# TimeChain Whitepaper PDF Export Guide

## 📄 **PDF Export Options**

This guide provides multiple methods for converting the TimeChain whitepaper to PDF format, including options for embedding diagrams and creating professional publications.

---

## 🚀 **Method 1: Automated Script (Recommended)**

### **Quick Start**
```bash
# Make the script executable
chmod +x pdf-export.sh

# Run the export
./pdf-export.sh
```

### **What It Does**
- Converts main whitepaper to PDF with proper formatting
- Converts all supporting documents to PDF
- Creates a combined PDF package (if pdfunite is available)
- Copies diagrams to output directory
- Provides detailed export summary

### **Requirements**
- `pandoc` - Document converter
- `xelatex` - PDF engine (usually included with LaTeX)
- `pdfunite` - PDF merging tool (optional)
- `ImageMagick` - Image processing (optional)

### **Installation**
```bash
# macOS
brew install pandoc

# Ubuntu/Debian
sudo apt-get install pandoc texlive-xetex

# Windows
# Download from https://pandoc.org/
# Install MiKTeX for LaTeX support
```

---

## 📝 **Method 2: Manual Pandoc Conversion**

### **Basic Conversion**
```bash
pandoc TIMECHAIN_WHITEPAPER_V0.1.md \
    --output=TimeChain_Whitepaper_v0.1.pdf \
    --from=markdown+yaml_metadata_block \
    --to=pdf \
    --pdf-engine=xelatex
```

### **Advanced Conversion with Formatting**
```bash
pandoc TIMECHAIN_WHITEPAPER_V0.1.md \
    --output=TimeChain_Whitepaper_v0.1.pdf \
    --from=markdown+yaml_metadata_block+raw_html \
    --to=pdf \
    --pdf-engine=xelatex \
    --variable=papersize:a4 \
    --variable=geometry:margin=1in \
    --variable=mainfont:"DejaVu Sans" \
    --variable=monofont:"DejaVu Sans Mono" \
    --variable=colorlinks:true \
    --variable=linkcolor:blue \
    --table-of-contents \
    --number-sections \
    --metadata=title:"TimeChain: A Protocol for Decentralized Time Consensus" \
    --metadata=author:"TimeChain Research Team" \
    --metadata=date:"$(date +%Y-%m-%d)" \
    --metadata=version:"v0.1"
```

---

## 🎨 **Method 3: Professional LaTeX Template**

### **Create LaTeX Template**
Create a file `timechain_template.tex`:

```latex
\documentclass[a4paper,11pt]{article}
\usepackage[utf8]{inputenc}
\usepackage{geometry}
\usepackage{graphicx}
\usepackage{hyperref}
\usepackage{listings}
\usepackage{xcolor}
\usepackage{fancyhdr}
\usepackage{tocloft}

% Page setup
\geometry{margin=1in}
\setlength{\parindent}{0pt}
\setlength{\parskip}{0.5em}

% Colors
\definecolor{timechainblue}{RGB}{37,99,235}
\definecolor{codegreen}{RGB}{0,128,0}
\definecolor{codegray}{RGB}{128,128,128}

% Hyperref setup
\hypersetup{
    colorlinks=true,
    linkcolor=timechainblue,
    urlcolor=timechainblue,
    citecolor=timechainblue
}

% Code listing style
\lstset{
    basicstyle=\ttfamily\small,
    keywordstyle=\color{timechainblue},
    commentstyle=\color{codegreen},
    stringstyle=\color{red},
    showstringspaces=false,
    breaklines=true,
    frame=single,
    backgroundcolor=\color{gray!10}
}

% Header setup
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{TimeChain Whitepaper v0.1}
\fancyhead[R]{\thepage}
\renewcommand{\headrulewidth}{0.4pt}
\renewcommand{\footrulewidth}{0pt}

% Title information
\title{\textbf{TimeChain: A Protocol for Decentralized Time Consensus}}
\author{TimeChain Research Team}
\date{\today}
\version{v0.1}

\begin{document}

\maketitle
\tableofcontents
\newpage

% Content will be inserted here
% Use: pandoc -s --template=timechain_template.tex TIMECHAIN_WHITEPAPER_V0.1.md -o output.pdf

\end{document}
```

### **Convert with Template**
```bash
pandoc TIMECHAIN_WHITEPAPER_V0.1.md \
    --output=TimeChain_Whitepaper_v0.1.pdf \
    --template=timechain_template.tex \
    --pdf-engine=xelatex
```

---

## 🖼️ **Method 4: PDF with Embedded Diagrams**

### **Using LaTeX with Graphics**
```latex
% Add to your LaTeX template
\usepackage{graphicx}
\usepackage{float}

% In your markdown, use:
![System Architecture](diagrams/system_architecture.png){ width=0.8\textwidth }
```

### **Using HTML + wkhtmltopdf**
```bash
# Convert to HTML first
pandoc TIMECHAIN_WHITEPAPER_V0.1.md -o temp.html

# Convert HTML to PDF with images
wkhtmltopdf --enable-local-file-access temp.html TimeChain_Whitepaper_v0.1.pdf

# Clean up
rm temp.html
```

### **Using Python (WeasyPrint)**
```python
import weasyprint

# Read markdown and convert to HTML
with open('TIMECHAIN_WHITEPAPER_V0.1.md', 'r') as f:
    markdown_content = f.read()

# Convert to HTML (using markdown library)
import markdown
html_content = markdown.markdown(markdown_content, extensions=['extra', 'tables'])

# Add CSS styling
html_with_css = f"""
<!DOCTYPE html>
<html>
<head>
    <style>
        body {{ font-family: Arial, sans-serif; line-height: 1.6; margin: 2cm; }}
        h1 {{ color: #2563eb; border-bottom: 2px solid #2563eb; }}
        h2 {{ color: #1e40af; }}
        img {{ max-width: 100%; height: auto; }}
        table {{ border-collapse: collapse; width: 100%; }}
        th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
        th {{ background-color: #f2f2f2; }}
    </style>
</head>
<body>
{html_content}
</body>
</html>
"""

# Convert to PDF
weasyprint.HTML(string=html_with_css).write_pdf('TimeChain_Whitepaper_v0.1.pdf')
```

---

## 📊 **Method 5: Online Converters**

### **Recommended Online Tools**
1. **Markdown to PDF**
   - [CloudConvert](https://cloudconvert.com/md-to-pdf)
   - [Online Markdown Editor](https://dillinger.io/)
   - [Markdown to PDF](https://www.markdowntopdf.com/)

2. **Professional Publishing**
   - [Overleaf](https://www.overleaf.com/) - LaTeX online editor
   - [Typora](https://typora.io/) - Markdown editor with PDF export
   - [Notion](https://www.notion.so/) - Collaborative docs with PDF export

### **Online Conversion Steps**
1. Upload your markdown file
2. Select PDF as output format
3. Configure formatting options
4. Download the resulting PDF

---

## 🔧 **Troubleshooting**

### **Common Issues**

#### **1. LaTeX Errors**
```bash
# Error: LaTeX not found
# Solution: Install LaTeX distribution
# macOS: brew install --cask mactex
# Ubuntu: sudo apt-get install texlive-full
```

#### **2. Font Issues**
```bash
# Error: Font not found
# Solution: Specify different fonts or install missing fonts
--variable=mainfont:"Arial" \
--variable=monofont:"Courier New"
```

#### **3. Image Path Issues**
```bash
# Error: Images not found
# Solution: Use relative paths or copy images to same directory
![System Architecture](./diagrams/system_architecture.png)
```

#### **4. Encoding Issues**
```bash
# Error: Character encoding problems
# Solution: Specify encoding explicitly
--from=markdown+yaml_metadata_block+raw_html \
--variable=mainfont:"DejaVu Sans"
```

### **Quality Optimization**

#### **High-Quality PDF Settings**
```bash
pandoc input.md \
    --output=output.pdf \
    --pdf-engine=xelatex \
    --variable=papersize:a4 \
    --variable=geometry:margin=1in \
    --variable=fontsize:12pt \
    --variable=linestretch:1.2 \
    --variable=colorlinks:true \
    --variable=linkcolor:blue \
    --table-of-contents \
    --number-sections
```

#### **Print-Ready PDF**
```bash
# For professional printing, use these settings:
--variable=papersize:a4 \
--variable=geometry:margin=1.5in \
--variable=fontsize:11pt \
--variable=linestretch:1.4
```

---

## 📈 **Advanced Features**

### **Watermarking**
```bash
# Add draft watermark using LaTeX
\usepackage{draftwatermark}
\SetWatermarkText{DRAFT}
\SetWatermarkScale{1}
\SetWatermarkColor{gray!20}
```

### **Page Numbering**
```bash
# Custom page numbering in LaTeX
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{TimeChain Whitepaper}
\fancyhead[R]{\thepage}
\renewcommand{\headrulewidth}{0.4pt}
```

### **Custom Styling**
```css
/* Custom CSS for HTML-based conversion */
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    line-height: 1.6;
    color: #333;
    max-width: 800px;
    margin: 0 auto;
    padding: 20px;
}

h1 {
    color: #2563eb;
    border-bottom: 3px solid #2563eb;
    padding-bottom: 10px;
}

h2 {
    color: #1e40af;
    margin-top: 30px;
}

code {
    background-color: #f3f4f6;
    padding: 2px 4px;
    border-radius: 3px;
    font-family: 'Courier New', monospace;
}
```

---

## 🎯 **Recommendations**

### **For Review Distribution**
- Use Method 1 (automated script) for consistency
- Include all supporting documents
- Use A4 format with standard margins
- Enable hyperlinks for digital distribution

### **For Formal Publication**
- Use Method 3 (LaTeX template) for professional quality
- Consider print-ready formatting
- Include proper metadata and page numbers
- Use high-quality image embedding

### **For Web Distribution**
- Use Method 4 (HTML + WeasyPrint) for interactive features
- Optimize for digital reading
- Include clickable links and references
- Consider responsive design

---

*This guide provides comprehensive options for converting your TimeChain whitepaper to professional PDF format. Choose the method that best fits your distribution needs and technical requirements.*