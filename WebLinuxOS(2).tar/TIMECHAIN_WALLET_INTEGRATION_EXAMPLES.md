# TimeChain Wallet Integration Examples

## 🚀 **Overview**

This document provides practical examples and integration patterns for developers building applications with the TimeChain Wallet. Each example demonstrates how to leverage the unique temporal capabilities of the TimeChain protocol in real-world scenarios.

---

## 📱 **Quick Start Examples**

### **1. Basic Wallet Setup**

#### **JavaScript/Node.js**
```javascript
import { TimeChainWallet } from '@timechain/wallet-sdk';

// Initialize wallet
const wallet = new TimeChainWallet({
  apiKey: 'your-api-key',
  network: 'mainnet'
});

// Connect to existing wallet
await wallet.connect('wallet_123456789');

// Get wallet info
const walletInfo = await wallet.getWalletInfo();
console.log('Wallet Address:', walletInfo.address);
console.log('Balance:', walletInfo.balance);
```

#### **React Native**
```javascript
import { TimeChainWallet } from '@timechain/react-native-wallet-sdk';

// Initialize wallet with biometric authentication
const wallet = new TimeChainWallet({
  apiKey: 'your-api-key',
  network: 'mainnet',
  options: {
    biometricAuthentication: true,
    secureStorage: true
  }
});

// Authenticate and connect
const isAuthenticated = await wallet.authenticateWithBiometrics();
if (isAuthenticated) {
  await wallet.connect('wallet_123456789');
}
```

#### **Python**
```python
from timechain_wallet import TimeChainWallet

# Initialize wallet
wallet = TimeChainWallet(
    api_key='your-api-key',
    network='mainnet'
)

# Connect to wallet
wallet.connect('wallet_123456789')

# Get balance
balance = wallet.get_balance()
print(f"Balance: {balance}")
```

---

## 💰 **Payment Integration Examples**

### **1. E-commerce Payment Processing**

#### **React E-commerce Component**
```javascript
import React, { useState } from 'react';
import { TimeChainWallet } from '@timechain/wallet-sdk';

const EcommercePayment = ({ cartItems, totalAmount }) => {
  const [wallet, setWallet] = useState(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState(null);

  // Initialize wallet
  React.useEffect(() => {
    const initWallet = async () => {
      const walletInstance = new TimeChainWallet({
        apiKey: 'your-api-key',
        network: 'mainnet'
      });
      await walletInstance.connect();
      setWallet(walletInstance);
    };
    initWallet();
  }, []);

  const handlePayment = async () => {
    if (!wallet) return;

    setIsProcessing(true);
    try {
      // Create payment transaction
      const transaction = await wallet.sendTransaction({
        to: 'merchant_timechain_address',
        value: totalAmount.toString(),
        asset: 'TIME',
        metadata: {
          orderId: generateOrderId(),
          items: cartItems,
          timestamp: new Date().toISOString()
        }
      });

      // Wait for confirmation
      const receipt = await wallet.waitForTransaction(transaction.hash);
      
      setPaymentStatus({
        status: 'success',
        transactionHash: receipt.hash,
        blockNumber: receipt.blockNumber
      });

      // Update order status in your backend
      await updateOrderStatus({
        orderId: generateOrderId(),
        paymentHash: receipt.hash,
        status: 'paid'
      });

    } catch (error) {
      setPaymentStatus({
        status: 'failed',
        error: error.message
      });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="ecommerce-payment">
      <div className="order-summary">
        <h3>Order Summary</h3>
        {cartItems.map(item => (
          <div key={item.id} className="order-item">
            <span>{item.name}</span>
            <span>{item.price} TIME</span>
          </div>
        ))}
        <div className="order-total">
          <strong>Total: {totalAmount} TIME</strong>
        </div>
      </div>

      <button
        onClick={handlePayment}
        disabled={isProcessing || !wallet}
        className="payment-button"
      >
        {isProcessing ? 'Processing...' : 'Pay with TimeChain'}
      </button>

      {paymentStatus && (
        <div className={`payment-status ${paymentStatus.status}`}>
          {paymentStatus.status === 'success' ? (
            <div>
              ✅ Payment Successful!
              <div className="transaction-details">
                Transaction Hash: {paymentStatus.transactionHash}
              </div>
            </div>
          ) : (
            <div>
              ❌ Payment Failed: {paymentStatus.error}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
```

#### **Backend Payment Verification (Node.js)**
```javascript
const express = require('express');
const { TimeChainWallet } = require('@timechain/wallet-sdk');
const app = express();

const wallet = new TimeChainWallet({
  apiKey: 'your-api-key',
  network: 'mainnet'
});

// Webhook endpoint for payment verification
app.post('/webhook/payment', async (req, res) => {
  const { transactionHash, orderId } = req.body;

  try {
    // Verify transaction
    const transaction = await wallet.getTransaction(transactionHash);
    
    if (transaction.status === 'confirmed') {
      // Update order status
      await updateOrderInDatabase(orderId, {
        status: 'paid',
        paymentHash: transactionHash,
        confirmedAt: new Date()
      });

      // Send confirmation email
      await sendPaymentConfirmationEmail(orderId);

      res.json({ success: true });
    } else {
      res.json({ success: false, error: 'Transaction not confirmed' });
    }
  } catch (error) {
    res.json({ success: false, error: error.message });
  }
});

// Check payment status
app.get('/api/payment/:orderId', async (req, res) => {
  const { orderId } = req.params;
  
  try {
    const order = await getOrderFromDatabase(orderId);
    res.json(order);
  } catch (error) {
    res.status(404).json({ error: 'Order not found' });
  }
});
```

### **2. Subscription Management**

#### **Recurring Subscription Component**
```javascript
import React, { useState, useEffect } from 'react';
import { TimeChainWallet } from '@timechain/wallet-sdk';

const SubscriptionManager = ({ user, plan }) => {
  const [wallet, setWallet] = useState(null);
  const [subscription, setSubscription] = useState(null);
  const [isCancelling, setIsCancelling] = useState(false);

  useEffect(() => {
    const initWallet = async () => {
      const walletInstance = new TimeChainWallet({
        apiKey: 'your-api-key',
        network: 'mainnet'
      });
      await walletInstance.connect();
      setWallet(walletInstance);

      // Load existing subscription
      const existingSubscription = await loadSubscription(user.id);
      setSubscription(existingSubscription);
    };
    initWallet();
  }, [user.id]);

  const createSubscription = async () => {
    if (!wallet) return;

    try {
      // Schedule recurring payment
      const scheduledPayment = await wallet.scheduleRecurringTransaction({
        to: 'merchant_timechain_address',
        value: plan.price.toString(),
        asset: 'TIME',
        schedule: {
          frequency: 'monthly',
          interval: 1,
          startDate: new Date(),
          endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000), // 1 year
          dayOfMonth: 1
        },
        metadata: {
          userId: user.id,
          planId: plan.id,
          type: 'subscription'
        }
      });

      // Save subscription to database
      const newSubscription = await saveSubscriptionToDatabase({
        userId: user.id,
        planId: plan.id,
        scheduleId: scheduledPayment.id,
        status: 'active',
        startDate: new Date(),
        endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000)
      });

      setSubscription(newSubscription);
    } catch (error) {
      console.error('Failed to create subscription:', error);
    }
  };

  const cancelSubscription = async () => {
    if (!wallet || !subscription) return;

    setIsCancelling(true);
    try {
      // Cancel scheduled payment
      await wallet.cancelScheduledTransaction(subscription.scheduleId);

      // Update subscription status
      await updateSubscriptionInDatabase(subscription.id, {
        status: 'cancelled',
        cancelledAt: new Date()
      });

      setSubscription(null);
    } catch (error) {
      console.error('Failed to cancel subscription:', error);
    } finally {
      setIsCancelling(false);
    }
  };

  return (
    <div className="subscription-manager">
      <h3>Subscription Management</h3>
      
      {subscription ? (
        <div className="active-subscription">
          <div className="subscription-info">
            <p><strong>Plan:</strong> {plan.name}</p>
            <p><strong>Price:</strong> {plan.price} TIME/month</p>
            <p><strong>Status:</strong> {subscription.status}</p>
            <p><strong>Next Payment:</strong> {formatDate(subscription.nextPaymentDate)}</p>
          </div>
          
          <button
            onClick={cancelSubscription}
            disabled={isCancelling}
            className="cancel-button"
          >
            {isCancelling ? 'Cancelling...' : 'Cancel Subscription'}
          </button>
        </div>
      ) : (
        <div className="no-subscription">
          <p>You don't have an active subscription.</p>
          <button
            onClick={createSubscription}
            disabled={!wallet}
            className="subscribe-button"
          >
            Subscribe to {plan.name}
          </button>
        </div>
      )}
    </div>
  );
};
```

---

## 📈 **DeFi Integration Examples**

### **1. Yield Farming Dashboard**

#### **DeFi Dashboard Component**
```javascript
import React, { useState, useEffect } from 'react';
import { TimeChainWallet } from '@timechain/wallet-sdk';

const YieldFarmingDashboard = () => {
  const [wallet, setWallet] = useState(null);
  const [positions, setPositions] = useState([]);
  const [availablePools, setAvailablePools] = useState([]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const initWallet = async () => {
      const walletInstance = new TimeChainWallet({
        apiKey: 'your-api-key',
        network: 'mainnet'
      });
      await walletInstance.connect();
      setWallet(walletInstance);

      // Load user positions
      const userPositions = await wallet.getDefiPositions();
      setPositions(userPositions);

      // Load available pools
      const pools = await wallet.getAvailablePools();
      setAvailablePools(pools);
    };
    initWallet();
  }, []);

  const stakeInPool = async (poolId, amount) => {
    if (!wallet) return;

    setIsLoading(true);
    try {
      // Create time-locked stake
      const stake = await wallet.createTimeLockedStake({
        amount: amount.toString(),
        asset: 'TIME',
        duration: 90 * 24 * 60 * 60, // 90 days
        interestRate: availablePools.find(p => p.id === poolId).apy,
        compounding: 'daily',
        metadata: {
          poolId: poolId,
          type: 'yield_farming'
        }
      });

      // Update positions
      const updatedPositions = await wallet.getDefiPositions();
      setPositions(updatedPositions);

      // Show success message
      alert(`Successfully staked ${amount} TIME in ${poolId}`);
    } catch (error) {
      console.error('Staking failed:', error);
      alert('Staking failed: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  const unstakeFromPool = async (positionId) => {
    if (!wallet) return;

    setIsLoading(true);
    try {
      // Unstake position
      const result = await wallet.unstakePosition(positionId);

      // Update positions
      const updatedPositions = await wallet.getDefiPositions();
      setPositions(updatedPositions);

      // Show success message
      alert('Successfully unstaked from position');
    } catch (error) {
      console.error('Unstaking failed:', error);
      alert('Unstaking failed: ' + error.message);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="yield-farming-dashboard">
      <h2>Yield Farming Dashboard</h2>
      
      <div className="dashboard-grid">
        {/* Available Pools */}
        <div className="available-pools">
          <h3>Available Pools</h3>
          {availablePools.map(pool => (
            <div key={pool.id} className="pool-card">
              <div className="pool-info">
                <h4>{pool.name}</h4>
                <p>APY: {pool.apy}%</p>
                <p>TVL: {pool.tvl} TIME</p>
              </div>
              <button
                onClick={() => {
                  const amount = prompt(`Enter amount to stake in ${pool.name}:`);
                  if (amount) stakeInPool(pool.id, amount);
                }}
                disabled={isLoading}
                className="stake-button"
              >
                Stake
              </button>
            </div>
          ))}
        </div>

        {/* User Positions */}
        <div className="user-positions">
          <h3>Your Positions</h3>
          {positions.length === 0 ? (
            <p>No active positions</p>
          ) : (
            positions.map(position => (
              <div key={position.id} className="position-card">
                <div className="position-info">
                  <h4>{position.poolName}</h4>
                  <p>Staked: {position.amount} TIME</p>
                  <p>APY: {position.apy}%</p>
                  <p>Duration: {position.remainingDays} days remaining</p>
                  <p>Earned: {position.earned} TIME</p>
                </div>
                <button
                  onClick={() => unstakeFromPool(position.id)}
                  disabled={isLoading}
                  className="unstake-button"
                >
                  Unstake
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
```

### **2. Options Trading Interface**

#### **Options Trading Component**
```javascript
import React, { useState, useEffect } from 'react';
import { TimeChainWallet } from '@timechain/wallet-sdk';

const OptionsTrading = () => {
  const [wallet, setWallet] = useState(null);
  const [options, setOptions] = useState([]);
  const [userPositions, setUserPositions] = useState([]);
  const [selectedOption, setSelectedOption] = useState(null);
  const [tradeAmount, setTradeAmount] = useState('');

  useEffect(() => {
    const initWallet = async () => {
      const walletInstance = new TimeChainWallet({
        apiKey: 'your-api-key',
        network: 'mainnet'
      });
      await walletInstance.connect();
      setWallet(walletInstance);

      // Load available options
      const availableOptions = await wallet.getAvailableOptions();
      setOptions(availableOptions);

      // Load user positions
      const positions = await wallet.getOptionsPositions();
      setUserPositions(positions);
    };
    initWallet();
  }, []);

  const createOption = async (optionType, strikePrice, expirationTime) => {
    if (!wallet || !selectedOption || !tradeAmount) return;

    try {
      const option = await wallet.createTemporalOption({
        underlying: selectedOption.underlying,
        strikePrice: strikePrice.toString(),
        expirationTime: expirationTime,
        optionType: optionType,
        premium: tradeAmount.toString(),
        metadata: {
          type: 'options_trading'
        }
      });

      // Update positions
      const updatedPositions = await wallet.getOptionsPositions();
      setUserPositions(updatedPositions);

      // Reset form
      setTradeAmount('');
      setSelectedOption(null);

      alert(`Successfully created ${optionType} option`);
    } catch (error) {
      console.error('Option creation failed:', error);
      alert('Option creation failed: ' + error.message);
    }
  };

  const exerciseOption = async (positionId) => {
    if (!wallet) return;

    try {
      const result = await wallet.exerciseOption(positionId);

      // Update positions
      const updatedPositions = await wallet.getOptionsPositions();
      setUserPositions(updatedPositions);

      alert('Option exercised successfully');
    } catch (error) {
      console.error('Option exercise failed:', error);
      alert('Option exercise failed: ' + error.message);
    }
  };

  return (
    <div className="options-trading">
      <h2>Options Trading</h2>
      
      <div className="trading-interface">
        {/* Option Creation */}
        <div className="option-creation">
          <h3>Create New Option</h3>
          
          <div className="form-group">
            <label>Underlying Asset</label>
            <select
              value={selectedOption?.id || ''}
              onChange={(e) => setSelectedOption(
                options.find(o => o.id === e.target.value)
              )}
            >
              <option value="">Select asset</option>
              {options.map(option => (
                <option key={option.id} value={option.id}>
                  {option.underlying}
                </option>
              ))}
            </select>
          </div>

          <div className="form-group">
            <label>Premium (TIME)</label>
            <input
              type="number"
              value={tradeAmount}
              onChange={(e) => setTradeAmount(e.target.value)}
              placeholder="Enter premium amount"
            />
          </div>

          <div className="option-actions">
            <button
              onClick={() => createOption(
                'call',
                selectedOption?.strikePrice,
                selectedOption?.expirationTime
              )}
              disabled={!selectedOption || !tradeAmount}
              className="call-button"
            >
              Buy Call Option
            </button>
            
            <button
              onClick={() => createOption(
                'put',
                selectedOption?.strikePrice,
                selectedOption?.expirationTime
              )}
              disabled={!selectedOption || !tradeAmount}
              className="put-button"
            >
              Buy Put Option
            </button>
          </div>
        </div>

        {/* User Positions */}
        <div className="user-options-positions">
          <h3>Your Options Positions</h3>
          {userPositions.length === 0 ? (
            <p>No options positions</p>
          ) : (
            userPositions.map(position => (
              <div key={position.id} className="option-position">
                <div className="position-info">
                  <h4>{position.underlying} {position.type.toUpperCase()}</h4>
                  <p>Strike Price: {position.strikePrice}</p>
                  <p>Premium: {position.premium} TIME</p>
                  <p>Expiration: {new Date(position.expirationTime).toLocaleDateString()}</p>
                  <p>Status: {position.status}</p>
                  {position.profitLoss !== undefined && (
                    <p>P&L: {position.profitLoss > 0 ? '+' : ''}{position.profitLoss} TIME</p>
                  )}
                </div>
                <button
                  onClick={() => exerciseOption(position.id)}
                  disabled={position.status !== 'active'}
                  className="exercise-button"
                >
                  Exercise
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
```

---

## 🏢 **Business Integration Examples**

### **1. Payroll System**

#### **Payroll Management System**
```javascript
class PayrollSystem {
  constructor(wallet) {
    this.wallet = wallet;
    this.employees = [];
    this.payrollSchedule = null;
  }

  // Add employee to payroll
  async addEmployee(employee) {
    this.employees.push({
      ...employee,
      id: generateEmployeeId(),
      status: 'active'
    });

    // Schedule recurring payroll payment
    await this.scheduleEmployeePayroll(employee);
  }

  // Schedule recurring payroll payment for employee
  async scheduleEmployeePayroll(employee) {
    const schedule = await this.wallet.scheduleRecurringTransaction({
      to: employee.timechainAddress,
      value: employee.salary.toString(),
      asset: 'TIME',
      schedule: {
        frequency: 'bi-weekly',
        interval: 1,
        startDate: this.getNextPayday(),
        endDate: new Date(Date.now() + 2 * 365 * 24 * 60 * 60 * 1000), // 2 years
        dayOfWeek: 5, // Friday
        weekOfMonth: [1, 3] // 1st and 3rd Friday
      },
      metadata: {
        employeeId: employee.id,
        type: 'payroll',
        department: employee.department,
        taxWithholding: employee.taxRate
      }
    });

    employee.payrollScheduleId = schedule.id;
    return schedule;
  }

  // Calculate next payday
  getNextPayday() {
    const today = new Date();
    const nextFriday = new Date(today);
    nextFriday.setDate(today.getDate() + (5 - today.getDay() + 7) % 7);
    
    // Check if this is the 1st or 3rd Friday
    const weekOfMonth = Math.ceil(nextFriday.getDate() / 7);
    if (weekOfMonth === 2 || weekOfMonth === 4) {
      // Add 14 days for next payday
      nextFriday.setDate(nextFriday.getDate() + 14);
    }
    
    return nextFriday;
  }

  // Process payroll for all employees
  async processPayroll() {
    const payrollReport = {
      processed: [],
      failed: [],
      totalAmount: 0,
      timestamp: new Date()
    };

    for (const employee of this.employees.filter(e => e.status === 'active')) {
      try {
        // Calculate net salary (after tax)
        const netSalary = employee.salary * (1 - employee.taxRate);
        
        // Send payroll payment
        const transaction = await this.wallet.sendTransaction({
          to: employee.timechainAddress,
          value: netSalary.toString(),
          asset: 'TIME',
          metadata: {
            employeeId: employee.id,
            type: 'payroll',
            period: getCurrentPayPeriod(),
            grossSalary: employee.salary,
            netSalary: netSalary,
            taxWithheld: employee.salary * employee.taxRate
          }
        });

        payrollReport.processed.push({
          employeeId: employee.id,
          amount: netSalary,
          transactionHash: transaction.hash,
          timestamp: new Date()
        });

        payrollReport.totalAmount += netSalary;

        // Send tax payment to government
        await this.payTaxes(employee.salary * employee.taxRate);

      } catch (error) {
        payrollReport.failed.push({
          employeeId: employee.id,
          error: error.message,
          timestamp: new Date()
        });
      }
    }

    // Generate payroll report
    await this.generatePayrollReport(payrollReport);
    
    return payrollReport;
  }

  // Pay taxes to government
  async payTaxes(taxAmount) {
    const taxTransaction = await this.wallet.sendTransaction({
      to: 'government_tax_agency_address',
      value: taxAmount.toString(),
      asset: 'TIME',
      metadata: {
        type: 'tax_payment',
        period: getCurrentPayPeriod()
      }
    });

    return taxTransaction;
  }

  // Generate payroll report
  async generatePayrollReport(report) {
    const reportData = {
      ...report,
      company: 'Your Company',
      period: getCurrentPayPeriod(),
      generatedAt: new Date()
    };

    // Save report to database
    await savePayrollReport(reportData);

    // Send report to accounting
    await sendReportToAccounting(reportData);

    return reportData;
  }

  // Update employee salary
  async updateEmployeeSalary(employeeId, newSalary) {
    const employee = this.employees.find(e => e.id === employeeId);
    if (!employee) throw new Error('Employee not found');

    // Cancel existing payroll schedule
    if (employee.payrollScheduleId) {
      await this.wallet.cancelScheduledTransaction(employee.payrollScheduleId);
    }

    // Update employee salary
    employee.salary = newSalary;

    // Create new payroll schedule
    await this.scheduleEmployeePayroll(employee);

    return employee;
  }

  // Terminate employee
  async terminateEmployee(employeeId) {
    const employee = this.employees.find(e => e.id === employeeId);
    if (!employee) throw new Error('Employee not found');

    // Cancel payroll schedule
    if (employee.payrollScheduleId) {
      await this.wallet.cancelScheduledTransaction(employee.payrollScheduleId);
    }

    // Process final paycheck
    await this.processFinalPaycheck(employee);

    // Update employee status
    employee.status = 'terminated';
    employee.terminationDate = new Date();

    return employee;
  }

  // Process final paycheck with severance
  async processFinalPaycheck(employee) {
    const severancePay = employee.salary * 2; // 2 months severance
    const finalPaycheck = employee.salary + severancePay;

    const transaction = await this.wallet.sendTransaction({
      to: employee.timechainAddress,
      value: finalPaycheck.toString(),
      asset: 'TIME',
      metadata: {
        employeeId: employee.id,
        type: 'final_paycheck',
        regularSalary: employee.salary,
        severancePay: severancePay,
        terminationDate: new Date()
      }
    });

    return transaction;
  }
}

// Usage example
const initPayrollSystem = async () => {
  const wallet = new TimeChainWallet({
    apiKey: 'your-api-key',
    network: 'mainnet'
  });
  await wallet.connect();

  const payroll = new PayrollSystem(wallet);

  // Add employees
  await payroll.addEmployee({
    name: 'John Doe',
    timechainAddress: 'tc1q...john',
    salary: 5000,
    taxRate: 0.25,
    department: 'Engineering'
  });

  await payroll.addEmployee({
    name: 'Jane Smith',
    timechainAddress: 'tc1q...jane',
    salary: 6000,
    taxRate: 0.30,
    department: 'Marketing'
  });

  // Process payroll (this would be called bi-weekly)
  const report = await payroll.processPayroll();
  console.log('Payroll processed:', report);
};
```

### **2. Supply Chain Finance**

#### **Supply Chain Payment System**
```javascript
class SupplyChainFinance {
  constructor(wallet) {
    this.wallet = wallet;
    this.suppliers = new Map();
    this.purchaseOrders = new Map();
    this.invoices = new Map();
  }

  // Register supplier
  async registerSupplier(supplier) {
    const supplierId = generateSupplierId();
    this.suppliers.set(supplierId, {
      ...supplier,
      id: supplierId,
      registeredAt: new Date(),
      status: 'active'
    });

    // Create supplier payment schedule
    await this.createSupplierPaymentSchedule(supplierId, supplier);

    return supplierId;
  }

  // Create supplier payment schedule
  async createSupplierPaymentSchedule(supplierId, supplier) {
    const schedule = await this.wallet.scheduleRecurringTransaction({
      to: supplier.timechainAddress,
      value: supplier.paymentTerms.amount.toString(),
      asset: 'TIME',
      schedule: {
        frequency: supplier.paymentTerms.frequency,
        interval: 1,
        startDate: supplier.paymentTerms.startDate,
        endDate: new Date(Date.now() + 2 * 365 * 24 * 60 * 60 * 1000) // 2 years
      },
      metadata: {
        supplierId: supplierId,
        type: 'supplier_payment',
        contractId: supplier.contractId
      }
    });

    supplier.paymentScheduleId = schedule.id;
    return schedule;
  }

  // Create purchase order
  async createPurchaseOrder(poData) {
    const poId = generatePOId();
    const purchaseOrder = {
      ...poData,
      id: poId,
      status: 'pending',
      createdAt: new Date(),
      totalAmount: poData.items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0)
    };

    this.purchaseOrders.set(poId, purchaseOrder);

    // Schedule payment based on terms
    await this.schedulePurchaseOrderPayment(poId, purchaseOrder);

    return poId;
  }

  // Schedule purchase order payment
  async schedulePurchaseOrderPayment(poId, purchaseOrder) {
    const paymentDate = new Date();
    paymentDate.setDate(paymentDate.getDate() + purchaseOrder.paymentTerms.netDays);

    const schedule = await this.wallet.scheduleTransaction({
      to: purchaseOrder.supplierAddress,
      value: purchaseOrder.totalAmount.toString(),
      asset: 'TIME',
      executeAt: paymentDate,
      metadata: {
        purchaseOrderId: poId,
        type: 'purchase_order_payment',
        supplierId: purchaseOrder.supplierId
      }
    });

    purchaseOrder.paymentScheduleId = schedule.id;
    return schedule;
  }

  // Create invoice
  async createInvoice(invoiceData) {
    const invoiceId = generateInvoiceId();
    const invoice = {
      ...invoiceData,
      id: invoiceId,
      status: 'pending',
      createdAt: new Date(),
      dueDate: new Date(Date.now() + invoiceData.paymentTerms.netDays * 24 * 60 * 60 * 1000)
    };

    this.invoices.set(invoiceId, invoice);

    // Schedule invoice payment
    await this.scheduleInvoicePayment(invoiceId, invoice);

    return invoiceId;
  }

  // Schedule invoice payment
  async scheduleInvoicePayment(invoiceId, invoice) {
    const schedule = await this.wallet.scheduleTransaction({
      to: invoice.supplierAddress,
      value: invoice.amount.toString(),
      asset: 'TIME',
      executeAt: invoice.dueDate,
      metadata: {
        invoiceId: invoiceId,
        type: 'invoice_payment',
        supplierId: invoice.supplierId
      }
    });

    invoice.paymentScheduleId = schedule.id;
    return schedule;
  }

  // Process early payment discount
  async processEarlyPayment(invoiceId) {
    const invoice = this.invoices.get(invoiceId);
    if (!invoice) throw new Error('Invoice not found');

    // Calculate early payment discount
    const daysEarly = Math.ceil((invoice.dueDate - new Date()) / (24 * 60 * 60 * 1000));
    const discountRate = invoice.paymentTerms.earlyPaymentDiscount;
    const discount = invoice.amount * (discountRate / 100) * (daysEarly / 30);
    const paymentAmount = invoice.amount - discount;

    // Cancel scheduled payment
    if (invoice.paymentScheduleId) {
      await this.wallet.cancelScheduledTransaction(invoice.paymentScheduleId);
    }

    // Process early payment
    const transaction = await this.wallet.sendTransaction({
      to: invoice.supplierAddress,
      value: paymentAmount.toString(),
      asset: 'TIME',
      metadata: {
        invoiceId: invoiceId,
        type: 'early_payment',
        originalAmount: invoice.amount,
        discount: discount,
        paymentAmount: paymentAmount,
        daysEarly: daysEarly
      }
    });

    // Update invoice status
    invoice.status = 'paid';
    invoice.paidAt = new Date();
    invoice.paymentAmount = paymentAmount;
    invoice.discount = discount;

    return transaction;
  }

  // Handle supply chain financing
  async handleSupplyChainFinancing(invoiceId, financingRate) {
    const invoice = this.invoices.get(invoiceId);
    if (!invoice) throw new Error('Invoice not found');

    // Calculate financing amount
    const financingAmount = invoice.amount * (1 - financingRate / 100);

    // Cancel scheduled payment
    if (invoice.paymentScheduleId) {
      await this.wallet.cancelScheduledTransaction(invoice.paymentScheduleId);
    }

    // Process financing payment
    const transaction = await this.wallet.sendTransaction({
      to: invoice.supplierAddress,
      value: financingAmount.toString(),
      asset: 'TIME',
      metadata: {
        invoiceId: invoiceId,
        type: 'supply_chain_financing',
        originalAmount: invoice.amount,
        financingAmount: financingAmount,
        financingRate: financingRate
      }
    });

    // Update invoice status
    invoice.status = 'financed';
    invoice.financedAt = new Date();
    invoice.financingAmount = financingAmount;
    invoice.financingRate = financingRate;

    return transaction;
  }

  // Generate supply chain report
  async generateSupplyChainReport() {
    const report = {
      suppliers: Array.from(this.suppliers.values()),
      purchaseOrders: Array.from(this.purchaseOrders.values()),
      invoices: Array.from(this.invoices.values()),
      metrics: {
        totalSuppliers: this.suppliers.size,
        activePOs: Array.from(this.purchaseOrders.values()).filter(po => po.status === 'active').length,
        pendingInvoices: Array.from(this.invoices.values()).filter(inv => inv.status === 'pending').length,
        totalOutstanding: Array.from(this.invoices.values())
          .filter(inv => inv.status === 'pending')
          .reduce((sum, inv) => sum + inv.amount, 0)
      },
      generatedAt: new Date()
    };

    return report;
  }
}

// Usage example
const initSupplyChainFinance = async () => {
  const wallet = new TimeChainWallet({
    apiKey: 'your-api-key',
    network: 'mainnet'
  });
  await wallet.connect();

  const supplyChain = new SupplyChainFinance(wallet);

  // Register supplier
  const supplierId = await supplyChain.registerSupplier({
    name: 'ABC Supplier Co.',
    timechainAddress: 'tc1q...supplier',
    paymentTerms: {
      frequency: 'monthly',
      amount: 10000,
      startDate: new Date(),
      netDays: 30
    },
    contractId: 'contract-123'
  });

  // Create purchase order
  const poId = await supplyChain.createPurchaseOrder({
    supplierId: supplierId,
    supplierAddress: 'tc1q...supplier',
    items: [
      { name: 'Raw Materials', quantity: 100, unitPrice: 50 },
      { name: 'Components', quantity: 200, unitPrice: 25 }
    ],
    paymentTerms: {
      netDays: 30
    }
  });

  // Create invoice
  const invoiceId = await supplyChain.createInvoice({
    supplierId: supplierId,
    supplierAddress: 'tc1q...supplier',
    amount: 10000,
    paymentTerms: {
      netDays: 30,
      earlyPaymentDiscount: 2 // 2% discount for early payment
    },
    purchaseOrderId: poId
  });

  // Process early payment with discount
  const earlyPayment = await supplyChain.processEarlyPayment(invoiceId);
  console.log('Early payment processed:', earlyPayment);

  // Generate report
  const report = await supplyChain.generateSupplyChainReport();
  console.log('Supply chain report:', report);
};
```

---

## 🎮 **Gaming Integration Examples**

### **1. Provably Fair Gaming System**

#### **Gaming Platform Integration**
```javascript
class ProvablyFairGaming {
  constructor(wallet) {
    this.wallet = wallet;
    this.games = new Map();
    this.players = new Map();
  }

  // Register player
  async registerPlayer(playerData) {
    const playerId = generatePlayerId();
    const player = {
      ...playerData,
      id: playerId,
      registeredAt: new Date(),
      balance: 0,
      totalWagered: 0,
      totalWon: 0,
      gamesPlayed: 0
    };

    this.players.set(playerId, player);
    return playerId;
  }

  // Create provably fair game
  async createGame(gameConfig) {
    const gameId = generateGameId();
    const game = {
      ...gameConfig,
      id: gameId,
      status: 'waiting',
      createdAt: new Date(),
      players: [],
      maxPlayers: gameConfig.maxPlayers || 10,
      entryFee: gameConfig.entryFee || 0,
      prizePool: 0,
      winningNumber: null
    };

    this.games.set(gameId, game);

    // Schedule game start
    await this.scheduleGameStart(gameId, game);

    return gameId;
  }

  // Schedule game start with VDF-based random number
  async scheduleGameStart(gameId, game) {
    const startTime = new Date(Date.now() + game.startTimeDelay || 300000); // 5 minutes default

    const schedule = await this.wallet.scheduleTransaction({
      to: 'game_contract_address',
      value: '0',
      asset: 'TIME',
      executeAt: startTime,
      metadata: {
        gameId: gameId,
        type: 'game_start',
        maxPlayers: game.maxPlayers,
        entryFee: game.entryFee
      }
    });

    game.startScheduleId = schedule.id;
    return schedule;
  }

  // Join game
  async joinGame(playerId, gameId) {
    const player = this.players.get(playerId);
    const game = this.games.get(gameId);

    if (!player || !game) throw new Error('Player or game not found');
    if (game.status !== 'waiting') throw new Error('Game not accepting players');
    if (game.players.length >= game.maxPlayers) throw new Error('Game full');

    // Pay entry fee
    if (game.entryFee > 0) {
      const transaction = await this.wallet.sendTransaction({
        to: 'game_contract_address',
        value: game.entryFee.toString(),
        asset: 'TIME',
        metadata: {
          playerId: playerId,
          gameId: gameId,
          type: 'game_entry_fee'
        }
      });

      // Update player balance
      player.balance -= game.entryFee;
      player.totalWagered += game.entryFee;
    }

    // Add player to game
    game.players.push(playerId);
    game.prizePool += game.entryFee;

    // If game is full, start immediately
    if (game.players.length === game.maxPlayers) {
      await this.startGame(gameId);
    }

    return { success: true, transactionHash: transaction?.hash };
  }

  // Start game and generate winning number
  async startGame(gameId) {
    const game = this.games.get(gameId);
    if (!game) throw new Error('Game not found');

    game.status = 'active';
    game.startedAt = new Date();

    // Generate VDF-based winning number
    const vdfChallenge = await this.wallet.generateVDFChallenge({
      gameId: gameId,
      timestamp: new Date()
    });

    // Schedule winning number generation
    const winningSchedule = await this.wallet.scheduleTransaction({
      to: 'game_contract_address',
      value: '0',
      asset: 'TIME',
      executeAt: new Date(Date.now() + 60000), // 1 minute from now
      metadata: {
        gameId: gameId,
        type: 'generate_winning_number',
        vdfChallenge: vdfChallenge
      }
    });

    game.winningScheduleId = winningSchedule.id;
    return winningSchedule;
  }

  // Generate winning number using VDF
  async generateWinningNumber(gameId, vdfChallenge) {
    const game = this.games.get(gameId);
    if (!game) throw new Error('Game not found');

    // Compute VDF for provably fair random number
    const vdfResult = await this.wallet.computeVDF(vdfChallenge);
    
    // Generate winning number from VDF result
    const winningNumber = this.extractWinningNumber(vdfResult);
    game.winningNumber = winningNumber;

    // Determine winner
    const winner = this.determineWinner(game, winningNumber);
    
    // Distribute prize
    await this.distributePrize(gameId, winner);

    // Update game status
    game.status = 'completed';
    game.completedAt = new Date();
    game.winner = winner;

    // Update player statistics
    this.updatePlayerStatistics(game, winner);

    return { winningNumber, winner };
  }

  // Extract winning number from VDF result
  extractWinningNumber(vdfResult) {
    // Use VDF result to generate provably fair random number
    const hash = crypto.createHash('sha256').update(vdfResult).digest('hex');
    return parseInt(hash.substring(0, 8), 16) % 1000000; // 6-digit number
  }

  // Determine winner based on game type
  determineWinner(game, winningNumber) {
    switch (game.type) {
      case 'lottery':
        // Simple lottery - closest number wins
        let closestPlayer = null;
        let closestDistance = Infinity;
        
        for (const playerId of game.players) {
          const player = this.players.get(playerId);
          const playerNumber = player.selectedNumber || Math.floor(Math.random() * 1000000);
          const distance = Math.abs(playerNumber - winningNumber);
          
          if (distance < closestDistance) {
            closestDistance = distance;
            closestPlayer = playerId;
          }
        }
        
        return closestPlayer;

      case 'roulette':
        // Roulette-style betting
        const rouletteResult = winningNumber % 37; // 0-36
        // Determine winner based on betting patterns
        return this.determineRouletteWinner(game, rouletteResult);

      case 'dice':
        // Dice game
        const diceResult = (winningNumber % 6) + 1; // 1-6
        return this.determineDiceWinner(game, diceResult);

      default:
        throw new Error('Unknown game type');
    }
  }

  // Distribute prize to winner
  async distributePrize(gameId, winnerId) {
    const game = this.games.get(gameId);
    if (!game || !winnerId) return;

    const winner = this.players.get(winnerId);
    const prizeAmount = game.prizePool * 0.9; // 10% house edge

    // Send prize to winner
    const transaction = await this.wallet.sendTransaction({
      to: winner.timechainAddress,
      value: prizeAmount.toString(),
      asset: 'TIME',
      metadata: {
        gameId: gameId,
        type: 'prize_distribution',
        winnerId: winnerId,
        prizeAmount: prizeAmount
      }
    });

    // Update winner balance
    winner.balance += prizeAmount;
    winner.totalWon += prizeAmount;

    return transaction;
  }

  // Update player statistics
  updatePlayerStatistics(game, winnerId) {
    for (const playerId of game.players) {
      const player = this.players.get(playerId);
      player.gamesPlayed++;
      
      if (playerId === winnerId) {
        player.gamesWon++;
      }
    }
  }

  // Verify game fairness
  async verifyGameFairness(gameId) {
    const game = this.games.get(gameId);
    if (!game) throw new Error('Game not found');

    // Get VDF challenge and result
    const vdfChallenge = game.vdfChallenge;
    const vdfResult = game.vdfResult;

    // Verify VDF computation
    const isValid = await this.wallet.verifyVDF(vdfChallenge, vdfResult);
    
    if (!isValid) {
      throw new Error('Game fairness verification failed');
    }

    // Recompute winning number
    const recomputedWinningNumber = this.extractWinningNumber(vdfResult);
    
    return {
      isValid: isValid,
      originalWinningNumber: game.winningNumber,
      recomputedWinningNumber: recomputedWinningNumber,
      isMatch: game.winningNumber === recomputedWinningNumber
    };
  }

  // Get player statistics
  async getPlayerStatistics(playerId) {
    const player = this.players.get(playerId);
    if (!player) throw new Error('Player not found');

    return {
      playerId: playerId,
      balance: player.balance,
      totalWagered: player.totalWagered,
      totalWon: player.totalWon,
      gamesPlayed: player.gamesPlayed,
      gamesWon: player.gamesWon,
      winRate: player.gamesPlayed > 0 ? (player.gamesWon / player.gamesPlayed) * 100 : 0,
      netProfit: player.totalWon - player.totalWagered
    };
  }
}

// Usage example
const initGamingPlatform = async () => {
  const wallet = new TimeChainWallet({
    apiKey: 'your-api-key',
    network: 'mainnet'
  });
  await wallet.connect();

  const gaming = new ProvablyFairGaming(wallet);

  // Register players
  const player1Id = await gaming.registerPlayer({
    name: 'Player 1',
    timechainAddress: 'tc1q...player1'
  });

  const player2Id = await gaming.registerPlayer({
    name: 'Player 2',
    timechainAddress: 'tc1q...player2'
  });

  // Create lottery game
  const gameId = await gaming.createGame({
    type: 'lottery',
    maxPlayers: 2,
    entryFee: 100, // 100 TIME
    startTimeDelay: 300000 // 5 minutes
  });

  // Players join game
  await gaming.joinGame(player1Id, gameId);
  await gaming.joinGame(player2Id, gameId);

  // Game starts automatically when full
  console.log('Game created with ID:', gameId);

  // Later, verify game fairness
  const fairness = await gaming.verifyGameFairness(gameId);
  console.log('Game fairness verification:', fairness);

  // Get player statistics
  const stats1 = await gaming.getPlayerStatistics(player1Id);
  const stats2 = await gaming.getPlayerStatistics(player2Id);
  console.log('Player 1 stats:', stats1);
  console.log('Player 2 stats:', stats2);
};
```

---

## 🤖 **IoT Integration Examples**

### **1. Smart Home Automation**

#### **IoT Device Management System**
```javascript
class IoTDeviceManager {
  constructor(wallet) {
    this.wallet = wallet;
    this.devices = new Map();
    this.automations = new Map();
    this.deviceGroups = new Map();
  }

  // Register IoT device
  async registerDevice(deviceData) {
    const deviceId = generateDeviceId();
    const device = {
      ...deviceData,
      id: deviceId,
      registeredAt: new Date(),
      status: 'offline',
      lastSeen: null,
      batteryLevel: null,
      firmwareVersion: deviceData.firmwareVersion || '1.0.0'
    };

    this.devices.set(deviceId, device);

    // Schedule device health checks
    await this.scheduleDeviceHealthCheck(deviceId);

    return deviceId;
  }

  // Schedule device health checks
  async scheduleDeviceHealthCheck(deviceId) {
    const schedule = await this.wallet.scheduleRecurringTransaction({
      to: 'iot_contract_address',
      value: '0',
      asset: 'TIME',
      schedule: {
        frequency: 'hourly',
        interval: 1,
        startDate: new Date()
      },
      metadata: {
        deviceId: deviceId,
        type: 'device_health_check'
      }
    });

    const device = this.devices.get(deviceId);
    device.healthCheckScheduleId = schedule.id;
    return schedule;
  }

  // Update device status
  async updateDeviceStatus(deviceId, status) {
    const device = this.devices.get(deviceId);
    if (!device) throw new Error('Device not found');

    device.status = status.status;
    device.lastSeen = new Date();
    
    if (status.batteryLevel !== undefined) {
      device.batteryLevel = status.batteryLevel;
    }

    // Trigger automations based on status changes
    await this.triggerAutomations(deviceId, status);

    return device;
  }

  // Create automation rule
  async createAutomation(automationData) {
    const automationId = generateAutomationId();
    const automation = {
      ...automationData,
      id: automationId,
      createdAt: new Date(),
      status: 'active',
      executionCount: 0
    };

    this.automations.set(automationId, automation);

    // Schedule automation execution
    await this.scheduleAutomation(automationId, automation);

    return automationId;
  }

  // Schedule automation execution
  async scheduleAutomation(automationId, automation) {
    const schedule = await this.wallet.scheduleConditionalTransaction({
      to: 'iot_contract_address',
      value: '0',
      asset: 'TIME',
      condition: {
        type: automation.trigger.type,
        deviceId: automation.trigger.deviceId,
        threshold: automation.trigger.threshold
      },
      action: {
        type: 'contract_call',
        function: 'executeAutomation',
        args: [automationId]
      },
      timeout: new Date(Date.now() + 24 * 60 * 60 * 1000) // 24 hour timeout
    });

    automation.scheduleId = schedule.id;
    return schedule;
  }

  // Trigger automations based on device status
  async triggerAutomations(deviceId, status) {
    const deviceAutomations = Array.from(this.automations.values())
      .filter(auto => auto.trigger.deviceId === deviceId && auto.status === 'active');

    for (const automation of deviceAutomations) {
      const shouldTrigger = this.evaluateTriggerCondition(automation.trigger, status);
      
      if (shouldTrigger) {
        await this.executeAutomation(automation.id);
      }
    }
  }

  // Evaluate trigger condition
  evaluateTriggerCondition(trigger, status) {
    switch (trigger.type) {
      case 'battery_low':
        return status.batteryLevel !== undefined && status.batteryLevel < trigger.threshold;
      
      case 'device_offline':
        return status.status === 'offline';
      
      case 'temperature_high':
        return status.temperature !== undefined && status.temperature > trigger.threshold;
      
      case 'motion_detected':
        return status.motion === true;
      
      case 'time_based':
        const now = new Date();
        const triggerTime = new Date(trigger.threshold);
        return now >= triggerTime;
      
      default:
        return false;
    }
  }

  // Execute automation
  async executeAutomation(automationId) {
    const automation = this.automations.get(automationId);
    if (!automation || automation.status !== 'active') return;

    try {
      // Execute automation actions
      for (const action of automation.actions) {
        await this.executeAction(action);
      }

      // Update automation statistics
      automation.executionCount++;
      automation.lastExecutedAt = new Date();

      // Schedule next execution if recurring
      if (automation.recurring) {
        await this.scheduleNextExecution(automationId, automation);
      }

    } catch (error) {
      console.error('Automation execution failed:', error);
      automation.status = 'error';
    }
  }

  // Execute individual action
  async executeAction(action) {
    switch (action.type) {
      case 'send_notification':
        await this.sendNotification(action);
        break;
      
      case 'control_device':
        await this.controlDevice(action);
        break;
      
      case 'schedule_maintenance':
        await this.scheduleMaintenance(action);
        break;
      
      case 'trigger_alarm':
        await this.triggerAlarm(action);
        break;
      
      default:
        throw new Error('Unknown action type');
    }
  }

  // Send notification
  async sendNotification(action) {
    const transaction = await this.wallet.sendTransaction({
      to: 'notification_service_address',
      value: '0',
      asset: 'TIME',
      metadata: {
        type: 'send_notification',
        recipient: action.recipient,
        message: action.message,
        priority: action.priority || 'normal'
      }
    });

    return transaction;
  }

  // Control device
  async controlDevice(action) {
    const transaction = await this.wallet.sendTransaction({
      to: 'device_control_contract',
      value: '0',
      asset: 'TIME',
      metadata: {
        type: 'control_device',
        deviceId: action.deviceId,
        command: action.command,
        parameters: action.parameters
      }
    });

    return transaction;
  }

  // Schedule maintenance
  async scheduleMaintenance(action) {
    const schedule = await this.wallet.scheduleTransaction({
      to: 'maintenance_service_address',
      value: action.cost?.toString() || '0',
      asset: 'TIME',
      executeAt: new Date(action.scheduledTime),
      metadata: {
        type: 'schedule_maintenance',
        deviceId: action.deviceId,
        maintenanceType: action.maintenanceType,
        description: action.description
      }
    });

    return schedule;
  }

  // Trigger alarm
  async triggerAlarm(action) {
    const transaction = await this.wallet.sendTransaction({
      to: 'alarm_service_address',
      value: '0',
      asset: 'TIME',
      metadata: {
        type: 'trigger_alarm',
        alarmType: action.alarmType,
        location: action.location,
        severity: action.severity || 'medium'
      }
    });

    return transaction;
  }

  // Create device group
  async createDeviceGroup(groupData) {
    const groupId = generateGroupId();
    const group = {
      ...groupData,
      id: groupId,
      createdAt: new Date(),
      devices: groupData.devices || []
    };

    this.deviceGroups.set(groupId, group);
    return groupId;
  }

  // Execute group automation
  async executeGroupAutomation(groupId, automationId) {
    const group = this.deviceGroups.get(groupId);
    if (!group) throw new Error('Device group not found');

    const automation = this.automations.get(automationId);
    if (!automation) throw new Error('Automation not found');

    // Execute automation on all devices in group
    for (const deviceId of group.devices) {
      const deviceAction = {
        ...automation.actions[0], // Use first action
        deviceId: deviceId
      };
      
      await this.executeAction(deviceAction);
    }
  }

  // Generate IoT dashboard data
  async generateDashboardData() {
    const devices = Array.from(this.devices.values());
    const automations = Array.from(this.automations.values());
    const groups = Array.from(this.deviceGroups.values());

    return {
      devices: {
        total: devices.length,
        online: devices.filter(d => d.status === 'online').length,
        offline: devices.filter(d => d.status === 'offline').length,
        lowBattery: devices.filter(d => d.batteryLevel !== null && d.batteryLevel < 20).length
      },
      automations: {
        total: automations.length,
        active: automations.filter(a => a.status === 'active').length,
        totalExecutions: automations.reduce((sum, a) => sum + a.executionCount, 0)
      },
      groups: {
        total: groups.length,
        totalDevices: groups.reduce((sum, g) => sum + g.devices.length, 0)
      },
      generatedAt: new Date()
    };
  }
}

// Usage example
const initIoTSystem = async () => {
  const wallet = new TimeChainWallet({
    apiKey: 'your-api-key',
    network: 'mainnet'
  });
  await wallet.connect();

  const iot = new IoTDeviceManager(wallet);

  // Register devices
  const thermostatId = await iot.registerDevice({
    name: 'Living Room Thermostat',
    type: 'thermostat',
    location: 'living_room',
    firmwareVersion: '2.1.0'
  });

  const securityCameraId = await iot.registerDevice({
    name: 'Front Door Camera',
    type: 'security_camera',
    location: 'front_door',
    firmwareVersion: '1.5.0'
  });

  const smartLockId = await iot.registerDevice({
    name: 'Front Door Lock',
    type: 'smart_lock',
    location: 'front_door',
    firmwareVersion: '3.0.0'
  });

  // Create automation rules
  await iot.createAutomation({
    name: 'Low Battery Alert',
    trigger: {
      type: 'battery_low',
      deviceId: thermostatId,
      threshold: 20
    },
    actions: [
      {
        type: 'send_notification',
        recipient: 'homeowner@email.com',
        message: 'Thermostat battery is low. Please replace batteries.',
        priority: 'high'
      }
    ],
    recurring: true
  });

  await iot.createAutomation({
    name: 'Motion Detected Alert',
    trigger: {
      type: 'motion_detected',
      deviceId: securityCameraId
    },
    actions: [
      {
        type: 'send_notification',
        recipient: 'homeowner@email.com',
        message: 'Motion detected at front door.',
        priority: 'medium'
      },
      {
        type: 'control_device',
        deviceId: smartLockId,
        command: 'lock',
        parameters: { timeout: 30 }
      }
    ],
    recurring: true
  });

  // Create device group
  const securityGroupId = await iot.createDeviceGroup({
    name: 'Security Devices',
    devices: [securityCameraId, smartLockId]
  });

  // Update device status (simulated)
  await iot.updateDeviceStatus(thermostatId, {
    status: 'online',
    batteryLevel: 15,
    temperature: 22
  });

  // Generate dashboard
  const dashboard = await iot.generateDashboardData();
  console.log('IoT Dashboard:', dashboard);
};
```

---

## 📊 **Analytics Integration Examples**

### **1. Temporal Analytics Dashboard**

#### **Analytics Integration Component**
```javascript
import React, { useState, useEffect } from 'react';
import { TimeChainWallet } from '@timechain/wallet-sdk';

const TemporalAnalyticsDashboard = () => {
  const [wallet, setWallet] = useState(null);
  const [analytics, setAnalytics] = useState(null);
  const [timeRange, setTimeRange] = useState('30d');
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const initWallet = async () => {
      const walletInstance = new TimeChainWallet({
        apiKey: 'your-api-key',
        network: 'mainnet'
      });
      await walletInstance.connect();
      setWallet(walletInstance);

      // Load initial analytics
      await loadAnalytics(walletInstance, timeRange);
    };
    initWallet();
  }, []);

  const loadAnalytics = async (walletInstance, range) => {
    setIsLoading(true);
    try {
      const analyticsData = await walletInstance.getTemporalAnalytics({
        timeRange: range,
        metrics: [
          'transaction_volume',
          'temporal_operations',
          'user_activity',
          'network_performance'
        ]
      });

      setAnalytics(analyticsData);
    } catch (error) {
      console.error('Failed to load analytics:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleTimeRangeChange = async (newRange) => {
    setTimeRange(newRange);
    if (wallet) {
      await loadAnalytics(wallet, newRange);
    }
  };

  const exportAnalytics = async () => {
    if (!analytics) return;

    try {
      const exportData = await wallet.exportAnalyticsData({
        analytics: analytics,
        format: 'csv',
        timeRange: timeRange
      });

      // Create download link
      const blob = new Blob([exportData], { type: 'text/csv' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `temporal-analytics-${timeRange}.csv`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Failed to export analytics:', error);
    }
  };

  return (
    <div className="temporal-analytics-dashboard">
      <div className="dashboard-header">
        <h2>Temporal Analytics Dashboard</h2>
        <div className="time-range-selector">
          <select
            value={timeRange}
            onChange={(e) => handleTimeRangeChange(e.target.value)}
          >
            <option value="24h">Last 24 Hours</option>
            <option value="7d">Last 7 Days</option>
            <option value="30d">Last 30 Days</option>
            <option value="90d">Last 90 Days</option>
            <option value="1y">Last Year</option>
          </select>
          <button onClick={exportAnalytics} className="export-button">
            Export Data
          </button>
        </div>
      </div>

      {isLoading ? (
        <div className="loading">Loading analytics...</div>
      ) : analytics ? (
        <div className="analytics-content">
          {/* Transaction Volume Chart */}
          <div className="analytics-card">
            <h3>Transaction Volume Over Time</h3>
            <TemporalLineChart
              data={analytics.transaction_volume}
              xAxis="timestamp"
              yAxis="volume"
              title="Transaction Volume"
            />
          </div>

          {/* Temporal Operations Distribution */}
          <div className="analytics-card">
            <h3>Temporal Operations Distribution</h3>
            <TemporalPieChart
              data={analytics.temporal_operations}
              title="Operation Types"
            />
          </div>

          {/* User Activity Heatmap */}
          <div className="analytics-card">
            <h3>User Activity Heatmap</h3>
            <TemporalHeatmap
              data={analytics.user_activity}
              title="User Activity by Time"
            />
          </div>

          {/* Network Performance Metrics */}
          <div className="analytics-card">
            <h3>Network Performance</h3>
            <PerformanceMetrics
              data={analytics.network_performance}
              metrics={['latency', 'throughput', 'error_rate']}
            />
          </div>

          {/* Key Metrics Summary */}
          <div className="analytics-card">
            <h3>Key Metrics</h3>
            <div className="metrics-grid">
              <div className="metric-item">
                <div className="metric-value">
                  {analytics.summary.total_transactions.toLocaleString()}
                </div>
                <div className="metric-label">Total Transactions</div>
              </div>
              <div className="metric-item">
                <div className="metric-value">
                  {analytics.summary.active_users.toLocaleString()}
                </div>
                <div className="metric-label">Active Users</div>
              </div>
              <div className="metric-item">
                <div className="metric-value">
                  {analytics.summary.avg_latency.toFixed(2)}ms
                </div>
                <div className="metric-label">Avg Latency</div>
              </div>
              <div className="metric-item">
                <div className="metric-value">
                  {analytics.summary.success_rate.toFixed(1)}%
                </div>
                <div className="metric-label">Success Rate</div>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="no-data">No analytics data available</div>
      )}
    </div>
  );
};
```

---

## 🚀 **Deployment Examples**

### **1. Docker Deployment**

#### **Docker Compose for TimeChain Wallet Services**
```yaml
version: '3.8'

services:
  # TimeChain Wallet API Service
  wallet-api:
    build:
      context: .
      dockerfile: Dockerfile.api
    ports:
      - "3000:3000"
    environment:
      - NODE_ENV=production
      - TIMECHAIN_API_KEY=${TIMECHAIN_API_KEY}
      - TIMECHAIN_NETWORK=mainnet
      - DATABASE_URL=${DATABASE_URL}
      - REDIS_URL=${REDIS_URL}
    depends_on:
      - postgres
      - redis
    volumes:
      - ./logs:/app/logs
    restart: unless-stopped

  # TimeChain Wallet Web App
  wallet-web:
    build:
      context: .
      dockerfile: Dockerfile.web
    ports:
      - "80:80"
      - "443:443"
    environment:
      - REACT_APP_API_URL=https://api.wallet.timechain.network
      - REACT_APP_NETWORK=mainnet
    depends_on:
      - wallet-api
    volumes:
      - ./ssl:/etc/ssl/certs
    restart: unless-stopped

  # PostgreSQL Database
  postgres:
    image: postgres:15
    environment:
      - POSTGRES_DB=timechain_wallet
      - POSTGRES_USER=${POSTGRES_USER}
      - POSTGRES_PASSWORD=${POSTGRES_PASSWORD}
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./database/init.sql:/docker-entrypoint-initdb.d/init.sql
    ports:
      - "5432:5432"
    restart: unless-stopped

  # Redis Cache
  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis_data:/data
    restart: unless-stopped

  # Nginx Reverse Proxy
  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - wallet-api
      - wallet-web
    restart: unless-stopped

  # TimeChain Node
  timechain-node:
    image: timechain/node:latest
    ports:
      - "8545:8545"  # JSON-RPC
      - "8546:8546"  # WebSocket
    environment:
      - TIMECHAIN_NETWORK=mainnet
      - NODE_TYPE=validator
      - DATA_DIR=/data
    volumes:
      - timechain_data:/data
    restart: unless-stopped

volumes:
  postgres_data:
  redis_data:
  timechain_data:
```

#### **Kubernetes Deployment**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: timechain-wallet-api
  labels:
    app: timechain-wallet-api
spec:
  replicas: 3
  selector:
    matchLabels:
      app: timechain-wallet-api
  template:
    metadata:
      labels:
        app: timechain-wallet-api
    spec:
      containers:
      - name: timechain-wallet-api
        image: timechain/wallet-api:latest
        ports:
        - containerPort: 3000
        env:
        - name: NODE_ENV
          value: "production"
        - name: TIMECHAIN_API_KEY
          valueFrom:
            secretKeyRef:
              name: timechain-secrets
              key: api-key
        - name: TIMECHAIN_NETWORK
          value: "mainnet"
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: timechain-secrets
              key: database-url
        resources:
          requests:
            memory: "256Mi"
            cpu: "250m"
          limits:
            memory: "512Mi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /health
            port: 3000
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 3000
          initialDelaySeconds: 5
          periodSeconds: 5

---
apiVersion: v1
kind: Service
metadata:
  name: timechain-wallet-api-service
spec:
  selector:
    app: timechain-wallet-api
  ports:
  - protocol: TCP
    port: 80
    targetPort: 3000
  type: LoadBalancer

---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: timechain-wallet-ingress
  annotations:
    nginx.ingress.kubernetes.io/rewrite-target: /
    cert-manager.io/cluster-issuer: letsencrypt-prod
spec:
  tls:
  - hosts:
    - api.wallet.timechain.network
    secretName: timechain-wallet-tls
  rules:
  - host: api.wallet.timechain.network
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: timechain-wallet-api-service
            port:
              number: 80
```

---

*These integration examples demonstrate the versatility and power of the TimeChain Wallet across various industries and use cases. Each example showcases how to leverage the unique temporal capabilities of the TimeChain protocol to solve real-world problems.*