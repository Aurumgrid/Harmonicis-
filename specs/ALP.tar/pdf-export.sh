#!/usr/bin/env bash
# pdf-export.sh - Convert TimeChain whitepaper to PDF with diagrams
# Requires: pandoc, pandoc-crossref, pandoc-citeproc

set -e

echo "🚀 Starting TimeChain Whitepaper PDF Export..."

# Check if pandoc is installed
if ! command -v pandoc &> /dev/null; then
    echo "❌ Pandoc is not installed. Please install it first:"
    echo "   macOS: brew install pandoc"
    echo "   Ubuntu: sudo apt-get install pandoc"
    echo "   Windows: Download from https://pandoc.org/"
    exit 1
fi

# Create output directory
mkdir -p output

# Convert markdown to PDF with proper formatting
echo "📄 Converting TIMECHAIN_WHITEPAPER_V0.1.md to PDF..."
pandoc TIMECHAIN_WHITEPAPER_V0.1.md \
    --output=output/TimeChain_Whitepaper_v0.1.pdf \
    --from=markdown+yaml_metadata_block+raw_html \
    --to=pdf \
    --pdf-engine=xelatex \
    --variable=papersize:a4 \
    --variable=geometry:margin=1in \
    --variable=mainfont:"DejaVu Sans" \
    --variable=monofont:"DejaVu Sans Mono" \
    --variable=colorlinks:true \
    --variable=linkcolor:blue \
    --variable=urlcolor:blue \
    --variable=toccolor:blue \
    --table-of-contents \
    --number-sections \
    --metadata=title:"TimeChain: A Protocol for Decentralized Time Consensus" \
    --metadata=author:"TimeChain Research Team" \
    --metadata=date:"$(date +%Y-%m-%d)" \
    --metadata=version:"v0.1"

echo "✅ Main whitepaper PDF created: output/TimeChain_Whitepaper_v0.1.pdf"

# Convert other documents to PDF
echo "📋 Converting supporting documents..."

# Review Checklist
pandoc WHITEPAPER_REVIEW_CHECKLIST.md \
    --output=output/Whitepaper_Review_Checklist.pdf \
    --from=markdown \
    --to=pdf \
    --pdf-engine=xelatex \
    --variable=papersize:a4 \
    --variable=geometry:margin=1in

# Version Management
pandoc VERSION_MANAGEMENT.md \
    --output=output/Version_Management.pdf \
    --from=markdown \
    --to=pdf \
    --pdf-engine=xelatex \
    --variable=papersize:a4 \
    --variable=geometry:margin=1in

# Enhancement Template
pandoc V0_2_ENHANCEMENT_TEMPLATE.md \
    --output=output/V0_2_Enhancement_Template.pdf \
    --from=markdown \
    --to=pdf \
    --pdf-engine=xelatex \
    --variable=papersize:a4 \
    --variable=geometry:margin=1in

echo "✅ Supporting documents converted to PDF"

# Create a combined PDF package
echo "📦 Creating combined PDF package..."
if command -v pdfunite &> /dev/null; then
    pdfunite \
        output/TimeChain_Whitepaper_v0.1.pdf \
        output/Whitepaper_Review_Checklist.pdf \
        output/Version_Management.pdf \
        output/V0_2_Enhancement_Template.pdf \
        output/TimeChain_Complete_Package_v0.1.pdf
    echo "✅ Combined PDF created: output/TimeChain_Complete_Package_v0.1.pdf"
else
    echo "⚠️  pdfunite not found. Combined PDF not created."
fi

# Copy diagrams to output
echo "🖼️  Copying diagrams to output directory..."
mkdir -p output/diagrams
cp diagrams/*.png output/diagrams/

# Create a PDF with diagrams embedded (requires additional tools)
echo "🎨 Creating enhanced PDF with embedded diagrams..."
if command -v convert &> /dev/null; then
    # This is a placeholder - actual implementation would require more complex PDF manipulation
    echo "⚠️  Diagram embedding requires additional PDF tools. See README for instructions."
fi

# Show output summary
echo ""
echo "📊 Export Summary:"
echo "=================="
echo "📄 Main Whitepaper: output/TimeChain_Whitepaper_v0.1.pdf"
echo "📋 Review Checklist: output/Whitepaper_Review_Checklist.pdf"
echo "📋 Version Management: output/Version_Management.pdf"
echo "📋 Enhancement Template: output/V0_2_Enhancement_Template.pdf"
ls -la output/*.pdf 2>/dev/null || echo "No PDF files found"
echo ""
echo "🖼️  Diagrams copied to: output/diagrams/"
ls -la output/diagrams/ 2>/dev/null || echo "No diagram files found"
echo ""
echo "🎉 PDF export completed successfully!"
echo ""
echo "💡 Tips for better PDF generation:"
echo "   - Install 'pdfunite' for combined PDF creation"
echo "   - Install 'ImageMagick' for diagram embedding"
echo "   - Use 'wkhtmltopdf' for alternative PDF generation"
echo "   - Consider using LaTeX for more advanced formatting"