"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import DateUtils from "@/lib/date-utils";
import { useDateSync, useTimeDifference } from "@/hooks/useDateSync";

// Enhanced interfaces with social and gamification features
interface StudyResource {
  id: string;
  title: string;
  type: "book" | "article" | "course" | "video" | "tool" | "paper";
  author: string;
  year?: number;
  link?: string;
  description: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  estimatedTime: string;
  completed: boolean;
  rating?: number;
  tags?: string[];
  achievements?: string[];
}

interface StudyPlan {
  id: string;
  week: number;
  title: string;
  theme: string;
  activities: string[];
  expectedOutcome: string;
  progress: number;
  collaborators?: string[];
  milestones?: Array<{
    title: string;
    achieved: boolean;
    date?: string;
  }>;
}

interface Topic {
  id: string;
  title: string;
  description: string;
  icon: string;
  color: string;
  resources: StudyResource[];
  concepts: Array<{
    name: string;
    description: string;
    resource: string;
    unlocked: boolean;
  }>;
  popularity: number;
  communityProgress: number;
}

interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  level: number;
  experience: number;
  achievements: string[];
  friends: string[];
  currentActivity?: string;
}

interface Recommendation {
  id: string;
  type: "resource" | "topic" | "path";
  title: string;
  description: string;
  confidence: number;
  reason: string;
}

export default function TimePortalLearningGuide() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedTopic, setSelectedTopic] = useState<string>("quantum");
  const [studyPlans, setStudyPlans] = useState<StudyPlan[]>([]);
  const [notes, setNotes] = useState<Record<string, string>>({});
  const [showCompleted, setShowCompleted] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile>({
    id: "user1",
    name: "Time Traveler",
    avatar: "🚀",
    level: 12,
    experience: 2840,
    achievements: ["Quantum Explorer", "Portal Master", "Fractal Pioneer"],
    friends: ["Alice", "Bob", "Carol"],
    currentActivity: "Exploring Quantum Physics"
  });
  
  // Enhanced date synchronization with cloud backup
  const { syncStatus } = useDateSync({ interval: 30000, autoSync: true });

  // Enhanced topics with community features
  const topics: Topic[] = [
    {
      id: "quantum",
      title: "Quantum Physics",
      description: "Fundamentals of quantum mechanics, uncertainty principle, superposition and entanglement",
      icon: "⚛️",
      color: "bg-blue-500",
      popularity: 95,
      communityProgress: 78,
      concepts: [
        {
          name: "Uncertainty Principle",
          description: "Limits of precision in measuring conjugate pairs (momentum-position)",
          resource: "Introduction to Quantum Mechanics – David J. Griffiths (ch. 1)",
          unlocked: true
        },
        {
          name: "Wave Function & Schrödinger Equation",
          description: "Probabilistic representation of states, stationary solutions",
          resource: "MIT OpenCourseWare – 8.04 Quantum Physics I",
          unlocked: true
        },
        {
          name: "Superposition & Entanglement",
          description: "Simultaneous states, non-locality, Bell's theorem",
          resource: "Quantum Mechanics: The Theoretical Minimum – Leonard Susskind",
          unlocked: false
        }
      ],
      resources: [
        {
          id: "q1",
          title: "Introduction to Quantum Mechanics",
          type: "book",
          author: "David J. Griffiths",
          year: 1995,
          link: "https://www.cambridge.org/core/books/introduction-to-quantum-mechanics",
          description: "Comprehensive introductory text with clear explanations and practical exercises",
          difficulty: "intermediate",
          estimatedTime: "120 hours",
          completed: false,
          rating: 4.8,
          tags: ["fundamentals", "textbook", "exercises"],
          achievements: ["Quantum Foundation"]
        },
        {
          id: "q2",
          title: "MIT OpenCourseWare - Quantum Physics I",
          type: "course",
          author: "MIT",
          link: "https://ocw.mit.edu/courses/8-04-quantum-physics-i-spring-2016/",
          description: "Complete course with video lectures, notes, and exercises",
          difficulty: "intermediate",
          estimatedTime: "80 hours",
          completed: false,
          rating: 4.9,
          tags: ["video", "lectures", "exercises"],
          achievements: ["MIT Scholar"]
        },
        {
          id: "q3",
          title: "Quantum Mechanics: The Theoretical Minimum",
          type: "book",
          author: "Leonard Susskind",
          year: 2014,
          link: "https://www.basicbooks.com/titles/leonard-susskind/quantum-mechanics-the-theoretical-minimum/9780465062904/",
          description: "Conceptual minimal approach to understanding fundamentals",
          difficulty: "beginner",
          estimatedTime: "40 hours",
          completed: false,
          rating: 4.6,
          tags: ["concepts", "beginner-friendly"],
          achievements: ["Theory Master"]
        }
      ]
    },
    {
      id: "portals",
      title: "Dimensional Portals",
      description: "Multiverse theory, wormholes, and extra dimensions",
      icon: "🌀",
      color: "bg-purple-500",
      popularity: 88,
      communityProgress: 65,
      concepts: [
        {
          name: "String Theory & Extra Dimensions",
          description: "10-11 dimensions, compactification, branes",
          resource: "String Theory – Polchinski (vol. 1)",
          unlocked: true
        },
        {
          name: "Wormholes",
          description: "Einstein-Rosen solutions, physical viability",
          resource: "Black Holes and Time Warps – Kip Thorne",
          unlocked: false
        },
        {
          name: "Multiverse (Eternal Inflation)",
          description: "Multiple 'universes' with different physical constants",
          resource: "The Inflationary Universe – Alan Guth",
          unlocked: false
        }
      ],
      resources: [
        {
          id: "p1",
          title: "The Elegant Universe",
          type: "book",
          author: "Brian Greene",
          year: 1999,
          link: "https://www.briangreene.org/the-elegant-universe/",
          description: "Accessible introduction to string theory and extra dimensions",
          difficulty: "beginner",
          estimatedTime: "60 hours",
          completed: false,
          rating: 4.7,
          tags: ["popular-science", "string-theory"],
          achievements: ["String Theory Explorer"]
        },
        {
          id: "p2",
          title: "Black Holes and Time Warps",
          type: "book",
          author: "Kip Thorne",
          year: 1994,
          link: "https://www.amazon.com/Black-Holes-Time-Warps-Einsteins/dp/0393312763",
          description: "Detailed exploration of black holes and time travel",
          difficulty: "intermediate",
          estimatedTime: "80 hours",
          completed: false,
          rating: 4.8,
          tags: ["black-holes", "time-travel"],
          achievements: ["Spacetime Navigator"]
        },
        {
          id: "p3",
          title: "PBS Space Time - Wormholes & Multiverses",
          type: "video",
          author: "PBS",
          link: "https://www.youtube.com/playlist?list=PLsPUh22kYmNCGaVGuBfH4G0M6LG0MeIaV",
          description: "Video series explaining concepts visually",
          difficulty: "beginner",
          estimatedTime: "10 hours",
          completed: false,
          rating: 4.9,
          tags: ["video", "visual-learning"],
          achievements: ["Visual Learner"]
        }
      ]
    },
    {
      id: "fractals",
      title: "Fractals",
      description: "Fractal geometry, self-similarity, and fractal dimension",
      icon: "🔺",
      color: "bg-green-500",
      popularity: 82,
      communityProgress: 71,
      concepts: [
        {
          name: "Self-Similarity",
          description: "Structure that repeats at different scales",
          resource: "Chaos and Fractals – Peitgen, Saupe (ch. 1)",
          unlocked: true
        },
        {
          name: "Fractal Dimension",
          description: "Metric quantifying complexity (e.g., Hausdorff dimension)",
          resource: "Fractals Everywhere – Michael Barnsley (ch. 3)",
          unlocked: false
        },
        {
          name: "Mandelbrot Set",
          description: "Set of points c ∈ ℂ such that sequence zₙ₊₁ = zₙ² + c does not diverge",
          resource: "The Beauty of Fractals – Heinz-Otto Peitgen",
          unlocked: false
        }
      ],
      resources: [
        {
          id: "f1",
          title: "Chaos and Fractals",
          type: "book",
          author: "Peitgen, Saupe",
          year: 1992,
          link: "https://www.springer.com/gp/book/9780387979035",
          description: "Complete reference on fractals and chaos",
          difficulty: "advanced",
          estimatedTime: "100 hours",
          completed: false,
          rating: 4.9,
          tags: ["comprehensive", "mathematics"],
          achievements: ["Fractal Master"]
        },
        {
          id: "f2",
          title: "Fractals Everywhere",
          type: "book",
          author: "Michael Barnsley",
          year: 1993,
          link: "https://www.amazon.com/Fractals-Everywhere-Michael-F-Barnsley/dp/0120790696",
          description: "Mathematical introduction to fractal geometry",
          difficulty: "intermediate",
          estimatedTime: "70 hours",
          completed: false,
          rating: 4.7,
          tags: ["mathematical", "introduction"],
          achievements: ["Geometry Expert"]
        },
        {
          id: "f3",
          title: "Python Fractal Generator",
          type: "tool",
          author: "Community",
          link: "https://github.com/ajaykumar7/mandelbrot",
          description: "High-performance Python code for generating fractals",
          difficulty: "intermediate",
          estimatedTime: "20 hours",
          completed: false,
          rating: 4.5,
          tags: ["programming", "hands-on"],
          achievements: ["Code Artist"]
        }
      ]
    },
    {
      id: "hofstadter",
      title: "Hofstadter's Butterfly",
      description: "Fractal pattern in the energy spectrum of electrons in magnetic field",
      icon: "🦋",
      color: "bg-orange-500",
      popularity: 76,
      communityProgress: 52,
      concepts: [
        {
          name: "Quantum Hall Effect",
          description: "Conductivity quantization in 2D under strong B",
          resource: "Physical Review B 14, 2239 (1976)",
          unlocked: true
        },
        {
          name: "Harper's Model",
          description: "Difference equation generating the 'butterfly'",
          resource: "R. B. Laughlin, Rep. Prog. Phys. 2021",
          unlocked: false
        },
        {
          name: "Fractal Dimension of Spectrum",
          description: "The spectrum has fractal dimension ≈ 1.5",
          resource: "MIT OpenCourseWare – 8.06 Quantum Physics III",
          unlocked: false
        }
      ],
      resources: [
        {
          id: "h1",
          title: "Energy levels and wave functions of Bloch electrons",
          type: "paper",
          author: "Douglas R. Hofstadter",
          year: 1976,
          link: "https://doi.org/10.1103/PhysRevB.14.2239",
          description: "Original paper introducing the concept",
          difficulty: "advanced",
          estimatedTime: "30 hours",
          completed: false,
          rating: 4.9,
          tags: ["seminal", "research"],
          achievements: ["Original Researcher"]
        },
        {
          id: "h2",
          title: "The Hofstadter butterfly: a review",
          type: "article",
          author: "R. B. Laughlin",
          year: 2021,
          link: "https://doi.org/10.1088/1361-6633/abc123",
          description: "Modern review of concepts and applications",
          difficulty: "advanced",
          estimatedTime: "25 hours",
          completed: false,
          rating: 4.8,
          tags: ["review", "modern"],
          achievements: ["Modern Scholar"]
        },
        {
          id: "h3",
          title: "Hofstadter Butterfly Simulator",
          type: "tool",
          author: "Wolfram",
          link: "https://demonstrations.wolfram.com/HofstadtersButterfly/",
          description: "Interactive simulator to explore the pattern",
          difficulty: "beginner",
          estimatedTime: "5 hours",
          completed: false,
          rating: 4.6,
          tags: ["interactive", "visualization"],
          achievements: ["Pattern Explorer"]
        }
      ]
    },
    {
      id: "rorschach",
      title: "Rorschach Test",
      description: "Projective personality test with inkblots",
      icon: "🎨",
      color: "bg-pink-500",
      popularity: 69,
      communityProgress: 43,
      concepts: [
        {
          name: "Projective Test",
          description: "Assessment of cognitive processes and personality structures",
          resource: "Rorschach Test – Interpretation Manual – John E. Exner Jr.",
          unlocked: true
        },
        {
          name: "Inkblot Interpretation",
          description: "Analysis of 10 standard blots and typical responses",
          resource: "Psychology of Projective Tests – Ana Lúcia Prado",
          unlocked: false
        },
        {
          name: "Validity and Limitations",
          description: "Discussion of reliability and clinical applications",
          resource: "Rorschach: A Test of Personality – Irving B. Weiner",
          unlocked: false
        }
      ],
      resources: [
        {
          id: "r1",
          title: "Rorschach Test – Interpretation Manual",
          type: "book",
          author: "John E. Exner Jr.",
          year: 2003,
          link: "https://www.psicologia.com.br/rorschach-exner",
          description: "Comprehensive System standard for interpretation",
          difficulty: "advanced",
          estimatedTime: "90 hours",
          completed: false,
          rating: 4.7,
          tags: ["clinical", "standard"],
          achievements: ["Clinical Expert"]
        },
        {
          id: "r2",
          title: "Psychology of Projective Tests",
          type: "book",
          author: "Ana Lúcia Prado",
          year: 2018,
          link: "https://www.artmed.com.br/psicologia-dos-testes-projetivos",
          description: "Critical approach with Brazilian context",
          difficulty: "intermediate",
          estimatedTime: "60 hours",
          completed: false,
          rating: 4.5,
          tags: ["contextual", "critical"],
          achievements: ["Cultural Psychologist"]
        },
        {
          id: "r3",
          title: "Inkblot App",
          type: "tool",
          author: "Mobile",
          link: "https://apps.apple.com/us/app/inkblot-rorschach-test/id123456789",
          description: "Interactive app for demonstrating the blots",
          difficulty: "beginner",
          estimatedTime: "10 hours",
          completed: false,
          rating: 4.3,
          tags: ["mobile", "interactive"],
          achievements: ["Tech Psychologist"]
        }
      ]
    },
    {
      id: "mandelbrot",
      title: "Mandelbrot Set",
      description: "The most famous fractal set, defined by zₙ₊₁ = zₙ² + c",
      icon: "🌊",
      color: "bg-cyan-500",
      popularity: 91,
      communityProgress: 85,
      concepts: [
        {
          name: "Mathematical Definition",
          description: "zₙ₊₁ = zₙ² + c, with z₀ = 0 and c ∈ ℂ",
          resource: "The Beauty of Fractals – Peitgen, Richter, Saupe",
          unlocked: true
        },
        {
          name: "Hausdorff Dimension",
          description: "The set has dimension ≈ 2, but fractal boundary of dimension ≈ 1.5",
          resource: "Mandelbrot Set – A Visual Introduction – Benoît B. Mandelbrot",
          unlocked: false
        },
        {
          name: "Infinite Zoom",
          description: "Each 'corner' contains nearly exact copies (self-similarity)",
          resource: "Khan Academy – Fractals and Mandelbrot Sets",
          unlocked: false
        }
      ],
      resources: [
        {
          id: "m1",
          title: "The Beauty of Fractals",
          type: "book",
          author: "Peitgen, Richter, Saupe",
          year: 1992,
          link: "https://www.springer.com/gp/book/9783540158516",
          description: "Classic work with impressive visualizations",
          difficulty: "intermediate",
          estimatedTime: "80 hours",
          completed: false,
          rating: 4.9,
          tags: ["classic", "visual"],
          achievements: ["Fractal Artist"]
        },
        {
          id: "m2",
          title: "The Fractal Geometry of Nature",
          type: "book",
          author: "Benoît B. Mandelbrot",
          year: 1982,
          link: "https://www.amazon.com/Fractal-Geometry-Nature-Benoit-Mandelbrot/dp/0716711869",
          description: "Fundamental book by the creator of fractals",
          difficulty: "intermediate",
          estimatedTime: "70 hours",
          completed: false,
          rating: 4.8,
          tags: ["foundational", "authoritative"],
          achievements: ["Fractal Pioneer"]
        },
        {
          id: "m3",
          title: "Ultra Fractal",
          type: "tool",
          author: "UltraFractal",
          link: "https://www.ultrafractal.com/",
          description: "Advanced software for creating and exploring fractals",
          difficulty: "intermediate",
          estimatedTime: "40 hours",
          completed: false,
          rating: 4.7,
          tags: ["software", "advanced"],
          achievements: ["Digital Artist"]
        }
      ]
    }
  ];

  // Enhanced study plans with collaboration features
  const initialStudyPlans: StudyPlan[] = [
    {
      id: "sp1",
      week: 1,
      title: "Quantum Physics Fundamentals",
      theme: "quantum",
      activities: [
        "Watch 2 MIT OCW lectures",
        "Read Griffiths chapters 1-2",
        "Solve basic exercises"
      ],
      expectedOutcome: "5-page summary of basic principles",
      progress: 0,
      collaborators: ["Alice", "Bob"],
      milestones: [
        { title: "Complete first lecture", achieved: true, date: "2024-01-15" },
        { title: "Finish reading assignment", achieved: false },
        { title: "Submit exercises", achieved: false }
      ]
    },
    {
      id: "sp2",
      week: 2,
      title: "Fractals & Mandelbrot",
      theme: "fractals",
      activities: [
        "Install Python",
        "Generate Mandelbrot and Julia sets",
        "Read Fractals Everywhere (ch. 1-3)"
      ],
      expectedOutcome: "Image gallery + commented code",
      progress: 0,
      collaborators: ["Carol"],
      milestones: [
        { title: "Setup development environment", achieved: false },
        { title: "Generate first fractal", achieved: false },
        { title: "Complete reading", achieved: false }
      ]
    },
    {
      id: "sp3",
      week: 3,
      title: "Hofstadter's Butterfly",
      theme: "hofstadter",
      activities: [
        "Read Hofstadter's 1976 paper",
        "Study 2021 review",
        "Reproduce simulator in Python"
      ],
      expectedOutcome: "Report explaining relationship between magnetic field and fractal spectrum",
      progress: 0,
      collaborators: ["Alice"],
      milestones: [
        { title: "Understand mathematical model", achieved: false },
        { title: "Implement simulation", achieved: false },
        { title: "Write analysis report", achieved: false }
      ]
    },
    {
      id: "sp4",
      week: 4,
      title: "Dimensional Portals (theory)",
      theme: "portals",
      activities: [
        "Study Greene's String Theory chapters",
        "Read Thorne's Wormholes",
        "Watch PBS Space Time videos"
      ],
      expectedOutcome: "2-3 page outline on physical viability of 'portals'",
      progress: 0,
      collaborators: ["Bob", "Carol"],
      milestones: [
        { title: "Complete String Theory reading", achieved: false },
        { title: "Finish Wormholes study", achieved: false },
        { title: "Watch all videos", achieved: false }
      ]
    },
    {
      id: "sp5",
      week: 5,
      title: "Rorschach Test",
      theme: "rorschach",
      activities: [
        "Read Exner's manual",
        "Watch APA webinar",
        "Practice interpreting 5 blots"
      ],
      expectedOutcome: "Interpretation report + validity discussion",
      progress: 0,
      collaborators: ["Carol"],
      milestones: [
        { title: "Complete manual reading", achieved: false },
        { title: "Attend webinar", achieved: false },
        { title: "Practice interpretations", achieved: false }
      ]
    },
    {
      id: "sp6",
      week: 6,
      title: "Integrated Final Project",
      theme: "integration",
      activities: [
        "Choose integration theme",
        "Develop practical project",
        "Prepare presentation"
      ],
      expectedOutcome: "10-15 minute presentation (slides + code)",
      progress: 0,
      collaborators: ["Alice", "Bob", "Carol"],
      milestones: [
        { title: "Select project topic", achieved: false },
        { title: "Complete development", achieved: false },
        { title: "Final presentation", achieved: false }
      ]
    }
  ];

  // Initialize recommendations
  useEffect(() => {
    setStudyPlans(initialStudyPlans);
    
    // Generate personalized recommendations
    const recs: Recommendation[] = [
      {
        id: "rec1",
        type: "resource",
        title: "Quantum Computing Basics",
        description: "Introduction to quantum computing concepts and applications",
        confidence: 92,
        reason: "Based on your interest in Quantum Physics and high completion rate"
      },
      {
        id: "rec2",
        type: "topic",
        title: "Chaos Theory",
        description: "Explore the mathematical study of dynamical systems",
        confidence: 87,
        reason: "Complementary to your Fractals exploration"
      },
      {
        id: "rec3",
        type: "path",
        title: "Advanced Quantum Mechanics",
        description: "Deep dive into advanced quantum concepts and applications",
        confidence: 78,
        reason: "Next logical step after completing Quantum Physics fundamentals"
      }
    ];
    setRecommendations(recs);
  }, []);

  const toggleResourceCompletion = (resourceId: string, topicId: string) => {
    const topic = topics.find(t => t.id === topicId);
    if (topic) {
      const updatedResources = topic.resources.map(resource => 
        resource.id === resourceId 
          ? { ...resource, completed: !resource.completed }
          : resource
      );
      // Update user experience and achievements
      if (!topic.resources.find(r => r.id === resourceId)?.completed) {
        setUserProfile(prev => ({
          ...prev,
          experience: prev.experience + 50,
          level: Math.floor((prev.experience + 50) / 250)
        }));
      }
    }
  };

  const updatePlanProgress = (planId: string, progress: number) => {
    setStudyPlans(prev => prev.map(plan => 
      plan.id === planId ? { ...plan, progress } : plan
    ));
  };

  const updateNotes = (topicId: string, content: string) => {
    setNotes(prev => ({ ...prev, [topicId]: content }));
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-100 text-green-800";
      case "intermediate": return "bg-yellow-100 text-yellow-800";
      case "advanced": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "book": return "📚";
      case "article": return "📄";
      case "course": return "🎓";
      case "video": return "🎬";
      case "tool": return "🔧";
      case "paper": return "📑";
      default: return "📖";
    }
  };

  const getRecommendationIcon = (type: string) => {
    switch (type) {
      case "resource": return "🎯";
      case "topic": return "🌟";
      case "path": return "🛤️";
      default: return "💡";
    }
  };

  const filteredTopics = topics.filter(topic => 
    topic.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    topic.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const currentTopic = topics.find(t => t.id === selectedTopic) || topics[0];

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      {/* Enhanced Header with User Profile */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-4xl font-bold mb-2">Time Portal - Conception Learning Guide</h1>
            <p className="text-muted-foreground mb-4">
              Journey through Quantum Physics, Dimensional Portals, Fractals, and more with enhanced social learning and AI-powered recommendations
            </p>
          </div>
          
          {/* User Profile Card */}
          <Card className="w-80">
            <CardHeader className="pb-3">
              <div className="flex items-center gap-3">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={userProfile.avatar} />
                  <AvatarFallback>{userProfile.avatar}</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-lg">{userProfile.name}</CardTitle>
                  <CardDescription>Level {userProfile.level} • {userProfile.experience} XP</CardDescription>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-muted-foreground">Activity:</span>
                  <span className="font-medium">{userProfile.currentActivity}</span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-muted-foreground">Friends:</span>
                  <span className="font-medium">{userProfile.friends.length}</span>
                </div>
                <div className="flex flex-wrap gap-1">
                  {userProfile.achievements.slice(0, 3).map((achievement, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {achievement}
                    </Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Enhanced Sync Status */}
        <div className="flex items-center gap-6 text-sm mb-6">
          <div className="flex items-center gap-2">
            <div className={`w-3 h-3 rounded-full ${syncStatus.success ? 'bg-green-500' : 'bg-red-500'}`}></div>
            <span>Portal Sync: {syncStatus.success ? 'Active' : 'Error'}</span>
          </div>
          <span>Last sync: {DateUtils.formatDisplay(syncStatus.lastSync, { hour: '2-digit', minute: '2-digit' })}</span>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-blue-500"></div>
            <span>Cloud Backup: Enabled</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-purple-500"></div>
            <span>AI Recommendations: Active</span>
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <Input
          placeholder="Search topics, resources, or concepts..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="max-w-md"
        />
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Portal Overview</TabsTrigger>
          <TabsTrigger value="topics">Knowledge Dimensions</TabsTrigger>
          <TabsTrigger value="plan">Temporal Journey</TabsTrigger>
          <TabsTrigger value="resources">Portal Resources</TabsTrigger>
          <TabsTrigger value="social">Social Hub</TabsTrigger>
          <TabsTrigger value="recommendations">AI Recommendations</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredTopics.map((topic) => (
              <Card key={topic.id} className="cursor-pointer hover:shadow-lg transition-all duration-200 hover:scale-105">
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className={`w-12 h-12 ${topic.color} rounded-full flex items-center justify-center text-2xl`}>
                        {topic.icon}
                      </div>
                      <div>
                        <CardTitle className="text-lg">{topic.title}</CardTitle>
                        <CardDescription className="text-sm">
                          {topic.resources.length} resources
                        </CardDescription>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <Badge variant="outline" className="text-xs">
                        {topic.popularity}% popular
                      </Badge>
                      <div className="text-xs text-muted-foreground">
                        {topic.communityProgress}% complete
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-4">
                    {topic.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <Button 
                      variant="outline" 
                      size="sm" 
                      onClick={() => {
                        setSelectedTopic(topic.id);
                        setActiveTab("topics");
                      }}
                    >
                      Enter Portal
                    </Button>
                    <div className="flex items-center gap-1">
                      {topic.concepts.filter(c => c.unlocked).length}/{topic.concepts.length} concepts
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Enhanced Analytics Dashboard */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mt-6">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Portals Opened</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-blue-600">
                  {topics.reduce((acc, topic) => acc + topic.resources.filter(r => r.completed).length, 0)}
                </div>
                <Progress 
                  value={topics.reduce((acc, topic) => acc + topic.resources.filter(r => r.completed).length, 0) / topics.reduce((acc, topic) => acc + topic.resources.length, 0) * 100} 
                  className="mt-2"
                />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Dimensions Explored</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">
                  {topics.length}
                </div>
                <Progress 
                  value={topics.filter(t => t.resources.some(r => r.completed)).length / topics.length * 100} 
                  className="mt-2"
                />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Journey Progress</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-purple-600">
                  {Math.round(topics.reduce((acc, topic) => acc + topic.resources.filter(r => r.completed).length / topic.resources.length, 0) / topics.length * 100)}%
                </div>
                <Progress 
                  value={topics.reduce((acc, topic) => acc + topic.resources.filter(r => r.completed).length / topic.resources.length, 0) / topics.length * 100} 
                  className="mt-2"
                />
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm">Experience Points</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-orange-600">
                  {userProfile.experience}
                </div>
                <div className="text-sm text-muted-foreground mt-1">
                  Level {userProfile.level}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="topics" className="mt-6">
          <div className="flex gap-4 mb-6">
            <Select value={selectedTopic} onValueChange={setSelectedTopic}>
              <SelectTrigger className="w-64">
                <SelectValue placeholder="Select a dimension" />
              </SelectTrigger>
              <SelectContent>
                {topics.map((topic) => (
                  <SelectItem key={topic.id} value={topic.id}>
                    {topic.icon} {topic.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Switch 
              checked={showCompleted}
              onCheckedChange={setShowCompleted}
            />
            <span className="text-sm">Show completed portals</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <div className={`w-8 h-8 ${currentTopic.color} rounded-full flex items-center justify-center`}>
                    {currentTopic.icon}
                  </div>
                  {currentTopic.title}
                </CardTitle>
                <CardDescription>
                  {currentTopic.description}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-medium mb-2">Core Concepts</h4>
                    <div className="space-y-2">
                      {currentTopic.concepts.map((concept, index) => (
                        <div key={index} className={`p-3 rounded-lg border ${concept.unlocked ? 'bg-muted' : 'bg-muted/50 opacity-60'}`}>
                          <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${concept.unlocked ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                            <div className="font-medium text-sm">{concept.name}</div>
                            {!concept.unlocked && <Lock className="w-3 h-3 text-gray-400" />}
                          </div>
                          <div className="text-xs text-muted-foreground mt-1">
                            {concept.description}
                          </div>
                          <div className="text-xs text-blue-600 mt-1">
                            Portal: {concept.resource}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-medium mb-2">Community Progress</h4>
                    <div className="flex items-center gap-2">
                      <Progress value={currentTopic.communityProgress} className="flex-1" />
                      <span className="text-sm font-medium">{currentTopic.communityProgress}%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Portal Resources</CardTitle>
                <CardDescription>
                  Learning materials for {currentTopic.title}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-96">
                  <div className="space-y-3">
                    {currentTopic.resources
                      .filter(resource => showCompleted || !resource.completed)
                      .map((resource) => (
                        <div key={resource.id} className="p-3 border rounded-lg hover:shadow-md transition-shadow">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-1">
                                <span>{getTypeIcon(resource.type)}</span>
                                <span className="font-medium text-sm">{resource.title}</span>
                                <Badge className={getDifficultyColor(resource.difficulty)}>
                                  {resource.difficulty}
                                </Badge>
                                {resource.rating && (
                                  <Badge variant="outline" className="text-xs">
                                    ⭐ {resource.rating}
                                  </Badge>
                                )}
                              </div>
                              <div className="text-xs text-muted-foreground mb-1">
                                {resource.author} {resource.year && `(${resource.year})`}
                              </div>
                              <div className="text-xs text-muted-foreground mb-2">
                                {resource.description}
                              </div>
                              <div className="flex items-center gap-4 text-xs">
                                <span className="text-blue-600">⏱️ {resource.estimatedTime}</span>
                                {resource.tags && (
                                  <div className="flex gap-1">
                                    {resource.tags.slice(0, 2).map((tag, index) => (
                                      <Badge key={index} variant="secondary" className="text-xs">
                                        {tag}
                                      </Badge>
                                    ))}
                                  </div>
                                )}
                              </div>
                              {resource.achievements && resource.achievements.length > 0 && (
                                <div className="flex gap-1 mt-2">
                                  {resource.achievements.map((achievement, index) => (
                                    <Badge key={index} variant="outline" className="text-xs">
                                      🏆 {achievement}
                                    </Badge>
                                  ))}
                                </div>
                              )}
                            </div>
                            <Switch
                              checked={resource.completed}
                              onCheckedChange={() => toggleResourceCompletion(resource.id, currentTopic.id)}
                            />
                          </div>
                          {resource.link && (
                            <Button 
                              variant="ghost" 
                              size="sm" 
                              className="mt-2 p-0 h-auto text-xs"
                              onClick={() => window.open(resource.link, '_blank')}
                            >
                              Open Resource →
                            </Button>
                          )}
                        </div>
                      ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>

          {/* Notes Section */}
          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Temporal Notes</CardTitle>
              <CardDescription>
                Personal notes for {currentTopic.title}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Textarea
                placeholder="Add your notes, insights, and discoveries..."
                value={notes[currentTopic.id] || ''}
                onChange={(e) => updateNotes(currentTopic.id, e.target.value)}
                rows={4}
              />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="plan" className="mt-6">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Temporal Journey Plan</CardTitle>
                <CardDescription>
                  Your 6-week journey through the Time Portal dimensions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {studyPlans.map((plan) => (
                    <Card key={plan.id} className="border-l-4 border-l-blue-500">
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="text-lg">Week {plan.week}: {plan.title}</CardTitle>
                            <CardDescription>
                              Theme: {topics.find(t => t.id === plan.theme)?.title || plan.theme}
                            </CardDescription>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-medium">{plan.progress}% Complete</div>
                            <Progress value={plan.progress} className="w-24 mt-1" />
                          </div>
                        </div>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div>
                            <h5 className="font-medium mb-2">Activities:</h5>
                            <ul className="list-disc list-inside text-sm text-muted-foreground space-y-1">
                              {plan.activities.map((activity, index) => (
                                <li key={index}>{activity}</li>
                              ))}
                            </ul>
                          </div>
                          
                          <div>
                            <h5 className="font-medium mb-2">Expected Outcome:</h5>
                            <p className="text-sm text-muted-foreground">{plan.expectedOutcome}</p>
                          </div>
                          
                          {plan.collaborators && plan.collaborators.length > 0 && (
                            <div>
                              <h5 className="font-medium mb-2">Collaborators:</h5>
                              <div className="flex gap-2">
                                {plan.collaborators.map((collaborator, index) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    👤 {collaborator}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          {plan.milestones && plan.milestones.length > 0 && (
                            <div>
                              <h5 className="font-medium mb-2">Milestones:</h5>
                              <div className="space-y-1">
                                {plan.milestones.map((milestone, index) => (
                                  <div key={index} className="flex items-center gap-2 text-sm">
                                    <div className={`w-2 h-2 rounded-full ${milestone.achieved ? 'bg-green-500' : 'bg-gray-300'}`}></div>
                                    <span className={milestone.achieved ? 'text-foreground' : 'text-muted-foreground'}>
                                      {milestone.title}
                                    </span>
                                    {milestone.date && (
                                      <span className="text-xs text-muted-foreground">
                                        ({milestone.date})
                                      </span>
                                    )}
                                  </div>
                                ))}
                              </div>
                            </div>
                          )}
                          
                          <div className="flex items-center gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => updatePlanProgress(plan.id, Math.min(plan.progress + 25, 100))}
                            >
                              Update Progress
                            </Button>
                            <span className="text-xs text-muted-foreground">
                              Last updated: {DateUtils.formatDisplay(new Date(), { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="resources" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>Portal Resources Library</CardTitle>
              <CardDescription>
                Complete collection of all learning materials across all dimensions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-96">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {topics.flatMap(topic => 
                    topic.resources.map(resource => ({
                      ...resource,
                      topic: topic.title,
                      topicIcon: topic.icon,
                      topicColor: topic.color
                    }))
                  ).map((resource, index) => (
                    <Card key={index} className="hover:shadow-md transition-shadow">
                      <CardHeader className="pb-2">
                        <div className="flex items-center gap-2">
                          <span>{resource.topicIcon}</span>
                          <Badge variant="outline" className="text-xs">
                            {resource.topic}
                          </Badge>
                        </div>
                        <CardTitle className="text-sm">{resource.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="text-xs text-muted-foreground">
                            {resource.author} {resource.year && `(${resource.year})`}
                          </div>
                          <div className="flex items-center gap-2">
                            <Badge className={getDifficultyColor(resource.difficulty)}>
                              {resource.difficulty}
                            </Badge>
                            <Badge variant="outline" className="text-xs">
                              {getTypeIcon(resource.type)} {resource.type}
                            </Badge>
                          </div>
                          <div className="text-xs text-muted-foreground">
                            ⏱️ {resource.estimatedTime}
                          </div>
                          <div className="flex items-center justify-between">
                            <Switch
                              checked={resource.completed}
                              onCheckedChange={() => toggleResourceCompletion(resource.id, resource.topic.toLowerCase().replace(' ', ''))}
                            />
                            {resource.link && (
                              <Button 
                                variant="ghost" 
                                size="sm" 
                                className="p-0 h-auto text-xs"
                                onClick={() => window.open(resource.link, '_blank')}
                              >
                                Open →
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="social" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Friends Activity</CardTitle>
                <CardDescription>
                  See what your friends are learning
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {userProfile.friends.map((friend, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                      <Avatar>
                        <AvatarFallback>👤</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="font-medium text-sm">{friend}</div>
                        <div className="text-xs text-muted-foreground">
                          {index === 0 ? "Currently studying Quantum Physics" :
                           index === 1 ? "Completed Fractals module" :
                           "Exploring Dimensional Portals"}
                        </div>
                      </div>
                      <Button variant="outline" size="sm">
                        Connect
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Community Discussions</CardTitle>
                <CardDescription>
                  Join discussions with other time travelers
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Avatar className="w-6 h-6">
                        <AvatarFallback>🔬</AvatarFallback>
                      </Avatar>
                      <span className="font-medium text-sm">Dr. Smith</span>
                      <Badge variant="outline" className="text-xs">Quantum Physics</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      Just discovered an amazing visualization of the double-slit experiment. Anyone interested in collaborating on a interactive demo?
                    </p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span>2 hours ago</span>
                      <span>5 replies</span>
                      <span>12 likes</span>
                    </div>
                  </div>
                  
                  <div className="p-3 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Avatar className="w-6 h-6">
                        <AvatarFallback>🎨</AvatarFallback>
                      </Avatar>
                      <span className="font-medium text-sm">Artist_Pro</span>
                      <Badge variant="outline" className="text-xs">Fractals</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      Created a new Mandelbrot zoom animation with custom color mapping. Check it out!
                    </p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span>5 hours ago</span>
                      <span>8 replies</span>
                      <span>24 likes</span>
                    </div>
                  </div>
                  
                  <div className="p-3 border rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Avatar className="w-6 h-6">
                        <AvatarFallback>🌀</AvatarFallback>
                      </Avatar>
                      <span className="font-medium text-sm">PortalExplorer</span>
                      <Badge variant="outline" className="text-xs">Dimensional Portals</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      Looking for study partners for the String Theory module. Who's interested?
                    </p>
                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span>1 day ago</span>
                      <span>15 replies</span>
                      <span>31 likes</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="recommendations" className="mt-6">
          <Card>
            <CardHeader>
              <CardTitle>AI-Powered Recommendations</CardTitle>
              <CardDescription>
                Personalized suggestions based on your learning journey and interests
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {recommendations.map((rec) => (
                  <Card key={rec.id} className="hover:shadow-md transition-shadow">
                    <CardHeader className="pb-2">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{getRecommendationIcon(rec.type)}</span>
                        <Badge variant="outline" className="text-xs">
                          {rec.type}
                        </Badge>
                        <Badge variant="secondary" className="text-xs">
                          {rec.confidence}% match
                        </Badge>
                      </div>
                      <CardTitle className="text-sm">{rec.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-xs text-muted-foreground mb-3">
                        {rec.description}
                      </p>
                      <div className="space-y-2">
                        <div className="text-xs">
                          <span className="font-medium">Why recommended:</span>
                          <p className="text-muted-foreground">{rec.reason}</p>
                        </div>
                        <Button variant="outline" size="sm" className="w-full">
                          Explore Recommendation
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Lock icon component
function Lock({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
    </svg>
  );
}