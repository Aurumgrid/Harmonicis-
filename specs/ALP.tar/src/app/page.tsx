"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import DateUtils from "@/lib/date-utils";
import { useDateSync } from "@/hooks/useDateSync";

interface UserProfile {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  level: number;
  xp: number;
  totalXp: number;
  streak: number;
  bio?: string;
}

interface LearningPath {
  id: string;
  title: string;
  description: string;
  category: string;
  difficulty: "BEGINNER" | "INTERMEDIATE" | "ADVANCED" | "EXPERT";
  duration: number;
  progress: number;
  enrolled: boolean;
  tags: string[];
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  category: string;
  rarity: "COMMON" | "RARE" | "EPIC" | "LEGENDARY" | "MYTHIC";
  unlocked: boolean;
  icon?: string;
}

interface Activity {
  id: string;
  type: string;
  title: string;
  description?: string;
  timestamp: string;
  isPublic: boolean;
}

interface Friend {
  id: string;
  name: string;
  avatar?: string;
  level: number;
  status: "ONLINE" | "OFFLINE" | "BUSY";
  lastActive: string;
}

export default function TimePortalConception() {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [learningPaths, setLearningPaths] = useState<LearningPath[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [activities, setActivities] = useState<Activity[]>([]);
  const [friends, setFriends] = useState<Friend[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [showNotifications, setShowNotifications] = useState(false);

  // Date synchronization hook
  const { 
    syncStatus, 
    nodesNeedingSync, 
    uploadsNeedingSync, 
    isSyncing,
    performManualSync
  } = useDateSync({ 
    interval: 30000,
    autoSync: true 
  });

  // Initialize demo data
  useEffect(() => {
    // Mock user profile
    setUserProfile({
      id: "1",
      name: "Alex Quantum",
      email: "alex@timeportal.com",
      avatar: "/api/placeholder/40/40",
      level: 12,
      xp: 2450,
      totalXp: 8900,
      streak: 7,
      bio: "Quantum computing enthusiast and temporal explorer"
    });

    // Mock learning paths
    setLearningPaths([
      {
        id: "1",
        title: "Quantum Computing Fundamentals",
        description: "Master the basics of quantum computing and qubit manipulation",
        category: "Quantum",
        difficulty: "BEGINNER",
        duration: 120,
        progress: 65,
        enrolled: true,
        tags: ["quantum", "computing", "fundamentals"]
      },
      {
        id: "2",
        title: "Temporal Synchronization",
        description: "Advanced techniques for temporal data coordination",
        category: "Temporal",
        difficulty: "INTERMEDIATE",
        duration: 180,
        progress: 30,
        enrolled: true,
        tags: ["temporal", "synchronization", "advanced"]
      },
      {
        id: "3",
        title: "Aurum Grid Integration",
        description: "Learn to work with the Aurum Grid system",
        category: "Aurum",
        difficulty: "ADVANCED",
        duration: 240,
        progress: 0,
        enrolled: false,
        tags: ["aurum", "grid", "integration"]
      },
      {
        id: "4",
        title: "Harmonic Node Management",
        description: "Optimize and manage harmonic node networks",
        category: "Harmonic",
        difficulty: "EXPERT",
        duration: 300,
        progress: 0,
        enrolled: false,
        tags: ["harmonic", "nodes", "management"]
      }
    ]);

    // Mock achievements
    setAchievements([
      {
        id: "1",
        name: "First Steps",
        description: "Complete your first learning module",
        category: "Learning",
        rarity: "COMMON",
        unlocked: true
      },
      {
        id: "2",
        name: "Week Warrior",
        description: "Maintain a 7-day learning streak",
        category: "Streak",
        rarity: "RARE",
        unlocked: true
      },
      {
        id: "3",
        name: "Quantum Pioneer",
        description: "Complete the Quantum Computing path",
        category: "Learning",
        rarity: "EPIC",
        unlocked: false
      },
      {
        id: "4",
        name: "Social Butterfly",
        description: "Connect with 10 friends",
        category: "Social",
        rarity: "COMMON",
        unlocked: false
      },
      {
        id: "5",
        name: "Temporal Master",
        description: "Achieve mastery in temporal synchronization",
        category: "Milestone",
        rarity: "LEGENDARY",
        unlocked: false
      },
      {
        id: "6",
        name: "Seasonal Champion",
        description: "Top performer in seasonal event",
        category: "Seasonal",
        rarity: "MYTHIC",
        unlocked: false
      }
    ]);

    // Mock activities
    setActivities([
      {
        id: "1",
        type: "COMPLETION",
        title: "Completed Quantum Basics Module",
        description: "Finished the introductory module with 95% score",
        timestamp: DateUtils.addTime(DateUtils.now(), -2, 'hours'),
        isPublic: true
      },
      {
        id: "2",
        type: "ACHIEVEMENT",
        title: "Unlocked Week Warrior",
        description: "Maintained a 7-day learning streak!",
        timestamp: DateUtils.addTime(DateUtils.now(), -5, 'hours'),
        isPublic: true
      },
      {
        id: "3",
        type: "ENROLLMENT",
        title: "Enrolled in Temporal Synchronization",
        description: "Started the advanced temporal coordination course",
        timestamp: DateUtils.addTime(DateUtils.now(), -1, 'days'),
        isPublic: true
      },
      {
        id: "4",
        type: "RANK_UP",
        title: "Level Up!",
        description: "Reached level 12 - Quantum Explorer",
        timestamp: DateUtils.addTime(DateUtils.now(), -2, 'days'),
        isPublic: true
      }
    ]);

    // Mock friends
    setFriends([
      {
        id: "1",
        name: "Sarah Temporal",
        avatar: "/api/placeholder/40/40",
        level: 15,
        status: "ONLINE",
        lastActive: DateUtils.now()
      },
      {
        id: "2",
        name: "Mike Quantum",
        avatar: "/api/placeholder/40/40",
        level: 10,
        status: "OFFLINE",
        lastActive: DateUtils.addTime(DateUtils.now(), -30, 'minutes')
      },
      {
        id: "3",
        name: "Emma Harmonic",
        avatar: "/api/placeholder/40/40",
        level: 18,
        status: "BUSY",
        lastActive: DateUtils.now()
      },
      {
        id: "4",
        name: "David Aurum",
        avatar: "/api/placeholder/40/40",
        level: 8,
        status: "ONLINE",
        lastActive: DateUtils.now()
      }
    ]);
  }, []);

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "COMMON": return "bg-gray-500";
      case "RARE": return "bg-blue-500";
      case "EPIC": return "bg-purple-500";
      case "LEGENDARY": return "bg-yellow-500";
      case "MYTHIC": return "bg-gradient-to-r from-purple-500 to-pink-500";
      default: return "bg-gray-500";
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "BEGINNER": return "bg-green-500";
      case "INTERMEDIATE": return "bg-yellow-500";
      case "ADVANCED": return "bg-orange-500";
      case "EXPERT": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ONLINE": return "bg-green-500";
      case "OFFLINE": return "bg-gray-500";
      case "BUSY": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  const filteredPaths = learningPaths.filter(path => {
    const matchesSearch = path.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         path.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = filterCategory === "all" || path.category.toLowerCase() === filterCategory.toLowerCase();
    return matchesSearch && matchesCategory;
  });

  const unlockedAchievements = achievements.filter(a => a.unlocked).length;
  const totalAchievements = achievements.length;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container mx-auto p-6 max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Time Portal Conception
              </h1>
              <p className="text-muted-foreground text-lg">
                Advanced Learning Platform with AI Recommendations & Gamification
              </p>
            </div>
            <div className="flex items-center gap-4">
              <Button 
                onClick={performManualSync}
                disabled={isSyncing}
                variant="outline"
                size="sm"
              >
                {isSyncing ? 'Syncing...' : 'Sync Now'}
              </Button>
              <div className="relative">
                <Button 
                  variant="outline" 
                  size="sm"
                  onClick={() => setShowNotifications(!showNotifications)}
                >
                  🔔
                </Button>
                {showNotifications && (
                  <Card className="absolute right-0 top-12 w-80 z-50">
                    <CardHeader className="pb-2">
                      <CardTitle className="text-sm">Notifications</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div className="text-sm">
                          <div className="font-medium">New Achievement Unlocked!</div>
                          <div className="text-muted-foreground">Week Warrior - 7 day streak</div>
                        </div>
                        <div className="text-sm">
                          <div className="font-medium">Friend Request</div>
                          <div className="text-muted-foreground">Sarah Temporal wants to connect</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </div>

          {/* User Profile Summary */}
          {userProfile && (
            <Card className="mb-6">
              <CardContent className="p-6">
                <div className="flex items-center gap-6">
                  <Avatar className="w-20 h-20">
                    <AvatarImage src={userProfile.avatar} />
                    <AvatarFallback>{userProfile.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1">
                    <div className="flex items-center gap-4 mb-2">
                      <h2 className="text-2xl font-bold">{userProfile.name}</h2>
                      <Badge variant="secondary">Level {userProfile.level}</Badge>
                      <Badge variant="outline">🔥 {userProfile.streak} day streak</Badge>
                    </div>
                    <p className="text-muted-foreground mb-4">{userProfile.bio}</p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <div className="text-sm text-muted-foreground">Current XP</div>
                        <div className="text-xl font-bold">{userProfile.xp.toLocaleString()} XP</div>
                        <Progress value={(userProfile.xp % 1000) / 10} className="mt-1" />
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Total XP</div>
                        <div className="text-xl font-bold">{userProfile.totalXp.toLocaleString()} XP</div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground">Achievements</div>
                        <div className="text-xl font-bold">{unlockedAchievements}/{totalAchievements}</div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="learning">Learning Paths</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="social">Social</TabsTrigger>
            <TabsTrigger value="library">Library</TabsTrigger>
            <TabsTrigger value="terminal">Terminal</TabsTrigger>
          </TabsList>

          <TabsContent value="dashboard" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Continue Learning */}
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle>Continue Learning</CardTitle>
                  <CardDescription>Your active learning paths</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {learningPaths.filter(p => p.enrolled && p.progress > 0).map((path) => (
                      <div key={path.id} className="border rounded-lg p-4">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold">{path.title}</h3>
                          <Badge variant="outline">{path.category}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">{path.description}</p>
                        <div className="flex items-center gap-4">
                          <div className="flex-1">
                            <div className="flex justify-between text-sm mb-1">
                              <span>Progress</span>
                              <span>{path.progress}%</span>
                            </div>
                            <Progress value={path.progress} />
                          </div>
                          <Button size="sm">Continue</Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>Your latest achievements and progress</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-4">
                      {activities.map((activity) => (
                        <div key={activity.id} className="border-l-4 border-blue-500 pl-4">
                          <div className="font-medium text-sm">{activity.title}</div>
                          <div className="text-xs text-muted-foreground mb-1">{activity.description}</div>
                          <div className="text-xs text-muted-foreground">
                            {DateUtils.formatDisplay(activity.timestamp, { 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })}
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>

            {/* Sync Status */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>System Status</CardTitle>
                <CardDescription>Temporal synchronization and system health</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className={`w-3 h-3 rounded-full mx-auto mb-2 ${syncStatus.success ? 'bg-green-500' : 'bg-red-500'}`}></div>
                    <div className="font-medium">Sync Status</div>
                    <div className="text-sm text-muted-foreground">
                      {syncStatus.success ? 'Active' : 'Error'}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold mb-2">{nodesNeedingSync.length}</div>
                    <div className="font-medium">Nodes Needing Sync</div>
                    <div className="text-sm text-muted-foreground">
                      {nodesNeedingSync.length === 0 ? 'All synced' : 'Action needed'}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold mb-2">{uploadsNeedingSync.length}</div>
                    <div className="font-medium">Uploads Needing Sync</div>
                    <div className="text-sm text-muted-foreground">
                      {uploadsNeedingSync.length === 0 ? 'All synced' : 'Pending'}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-lg font-semibold mb-2">
                      {DateUtils.formatDisplay(syncStatus.lastSync, { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </div>
                    <div className="font-medium">Last Sync</div>
                    <div className="text-sm text-muted-foreground">
                      Next: {DateUtils.formatDisplay(syncStatus.nextSync, { 
                        hour: '2-digit', 
                        minute: '2-digit' 
                      })}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="learning" className="mt-6">
            <div className="mb-6">
              <div className="flex flex-col md:flex-row gap-4">
                <Input
                  placeholder="Search learning paths..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="flex-1"
                />
                <Select value={filterCategory} onValueChange={setFilterCategory}>
                  <SelectTrigger className="w-full md:w-48">
                    <SelectValue placeholder="Filter by category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="quantum">Quantum</SelectItem>
                    <SelectItem value="temporal">Temporal</SelectItem>
                    <SelectItem value="aurum">Aurum</SelectItem>
                    <SelectItem value="harmonic">Harmonic</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredPaths.map((path) => (
                <Card key={path.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{path.title}</CardTitle>
                      <div className="flex gap-2">
                        <Badge variant="outline">{path.category}</Badge>
                        <div className={`w-2 h-2 rounded-full ${getDifficultyColor(path.difficulty)}`}></div>
                      </div>
                    </div>
                    <CardDescription>{path.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between text-sm">
                        <span>Duration: {path.duration} min</span>
                        <span>Difficulty: {path.difficulty}</span>
                      </div>
                      {path.enrolled && (
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Progress</span>
                            <span>{path.progress}%</span>
                          </div>
                          <Progress value={path.progress} />
                        </div>
                      )}
                      <div className="flex flex-wrap gap-1">
                        {path.tags.map((tag, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                      <Button 
                        className="w-full" 
                        variant={path.enrolled ? "outline" : "default"}
                      >
                        {path.enrolled ? "Continue Learning" : "Enroll Now"}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="achievements" className="mt-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {achievements.map((achievement) => (
                <Card key={achievement.id} className={`${achievement.unlocked ? '' : 'opacity-50'}`}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className={`w-4 h-4 rounded-full ${getRarityColor(achievement.rarity)}`}></div>
                      <Badge variant="outline">{achievement.rarity}</Badge>
                    </div>
                    <CardTitle className="text-lg">{achievement.name}</CardTitle>
                    <CardDescription>{achievement.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center justify-between">
                      <Badge variant="outline">{achievement.category}</Badge>
                      {achievement.unlocked ? (
                        <Badge variant="default">Unlocked</Badge>
                      ) : (
                        <Badge variant="secondary">Locked</Badge>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="social" className="mt-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Friends List */}
              <Card>
                <CardHeader>
                  <CardTitle>Friends</CardTitle>
                  <CardDescription>Your learning companions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {friends.map((friend) => (
                      <div key={friend.id} className="flex items-center gap-4">
                        <Avatar>
                          <AvatarImage src={friend.avatar} />
                          <AvatarFallback>{friend.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="font-medium">{friend.name}</div>
                          <div className="text-sm text-muted-foreground">Level {friend.level}</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${getStatusColor(friend.status)}`}></div>
                          <span className="text-sm text-muted-foreground">{friend.status}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Activity Feed */}
              <Card>
                <CardHeader>
                  <CardTitle>Activity Feed</CardTitle>
                  <CardDescription>What your friends are learning</CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-4">
                      <div className="border-l-4 border-green-500 pl-4">
                        <div className="font-medium text-sm">Sarah Temporal completed Quantum Basics</div>
                        <div className="text-xs text-muted-foreground">2 hours ago</div>
                      </div>
                      <div className="border-l-4 border-blue-500 pl-4">
                        <div className="font-medium text-sm">Mike Quantum started Temporal Synchronization</div>
                        <div className="text-xs text-muted-foreground">5 hours ago</div>
                      </div>
                      <div className="border-l-4 border-purple-500 pl-4">
                        <div className="font-medium text-sm">Emma Harmonic unlocked Quantum Pioneer</div>
                        <div className="text-xs text-muted-foreground">1 day ago</div>
                      </div>
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="library" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Learning Library</CardTitle>
                <CardDescription>Your personal collection of learning resources</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  <Card className="border-dashed border-2">
                    <CardContent className="p-6 text-center">
                      <div className="text-4xl mb-2">📝</div>
                      <div className="font-medium">Notes</div>
                      <div className="text-sm text-muted-foreground">12 items</div>
                    </CardContent>
                  </Card>
                  <Card className="border-dashed border-2">
                    <CardContent className="p-6 text-center">
                      <div className="text-4xl mb-2">🔖</div>
                      <div className="font-medium">Bookmarks</div>
                      <div className="text-sm text-muted-foreground">8 items</div>
                    </CardContent>
                  </Card>
                  <Card className="border-dashed border-2">
                    <CardContent className="p-6 text-center">
                      <div className="text-4xl mb-2">📚</div>
                      <div className="font-medium">Resources</div>
                      <div className="text-sm text-muted-foreground">25 items</div>
                    </CardContent>
                  </Card>
                  <Card className="border-dashed border-2">
                    <CardContent className="p-6 text-center">
                      <div className="text-4xl mb-2">🏆</div>
                      <div className="font-medium">Certificates</div>
                      <div className="text-sm text-muted-foreground">3 items</div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="terminal" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Time Terminal</CardTitle>
                <CardDescription>Multi-session temporal command interface</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="bg-black text-green-400 p-4 rounded-lg font-mono text-sm h-96 overflow-y-auto">
                  <div className="mb-2">
                    <span className="text-blue-400">time-portal@conception:~$</span> quantum-sync --status
                  </div>
                  <div className="mb-2 ml-4">
                    Quantum Nodes: 4/4 synchronized
                  </div>
                  <div className="mb-2 ml-4">
                    Temporal Coherence: 98.7%
                  </div>
                  <div className="mb-2 ml-4">
                    Last Sync: 2024-01-15T14:30:25Z
                  </div>
                  <div className="mb-2">
                    <span className="text-blue-400">time-portal@conception:~$</span> aurum-grid --list-nodes
                  </div>
                  <div className="mb-2 ml-4">
                    Node ID: AQ-001 | Status: ACTIVE | Coherence: 0.96
                  </div>
                  <div className="mb-2 ml-4">
                    Node ID: AQ-002 | Status: ACTIVE | Coherence: 0.94
                  </div>
                  <div className="mb-2 ml-4">
                    Node ID: AQ-003 | Status: SYNCING | Coherence: 0.87
                  </div>
                  <div className="mb-2">
                    <span className="text-blue-400">time-portal@conception:~$</span> _
                  </div>
                  <div className="animate-pulse">█</div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}