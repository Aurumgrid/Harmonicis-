import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import ZAI from 'z-ai-web-dev-sdk';

interface RecommendationRequest {
  userId: string;
  type?: 'learning_path' | 'module' | 'user' | 'content' | 'activity';
  limit?: number;
  context?: {
    currentPath?: string;
    interests?: string[];
    skillLevel?: string;
    recentActivity?: string[];
  };
}

interface Recommendation {
  id: string;
  type: string;
  title: string;
  description: string;
  targetId: string;
  score: number;
  metadata: Record<string, any>;
  reasoning: string;
}

export async function POST(request: NextRequest) {
  try {
    const body: RecommendationRequest = await request.json();
    const { userId, type = 'learning_path', limit = 5, context = {} } = body;

    // Initialize ZAI SDK
    const zai = await ZAI.create();

    // Get user data
    const user = await db.user.findUnique({
      where: { id: userId },
      include: {
        enrollments: {
          include: {
            path: true
          }
        },
        achievements: {
          include: {
            achievement: true
          }
        },
        progress: {
          include: {
            module: {
              include: {
                path: true
              }
            }
          }
        },
        activities: {
          orderBy: { createdAt: 'desc' },
          take: 10
        }
      }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Get all learning paths for recommendations
    const allPaths = await db.learningPath.findMany({
      where: { isActive: true, isPublic: true },
      include: {
        modules: true,
        _count: {
          select: { enrollments: true }
        }
      }
    });

    // Get all users for social recommendations
    const allUsers = await db.user.findMany({
      where: { 
        id: { not: userId },
        lastActive: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) } // Active in last 30 days
      },
      orderBy: { level: 'desc' },
      take: 50
    });

    // Prepare user data for AI analysis
    const userData = {
      level: user.level,
      xp: user.xp,
      totalXp: user.totalXp,
      streak: user.streak,
      completedPaths: user.enrollments.filter(e => e.status === 'COMPLETED').map(e => e.path.title),
      currentPaths: user.enrollments.filter(e => e.status === 'ACTIVE').map(e => ({
        title: e.path.title,
        progress: e.progress,
        category: e.path.category
      })),
      achievements: user.achievements.map(ua => ua.achievement.name),
      recentActivities: user.activities.slice(0, 5).map(a => a.title),
      interests: context.interests || [],
      skillLevel: context.skillLevel || user.level > 10 ? 'advanced' : user.level > 5 ? 'intermediate' : 'beginner'
    };

    // Generate AI recommendations based on type
    let recommendations: Recommendation[] = [];

    switch (type) {
      case 'learning_path':
        recommendations = await generateLearningPathRecommendations(zai, userData, allPaths, limit);
        break;
      case 'user':
        recommendations = await generateUserRecommendations(zai, userData, allUsers, limit);
        break;
      case 'module':
        recommendations = await generateModuleRecommendations(zai, userData, allPaths, limit);
        break;
      case 'content':
        recommendations = await generateContentRecommendations(zai, userData, limit);
        break;
      case 'activity':
        recommendations = await generateActivityRecommendations(zai, userData, limit);
        break;
      default:
        recommendations = await generateLearningPathRecommendations(zai, userData, allPaths, limit);
    }

    // Save recommendations to database
    for (const rec of recommendations) {
      await db.userRecommendation.create({
        data: {
          userId,
          type: rec.type as any,
          title: rec.title,
          description: rec.description,
          targetId: rec.targetId,
          score: rec.score,
          metadata: JSON.stringify({
            ...rec.metadata,
            reasoning: rec.reasoning
          })
        }
      });
    }

    return NextResponse.json({ recommendations });
  } catch (error) {
    console.error('Error generating recommendations:', error);
    return NextResponse.json(
      { error: 'Failed to generate recommendations' },
      { status: 500 }
    );
  }
}

async function generateLearningPathRecommendations(
  zai: any, 
  userData: any, 
  allPaths: any[], 
  limit: number
): Promise<Recommendation[]> {
  // Prepare context for AI
  const context = `
User Profile:
- Level: ${userData.level}
- XP: ${userData.xp}
- Streak: ${userData.streak}
- Skill Level: ${userData.skillLevel}

Current Learning Paths:
${userData.currentPaths.map((p: any) => `- ${p.title} (${p.progress}% complete)`).join('\n')}

Completed Paths:
${userData.completedPaths.join('\n')}

Achievements:
${userData.achievements.join('\n')}

Recent Activities:
${userData.recentActivities.join('\n')}

Available Learning Paths:
${allPaths.map(p => `- ${p.title} (${p.category}, ${p.difficulty}, ${p.duration}min)`).join('\n')}
`;

  const prompt = `
Based on the user profile and learning history above, recommend ${limit} learning paths that would be most suitable for this user.

Consider:
1. User's current skill level and experience
2. Progress in existing paths
3. Achievement patterns
4. Learning interests and goals
5. Path difficulty and duration
6. Category preferences

For each recommendation, provide:
- Title of the learning path
- Brief description of why it's recommended
- Confidence score (0-1)
- Key reasons for recommendation

Format your response as JSON:
{
  "recommendations": [
    {
      "title": "Path Title",
      "description": "Why this path is recommended",
      "score": 0.85,
      "reasoning": "Detailed reasoning..."
    }
  ]
}
`;

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an AI learning recommendation engine. Provide personalized learning path recommendations based on user data and learning patterns.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 1000
    });

    const response = JSON.parse(completion.choices[0]?.message?.content || '{"recommendations": []}');
    
    return response.recommendations.map((rec: any, index: number) => {
      const matchingPath = allPaths.find(p => 
        p.title.toLowerCase().includes(rec.title.toLowerCase()) ||
        rec.title.toLowerCase().includes(p.title.toLowerCase())
      );

      return {
        id: `rec-${Date.now()}-${index}`,
        type: 'learning_path',
        title: rec.title,
        description: rec.description,
        targetId: matchingPath?.id || '',
        score: rec.score,
        metadata: {
          category: matchingPath?.category || '',
          difficulty: matchingPath?.difficulty || '',
          duration: matchingPath?.duration || 0,
          popularity: matchingPath?._count?.enrollments || 0
        },
        reasoning: rec.reasoning
      };
    });
  } catch (error) {
    console.error('Error generating learning path recommendations:', error);
    return [];
  }
}

async function generateUserRecommendations(
  zai: any, 
  userData: any, 
  allUsers: any[], 
  limit: number
): Promise<Recommendation[]> {
  const context = `
Current User:
- Level: ${userData.level}
- XP: ${userData.xp}
- Interests: ${userData.interests.join(', ')}
- Recent Activities: ${userData.recentActivities.join(', ')}

Available Users for Connection:
${allUsers.slice(0, 20).map(u => `- ${u.name} (Level ${u.level}, ${u.bio || 'No bio'})`).join('\n')}
`;

  const prompt = `
Based on the current user's profile and interests, recommend ${limit} users they should connect with for collaborative learning.

Consider:
1. Similar skill levels or complementary skills
2. Shared interests based on activities and bio
3. Learning goals that might align
4. Potential for mentorship or collaboration

For each recommendation, provide:
- User name
- Reason for connection
- Confidence score (0-1)
- Connection type (peer, mentor, collaborator)

Format your response as JSON:
{
  "recommendations": [
    {
      "title": "User Name",
      "description": "Why connect with this user",
      "score": 0.85,
      "reasoning": "Detailed reasoning..."
    }
  ]
}
`;

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an AI social connection recommendation engine. Suggest users for collaborative learning based on profiles and interests.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 800
    });

    const response = JSON.parse(completion.choices[0]?.message?.content || '{"recommendations": []}');
    
    return response.recommendations.map((rec: any, index: number) => {
      const matchingUser = allUsers.find(u => 
        u.name.toLowerCase().includes(rec.title.toLowerCase()) ||
        rec.title.toLowerCase().includes(u.name.toLowerCase())
      );

      return {
        id: `user-rec-${Date.now()}-${index}`,
        type: 'user',
        title: rec.title,
        description: rec.description,
        targetId: matchingUser?.id || '',
        score: rec.score,
        metadata: {
          level: matchingUser?.level || 0,
          mutualInterests: [],
          connectionType: 'peer'
        },
        reasoning: rec.reasoning
      };
    });
  } catch (error) {
    console.error('Error generating user recommendations:', error);
    return [];
  }
}

async function generateModuleRecommendations(
  zai: any, 
  userData: any, 
  allPaths: any[], 
  limit: number
): Promise<Recommendation[]> {
  // Get all modules from all paths
  const allModules = allPaths.flatMap(path => 
    path.modules.map(module => ({
      ...module,
      pathTitle: path.title,
      pathCategory: path.category
    }))
  );

  const context = `
User Profile:
- Level: ${userData.level}
- Current Paths: ${userData.currentPaths.map((p: any) => p.title).join(', ')}

Available Modules:
${allModules.slice(0, 30).map(m => `- ${m.title} (${m.type}, ${m.pathTitle})`).join('\n')}
`;

  const prompt = `
Based on the user's current learning progress, recommend ${limit} specific modules they should focus on next.

Consider:
1. User's current level and skill progression
2. Modules that build on current knowledge
3. Module types that match learning preferences
4. Prerequisites and logical progression

For each recommendation, provide:
- Module title
- Why this module is recommended next
- Confidence score (0-1)
- Learning value

Format your response as JSON:
{
  "recommendations": [
    {
      "title": "Module Title",
      "description": "Why this module is recommended",
      "score": 0.85,
      "reasoning": "Detailed reasoning..."
    }
  ]
}
`;

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an AI learning module recommendation engine. Suggest specific learning modules based on user progress and goals.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 800
    });

    const response = JSON.parse(completion.choices[0]?.message?.content || '{"recommendations": []}');
    
    return response.recommendations.map((rec: any, index: number) => {
      const matchingModule = allModules.find(m => 
        m.title.toLowerCase().includes(rec.title.toLowerCase()) ||
        rec.title.toLowerCase().includes(m.title.toLowerCase())
      );

      return {
        id: `module-rec-${Date.now()}-${index}`,
        type: 'module',
        title: rec.title,
        description: rec.description,
        targetId: matchingModule?.id || '',
        score: rec.score,
        metadata: {
          type: matchingModule?.type || '',
          pathTitle: matchingModule?.pathTitle || '',
          duration: matchingModule?.duration || 0
        },
        reasoning: rec.reasoning
      };
    });
  } catch (error) {
    console.error('Error generating module recommendations:', error);
    return [];
  }
}

async function generateContentRecommendations(
  zai: any, 
  userData: any, 
  limit: number
): Promise<Recommendation[]> {
  const prompt = `
Based on the user's learning profile and interests, recommend ${limit} types of learning content they might find valuable.

User Profile:
- Level: ${userData.level}
- Interests: ${userData.interests.join(', ')}
- Skill Level: ${userData.skillLevel}
- Recent Activities: ${userData.recentActivities.join(', ')}

Recommend content types such as:
- Video tutorials
- Interactive exercises
- Reading materials
- Practice projects
- Quizzes and assessments
- Community discussions

For each recommendation, provide:
- Content type
- Why it's recommended
- Confidence score (0-1)
- Expected benefit

Format your response as JSON:
{
  "recommendations": [
    {
      "title": "Content Type",
      "description": "Why this content type is recommended",
      "score": 0.85,
      "reasoning": "Detailed reasoning..."
    }
  ]
}
`;

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an AI content recommendation engine. Suggest learning content types based on user preferences and learning style.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 800
    });

    const response = JSON.parse(completion.choices[0]?.message?.content || '{"recommendations": []}');
    
    return response.recommendations.map((rec: any, index: number) => ({
      id: `content-rec-${Date.now()}-${index}`,
      type: 'content',
      title: rec.title,
      description: rec.description,
      targetId: '',
      score: rec.score,
      metadata: {
        contentType: rec.title.toLowerCase(),
        difficulty: userData.skillLevel
      },
      reasoning: rec.reasoning
    }));
  } catch (error) {
    console.error('Error generating content recommendations:', error);
    return [];
  }
}

async function generateActivityRecommendations(
  zai: any, 
  userData: any, 
  limit: number
): Promise<Recommendation[]> {
  const prompt = `
Based on the user's learning patterns and goals, recommend ${limit} learning activities they should try next.

User Profile:
- Level: ${userData.level}
- XP: ${userData.xp}
- Streak: ${userData.streak}
- Recent Activities: ${userData.recentActivities.join(', ')}
- Skill Level: ${userData.skillLevel}

Suggest activities such as:
- Daily practice sessions
- Weekly challenges
- Community participation
- Peer review sessions
- Teaching others
- Project work

For each recommendation, provide:
- Activity type
- Why it's recommended
- Confidence score (0-1)
- Expected impact on learning

Format your response as JSON:
{
  "recommendations": [
    {
      "title": "Activity Type",
      "description": "Why this activity is recommended",
      "score": 0.85,
      "reasoning": "Detailed reasoning..."
    }
  ]
}
`;

  try {
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'You are an AI learning activity recommendation engine. Suggest engaging learning activities based on user behavior and goals.'
        },
        {
          role: 'user',
          content: prompt
        }
      ],
      temperature: 0.7,
      max_tokens: 800
    });

    const response = JSON.parse(completion.choices[0]?.message?.content || '{"recommendations": []}');
    
    return response.recommendations.map((rec: any, index: number) => ({
      id: `activity-rec-${Date.now()}-${index}`,
      type: 'activity',
      title: rec.title,
      description: rec.description,
      targetId: '',
      score: rec.score,
      metadata: {
        activityType: rec.title.toLowerCase(),
        frequency: 'daily',
        estimatedTime: 30
      },
      reasoning: rec.reasoning
    }));
  } catch (error) {
    console.error('Error generating activity recommendations:', error);
    return [];
  }
}