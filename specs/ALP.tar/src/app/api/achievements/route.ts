import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';

interface AchievementCheckRequest {
  userId: string;
  activityType?: string;
  activityData?: Record<string, any>;
}

interface AchievementProgress {
  achievementId: string;
  name: string;
  description: string;
  currentProgress: number;
  maxProgress: number;
  percentage: number;
  unlocked: boolean;
  rarity: string;
  category: string;
  xpReward: number;
}

export async function POST(request: NextRequest) {
  try {
    const body: AchievementCheckRequest = await request.json();
    const { userId, activityType, activityData = {} } = body;

    // Get user data with achievements and progress
    const user = await db.user.findUnique({
      where: { id: userId },
      include: {
        achievements: {
          include: {
            achievement: true
          }
        },
        enrollments: true,
        progress: true,
        activities: {
          orderBy: { createdAt: 'desc' },
          take: 100
        }
      }
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // Get all active achievements
    const allAchievements = await db.achievement.findMany({
      where: { isActive: true }
    });

    // Check for new achievements based on activity
    const newlyUnlocked = await checkAndUnlockAchievements(user, allAchievements, activityType, activityData);

    // Get current achievement progress
    const achievementProgress = await calculateAchievementProgress(user, allAchievements);

    // Update user XP from newly unlocked achievements
    if (newlyUnlocked.length > 0) {
      const totalXpReward = newlyUnlocked.reduce((sum, ach) => sum + ach.xpReward, 0);
      await updateUserXP(userId, totalXpReward);
    }

    return NextResponse.json({
      newlyUnlocked,
      achievementProgress,
      totalAchievements: allAchievements.length,
      unlockedAchievements: user.achievements.length + newlyUnlocked.length
    });

  } catch (error) {
    console.error('Error checking achievements:', error);
    return NextResponse.json(
      { error: 'Failed to check achievements' },
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const userId = searchParams.get('userId');
    const category = searchParams.get('category');

    if (!userId) {
      return NextResponse.json({ error: 'User ID required' }, { status: 400 });
    }

    const whereClause: any = { isActive: true };
    if (category && category !== 'all') {
      whereClause.category = category.toUpperCase();
    }

    // Get achievements with user progress
    const achievements = await db.achievement.findMany({
      where: whereClause,
      include: {
        userAchievements: {
          where: { userId },
          select: {
            unlockedAt: true,
            progress: true
          }
        }
      },
      orderBy: [
        { rarity: 'asc' },
        { category: 'asc' }
      ]
    });

    const formattedAchievements = achievements.map(ach => {
      const userAchievement = ach.userAchievements[0];
      return {
        id: ach.id,
        name: ach.name,
        description: ach.description,
        icon: ach.icon,
        category: ach.category,
        rarity: ach.rarity,
        xpReward: ach.xpReward,
        unlocked: !!userAchievement,
        unlockedAt: userAchievement?.unlockedAt,
        progress: userAchievement?.progress || 0,
        isSecret: ach.isSecret
      };
    });

    // Get seasonal achievements if requested
    let seasonalAchievements = [];
    if (!category || category === 'seasonal') {
      seasonalAchievements = await getSeasonalAchievements(userId);
    }

    return NextResponse.json({
      achievements: formattedAchievements,
      seasonalAchievements,
      categories: await getAchievementCategories()
    });

  } catch (error) {
    console.error('Error fetching achievements:', error);
    return NextResponse.json(
      { error: 'Failed to fetch achievements' },
      { status: 500 }
    );
  }
}

async function checkAndUnlockAchievements(
  user: any,
  allAchievements: any[],
  activityType?: string,
  activityData?: Record<string, any>
): Promise<any[]> {
  const newlyUnlocked: any[] = [];
  const existingAchievementIds = user.achievements.map(ua => ua.achievementId);

  for (const achievement of allAchievements) {
    // Skip if already unlocked
    if (existingAchievementIds.includes(achievement.id)) {
      continue;
    }

    // Skip secret achievements that shouldn't be checked automatically
    if (achievement.isSecret && !activityData?.forceCheck) {
      continue;
    }

    const shouldUnlock = await evaluateAchievementConditions(user, achievement, activityType, activityData);
    
    if (shouldUnlock) {
      // Unlock the achievement
      await db.userAchievement.create({
        data: {
          userId: user.id,
          achievementId: achievement.id,
          unlockedAt: new Date(),
          progress: 1
        }
      });

      // Create activity for achievement unlock
      await db.activity.create({
        data: {
          userId: user.id,
          type: 'ACHIEVEMENT',
          title: `Unlocked ${achievement.name}`,
          description: achievement.description,
          isPublic: true,
          metadata: JSON.stringify({
            achievementId: achievement.id,
            rarity: achievement.rarity,
            xpReward: achievement.xpReward
          })
        }
      });

      newlyUnlocked.push(achievement);
    }
  }

  return newlyUnlocked;
}

async function evaluateAchievementConditions(
  user: any,
  achievement: any,
  activityType?: string,
  activityData?: Record<string, any>
): Promise<boolean> {
  try {
    const conditions = JSON.parse(achievement.conditions);
    
    switch (achievement.category) {
      case 'LEARNING':
        return await evaluateLearningAchievements(user, conditions, activityType, activityData);
      case 'STREAK':
        return await evaluateStreakAchievements(user, conditions);
      case 'SOCIAL':
        return await evaluateSocialAchievements(user, conditions, activityType, activityData);
      case 'MILESTONE':
        return await evaluateMilestoneAchievements(user, conditions, activityType, activityData);
      case 'SPECIAL':
        return await evaluateSpecialAchievements(user, conditions, activityType, activityData);
      case 'SEASONAL':
        return await evaluateSeasonalAchievements(user, conditions);
      default:
        return false;
    }
  } catch (error) {
    console.error('Error evaluating achievement conditions:', error);
    return false;
  }
}

async function evaluateLearningAchievements(
  user: any,
  conditions: any,
  activityType?: string,
  activityData?: Record<string, any>
): Promise<boolean> {
  if (conditions.type === 'module_completion') {
    const completedModules = user.progress.filter(p => p.status === 'COMPLETED').length;
    return completedModules >= conditions.count;
  }

  if (conditions.type === 'path_completion') {
    const completedPaths = user.enrollments.filter(e => e.status === 'COMPLETED').length;
    return completedPaths >= conditions.count;
  }

  if (conditions.type === 'total_time') {
    const totalTimeSpent = user.progress.reduce((sum: number, p: any) => sum + p.timeSpent, 0);
    return totalTimeSpent >= conditions.minutes;
  }

  if (conditions.type === 'specific_path' && activityData?.pathId) {
    return activityData.pathId === conditions.pathId && activityData.completed;
  }

  return false;
}

async function evaluateStreakAchievements(
  user: any,
  conditions: any
): Promise<boolean> {
  if (conditions.type === 'daily_streak') {
    return user.streak >= conditions.days;
  }

  if (conditions.type === 'weekly_activity') {
    const oneWeekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const weeklyActivities = user.activities.filter(a => new Date(a.createdAt) >= oneWeekAgo);
    return weeklyActivities.length >= conditions.count;
  }

  return false;
}

async function evaluateSocialAchievements(
  user: any,
  conditions: any,
  activityType?: string,
  activityData?: Record<string, any>
): Promise<boolean> {
  if (conditions.type === 'friends_count') {
    // This would need to query the friends table
    // For now, return false as we don't have the friend count in the user object
    return false;
  }

  if (conditions.type === 'activities_shared') {
    const publicActivities = user.activities.filter(a => a.isPublic).length;
    return publicActivities >= conditions.count;
  }

  return false;
}

async function evaluateMilestoneAchievements(
  user: any,
  conditions: any,
  activityType?: string,
  activityData?: Record<string, any>
): Promise<boolean> {
  if (conditions.type === 'level_reached') {
    return user.level >= conditions.level;
  }

  if (conditions.type === 'total_xp') {
    return user.totalXp >= conditions.xp;
  }

  return false;
}

async function evaluateSpecialAchievements(
  user: any,
  conditions: any,
  activityType?: string,
  activityData?: Record<string, any>
): Promise<boolean> {
  if (conditions.type === 'first_activity' && activityType) {
    const hasPreviousActivities = user.activities.length > 0;
    return !hasPreviousActivities;
  }

  if (conditions.type === 'perfect_score' && activityData?.score) {
    return activityData.score === 100;
  }

  return false;
}

async function evaluateSeasonalAchievements(
  user: any,
  conditions: any
): Promise<boolean> {
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();

  if (conditions.type === 'monthly_champion') {
    // Check if user is top performer this month
    // This would require more complex queries
    return false;
  }

  if (conditions.type === 'seasonal_participant') {
    const seasonStart = new Date(currentYear, Math.floor(currentMonth / 3) * 3, 1);
    const seasonalActivities = user.activities.filter(a => new Date(a.createdAt) >= seasonStart);
    return seasonalActivities.length >= conditions.count;
  }

  return false;
}

async function calculateAchievementProgress(user: any, allAchievements: any[]): Promise<AchievementProgress[]> {
  const progress: AchievementProgress[] = [];
  const existingAchievementIds = user.achievements.map(ua => ua.achievementId);

  for (const achievement of allAchievements) {
    const isUnlocked = existingAchievementIds.includes(achievement.id);
    let currentProgress = 0;
    let maxProgress = 1;

    if (!isUnlocked) {
      // Calculate progress based on achievement type
      try {
        const conditions = JSON.parse(achievement.conditions);
        
        switch (achievement.category) {
          case 'LEARNING':
            if (conditions.type === 'module_completion') {
              currentProgress = user.progress.filter(p => p.status === 'COMPLETED').length;
              maxProgress = conditions.count;
            } else if (conditions.type === 'path_completion') {
              currentProgress = user.enrollments.filter(e => e.status === 'COMPLETED').length;
              maxProgress = conditions.count;
            } else if (conditions.type === 'total_time') {
              currentProgress = user.progress.reduce((sum: number, p: any) => sum + p.timeSpent, 0);
              maxProgress = conditions.minutes;
            }
            break;
          case 'STREAK':
            if (conditions.type === 'daily_streak') {
              currentProgress = user.streak;
              maxProgress = conditions.days;
            }
            break;
          case 'MILESTONE':
            if (conditions.type === 'level_reached') {
              currentProgress = user.level;
              maxProgress = conditions.level;
            } else if (conditions.type === 'total_xp') {
              currentProgress = user.totalXp;
              maxProgress = conditions.xp;
            }
            break;
        }
      } catch (error) {
        console.error('Error calculating progress for achievement:', achievement.id, error);
      }
    } else {
      currentProgress = maxProgress;
    }

    const percentage = Math.min((currentProgress / maxProgress) * 100, 100);

    progress.push({
      achievementId: achievement.id,
      name: achievement.name,
      description: achievement.description,
      currentProgress,
      maxProgress,
      percentage,
      unlocked: isUnlocked,
      rarity: achievement.rarity,
      category: achievement.category,
      xpReward: achievement.xpReward
    });
  }

  return progress;
}

async function updateUserXP(userId: string, xpReward: number) {
  if (xpReward <= 0) return;

  const user = await db.user.findUnique({
    where: { id: userId }
  });

  if (!user) return;

  const newXp = user.xp + xpReward;
  const newTotalXp = user.totalXp + xpReward;
  let newLevel = user.level;

  // Check for level up (1000 XP per level)
  while (newXp >= 1000) {
    newXp -= 1000;
    newLevel++;
  }

  await db.user.update({
    where: { id: userId },
    data: {
      xp: newXp,
      totalXp: newTotalXp,
      level: newLevel
    }
  });

  // Create activity for level up if level changed
  if (newLevel > user.level) {
    await db.activity.create({
      data: {
        userId,
        type: 'RANK_UP',
        title: `Level Up!`,
        description: `Reached level ${newLevel}`,
        isPublic: true,
        metadata: JSON.stringify({
          oldLevel: user.level,
          newLevel,
          xpGained: xpReward
        })
      }
    });
  }
}

async function getSeasonalAchievements(userId: string): Promise<any[]> {
  const now = new Date();
  const currentMonth = now.getMonth();
  const currentYear = now.getFullYear();
  
  // Define seasonal events
  const seasonalEvents = [
    {
      name: "New Year Scholar",
      description: "Start the year with learning momentum",
      month: 0, // January
      icon: "🎆"
    },
    {
      name: "Spring Learner",
      description: "Embrace the season of growth",
      month: 3, // April
      icon: "🌸"
    },
    {
      name: "Summer Scholar",
      description: "Make the most of summer learning",
      month: 6, // July
      icon: "☀️"
    },
    {
      name: "Fall Achiever",
      description: "Harvest the fruits of your learning",
      month: 9, // October
      icon: "🍂"
    },
    {
      name: "Winter Master",
      description: "Master skills during the quiet season",
      month: 11, // December
      icon: "❄️"
    }
  ];

  const currentSeason = seasonalEvents.find(event => event.month === currentMonth);
  
  if (!currentSeason) return [];

  // Check if user has seasonal activity
  const seasonStart = new Date(currentYear, currentMonth, 1);
  const seasonalActivities = await db.activity.count({
    where: {
      userId,
      createdAt: { gte: seasonStart }
    }
  });

  return [{
    id: `seasonal-${currentYear}-${currentMonth}`,
    name: currentSeason.name,
    description: currentSeason.description,
    icon: currentSeason.icon,
    category: 'SEASONAL',
    rarity: 'EPIC',
    xpReward: 500,
    unlocked: seasonalActivities >= 10, // Example condition
    progress: Math.min(seasonalActivities, 10),
    maxProgress: 10,
    isSecret: false,
    seasonal: true
  }];
}

async function getAchievementCategories(): Promise<string[]> {
  const categories = await db.achievement.findMany({
    select: { category: true },
    distinct: ['category'],
    where: { isActive: true }
  });

  return categories.map(c => c.category);
}