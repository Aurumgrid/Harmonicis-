/**
 * React hook for date synchronization
 * Provides real-time date synchronization for harmonic nodes and uploads
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import dateSyncService, { 
  SyncStatus, 
  NodeSyncData, 
  UploadSyncData,
  SyncConfig 
} from '@/services/date-sync-service';

interface UseDateSyncReturn {
  syncStatus: SyncStatus;
  nodesNeedingSync: NodeSyncData[];
  uploadsNeedingSync: UploadSyncData[];
  isSyncing: boolean;
  startSync: () => void;
  stopSync: () => void;
  performManualSync: () => Promise<void>;
  syncNode: (nodeId: string) => Promise<void>;
  syncUpload: (uploadId: string) => Promise<void>;
  updateConfig: (config: Partial<SyncConfig>) => void;
}

export function useDateSync(config?: Partial<SyncConfig>): UseDateSyncReturn {
  const [syncStatus, setSyncStatus] = useState<SyncStatus>(dateSyncService.getStatus());
  const [nodesNeedingSync, setNodesNeedingSync] = useState<NodeSyncData[]>([]);
  const [uploadsNeedingSync, setUploadsNeedingSync] = useState<UploadSyncData[]>([]);
  
  const isSyncing = syncStatus.isSyncing;
  
  // Use refs to avoid stale closures
  const statusCallbackRef = useRef<(status: SyncStatus) => void>();
  const nodeCallbackRef = useRef<(nodes: NodeSyncData[]) => void>();
  const uploadCallbackRef = useRef<(uploads: UploadSyncData[]) => void>();

  // Initialize service
  useEffect(() => {
    if (config) {
      dateSyncService.updateConfig(config);
    }
    
    dateSyncService.initialize();
    
    return () => {
      dateSyncService.destroy();
    };
  }, [config]);

  // Set up status callback
  useEffect(() => {
    statusCallbackRef.current = (status: SyncStatus) => {
      setSyncStatus(status);
    };
    
    const unsubscribe = dateSyncService.onStatusUpdate(statusCallbackRef.current);
    
    return unsubscribe;
  }, []);

  // Set up node sync callback
  useEffect(() => {
    nodeCallbackRef.current = (nodes: NodeSyncData[]) => {
      setNodesNeedingSync(nodes.filter(node => node.syncNeeded));
    };
    
    const unsubscribe = dateSyncService.onNodeSync(nodeCallbackRef.current);
    
    return unsubscribe;
  }, []);

  // Set up upload sync callback
  useEffect(() => {
    uploadCallbackRef.current = (uploads: UploadSyncData[]) => {
      setUploadsNeedingSync(uploads.filter(upload => upload.syncNeeded));
    };
    
    const unsubscribe = dateSyncService.onUploadSync(uploadCallbackRef.current);
    
    return unsubscribe;
  }, []);

  // Action functions
  const startSync = useCallback(() => {
    dateSyncService.startSync();
  }, []);

  const stopSync = useCallback(() => {
    dateSyncService.stopSync();
  }, []);

  const performManualSync = useCallback(async () => {
    await dateSyncService.performSync();
  }, []);

  const syncNode = useCallback(async (nodeId: string) => {
    await dateSyncService.syncNode(nodeId);
  }, []);

  const syncUpload = useCallback(async (uploadId: string) => {
    await dateSyncService.syncUpload(uploadId);
  }, []);

  const updateConfig = useCallback((newConfig: Partial<SyncConfig>) => {
    dateSyncService.updateConfig(newConfig);
  }, []);

  return {
    syncStatus,
    nodesNeedingSync,
    uploadsNeedingSync,
    isSyncing,
    startSync,
    stopSync,
    performManualSync,
    syncNode,
    syncUpload,
    updateConfig
  };
}

/**
 * Hook for checking if a specific date needs synchronization
 */
export function useNeedsSync(lastSync: string | Date, intervalMinutes: number = 5): boolean {
  const [needsSync, setNeedsSync] = useState(false);

  useEffect(() => {
    const checkSync = () => {
      const lastSyncStr = typeof lastSync === 'string' ? lastSync : lastSync.toISOString();
      setNeedsSync(dateSyncService.needsNodeSync(lastSyncStr, intervalMinutes));
    };

    checkSync();
    
    // Check every minute
    const interval = setInterval(checkSync, 60000);
    
    return () => clearInterval(interval);
  }, [lastSync, intervalMinutes]);

  return needsSync;
}

/**
 * Hook for getting formatted time difference
 */
export function useTimeDifference(date: string | Date): {
  milliseconds: number;
  seconds: number;
  minutes: number;
  hours: number;
  days: number;
  humanReadable: string;
} {
  const [timeDiff, setTimeDiff] = useState({
    milliseconds: 0,
    seconds: 0,
    minutes: 0,
    hours: 0,
    days: 0,
    humanReadable: 'just now'
  });

  useEffect(() => {
    const updateTimeDiff = () => {
      const now = new Date();
      const dateObj = typeof date === 'string' ? new Date(date) : date;
      const diff = Math.abs(now.getTime() - dateObj.getTime());
      
      const milliseconds = diff;
      const seconds = Math.floor(diff / 1000);
      const minutes = Math.floor(seconds / 60);
      const hours = Math.floor(minutes / 60);
      const days = Math.floor(hours / 24);

      let humanReadable = '';
      if (days > 0) {
        humanReadable = `${days} day${days > 1 ? 's' : ''} ago`;
      } else if (hours > 0) {
        humanReadable = `${hours} hour${hours > 1 ? 's' : ''} ago`;
      } else if (minutes > 0) {
        humanReadable = `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
      } else if (seconds > 0) {
        humanReadable = `${seconds} second${seconds > 1 ? 's' : ''} ago`;
      } else {
        humanReadable = 'just now';
      }

      setTimeDiff({
        milliseconds,
        seconds,
        minutes,
        hours,
        days,
        humanReadable
      });
    };

    updateTimeDiff();
    
    // Update every second
    const interval = setInterval(updateTimeDiff, 1000);
    
    return () => clearInterval(interval);
  }, [date]);

  return timeDiff;
}