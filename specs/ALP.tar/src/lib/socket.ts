import { Server } from 'socket.io';

interface UserSession {
  userId: string;
  userName: string;
  socketId: string;
  currentRoom?: string;
  joinedAt: Date;
}

interface CollaborationRoom {
  id: string;
  name: string;
  type: 'learning_path' | 'module' | 'study_group' | 'general';
  participants: UserSession[];
  createdAt: Date;
}

const activeUsers = new Map<string, UserSession>();
const activeRooms = new Map<string, CollaborationRoom>();

export const setupSocket = (io: Server) => {
  io.on('connection', (socket) => {
    console.log('Client connected:', socket.id);
    
    // Join rooms for real-time updates
    socket.join('webhooks');
    socket.join('alerts');
    socket.join('channels');
    socket.join('learning');
    socket.join('achievements');
    socket.join('social');
    
    // Handle user authentication and session setup
    socket.on('user:join', (userData: { userId: string; userName: string; avatar?: string }) => {
      const userSession: UserSession = {
        userId: userData.userId,
        userName: userData.userName,
        socketId: socket.id,
        joinedAt: new Date()
      };
      
      activeUsers.set(socket.id, userSession);
      
      // Notify others about new user
      socket.broadcast.emit('user:joined', {
        userId: userData.userId,
        userName: userData.userName,
        avatar: userData.avatar,
        onlineCount: activeUsers.size
      });
      
      // Send current online count to user
      socket.emit('user:session', {
        sessionId: socket.id,
        onlineCount: activeUsers.size,
        activeRooms: Array.from(activeRooms.values())
      });
    });

    // Handle room creation and joining
    socket.on('room:create', (roomData: { name: string; type: CollaborationRoom['type'] }) => {
      const roomId = `room_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      const userSession = activeUsers.get(socket.id);
      
      if (!userSession) return;
      
      const newRoom: CollaborationRoom = {
        id: roomId,
        name: roomData.name,
        type: roomData.type,
        participants: [userSession],
        createdAt: new Date()
      };
      
      activeRooms.set(roomId, newRoom);
      socket.join(roomId);
      userSession.currentRoom = roomId;
      
      socket.emit('room:created', newRoom);
      io.emit('room:list', Array.from(activeRooms.values()));
    });

    socket.on('room:join', (roomId: string) => {
      const room = activeRooms.get(roomId);
      const userSession = activeUsers.get(socket.id);
      
      if (!room || !userSession) return;
      
      // Leave current room if any
      if (userSession.currentRoom) {
        socket.leave(userSession.currentRoom);
        const currentRoom = activeRooms.get(userSession.currentRoom);
        if (currentRoom) {
          currentRoom.participants = currentRoom.participants.filter(p => p.socketId !== socket.id);
          if (currentRoom.participants.length === 0) {
            activeRooms.delete(userSession.currentRoom);
          } else {
            socket.to(userSession.currentRoom).emit('room:user_left', {
              userId: userSession.userId,
              userName: userSession.userName,
              roomId: userSession.currentRoom
            });
          }
        }
      }
      
      // Join new room
      socket.join(roomId);
      userSession.currentRoom = roomId;
      room.participants.push(userSession);
      
      socket.emit('room:joined', room);
      socket.to(roomId).emit('room:user_joined', {
        userId: userSession.userId,
        userName: userSession.userName,
        roomId
      });
    });

    socket.on('room:leave', () => {
      const userSession = activeUsers.get(socket.id);
      if (!userSession || !userSession.currentRoom) return;
      
      const room = activeRooms.get(userSession.currentRoom);
      if (room) {
        room.participants = room.participants.filter(p => p.socketId !== socket.id);
        socket.leave(userSession.currentRoom);
        
        socket.to(userSession.currentRoom).emit('room:user_left', {
          userId: userSession.userId,
          userName: userSession.userName,
          roomId: userSession.currentRoom
        });
        
        if (room.participants.length === 0) {
          activeRooms.delete(userSession.currentRoom);
        }
      }
      
      userSession.currentRoom = undefined;
      socket.emit('room:left');
    });

    // Handle real-time collaboration messages
    socket.on('collaboration:message', (data: {
      roomId: string;
      content: string;
      type: 'text' | 'code' | 'file' | 'drawing';
      metadata?: Record<string, any>;
    }) => {
      const userSession = activeUsers.get(socket.id);
      if (!userSession) return;
      
      const message = {
        id: `msg_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        roomId: data.roomId,
        userId: userSession.userId,
        userName: userSession.userName,
        content: data.content,
        type: data.type,
        metadata: data.metadata || {},
        timestamp: new Date().toISOString()
      };
      
      socket.to(data.roomId).emit('collaboration:message', message);
      socket.emit('collaboration:message_sent', message);
    });

    // Handle real-time code collaboration
    socket.on('code:change', (data: {
      roomId: string;
      code: string;
      language: string;
      cursor?: { line: number; column: number };
    }) => {
      const userSession = activeUsers.get(socket.id);
      if (!userSession) return;
      
      const changeEvent = {
        userId: userSession.userId,
        userName: userSession.userName,
        code: data.code,
        language: data.language,
        cursor: data.cursor,
        timestamp: new Date().toISOString()
      };
      
      socket.to(data.roomId).emit('code:changed', changeEvent);
    });

    // Handle real-time drawing collaboration
    socket.on('drawing:update', (data: {
      roomId: string;
      drawingData: any;
      action: 'start' | 'draw' | 'end';
    }) => {
      const userSession = activeUsers.get(socket.id);
      if (!userSession) return;
      
      const drawingEvent = {
        userId: userSession.userId,
        userName: userSession.userName,
        drawingData: data.drawingData,
        action: data.action,
        timestamp: new Date().toISOString()
      };
      
      socket.to(data.roomId).emit('drawing:updated', drawingEvent);
    });

    // Handle learning progress updates
    socket.on('learning:progress', (data: {
      moduleId: string;
      progress: number;
      timeSpent: number;
    }) => {
      const userSession = activeUsers.get(socket.id);
      if (!userSession) return;
      
      const progressEvent = {
        userId: userSession.userId,
        userName: userSession.userName,
        moduleId: data.moduleId,
        progress: data.progress,
        timeSpent: data.timeSpent,
        timestamp: new Date().toISOString()
      };
      
      // Broadcast to learning room for real-time updates
      io.to('learning').emit('learning:progress_updated', progressEvent);
    });

    // Handle achievement unlocks
    socket.on('achievement:unlocked', (data: {
      achievementId: string;
      achievementName: string;
      rarity: string;
    }) => {
      const userSession = activeUsers.get(socket.id);
      if (!userSession) return;
      
      const achievementEvent = {
        userId: userSession.userId,
        userName: userSession.userName,
        achievementId: data.achievementId,
        achievementName: data.achievementName,
        rarity: data.rarity,
        timestamp: new Date().toISOString()
      };
      
      // Broadcast to achievements room
      io.to('achievements').emit('achievement:unlocked', achievementEvent);
      
      // Also broadcast to user's friends if any
      socket.to('social').emit('friend:achievement', achievementEvent);
    });

    // Handle social interactions
    socket.on('social:activity', (data: {
      type: 'friend_request' | 'message' | 'share' | 'like';
      targetUserId?: string;
      content: string;
    }) => {
      const userSession = activeUsers.get(socket.id);
      if (!userSession) return;
      
      const socialEvent = {
        userId: userSession.userId,
        userName: userSession.userName,
        type: data.type,
        targetUserId: data.targetUserId,
        content: data.content,
        timestamp: new Date().toISOString()
      };
      
      // Broadcast to social room
      io.to('social').emit('social:activity', socialEvent);
      
      // Send to specific user if targetUserId is provided
      if (data.targetUserId) {
        const targetSession = Array.from(activeUsers.values()).find(u => u.userId === data.targetUserId);
        if (targetSession) {
          io.to(targetSession.socketId).emit('social:direct', socialEvent);
        }
      }
    });

    // Handle study session invitations
    socket.on('study:invite', (data: {
      targetUserId: string;
      roomId?: string;
      message: string;
    }) => {
      const userSession = activeUsers.get(socket.id);
      if (!userSession) return;
      
      const invitation = {
        inviterId: userSession.userId,
        inviterName: userSession.userName,
        targetUserId: data.targetUserId,
        roomId: data.roomId,
        message: data.message,
        timestamp: new Date().toISOString()
      };
      
      const targetSession = Array.from(activeUsers.values()).find(u => u.userId === data.targetUserId);
      if (targetSession) {
        io.to(targetSession.socketId).emit('study:invitation', invitation);
      }
    });

    // Handle voice/video call signaling (WebRTC)
    socket.on('call:offer', (data: {
      targetUserId: string;
      offer: any;
      callType: 'voice' | 'video';
    }) => {
      const userSession = activeUsers.get(socket.id);
      if (!userSession) return;
      
      const targetSession = Array.from(activeUsers.values()).find(u => u.userId === data.targetUserId);
      if (targetSession) {
        io.to(targetSession.socketId).emit('call:offer', {
          callerId: userSession.userId,
          callerName: userSession.userName,
          offer: data.offer,
          callType: data.callType
        });
      }
    });

    socket.on('call:answer', (data: {
      targetUserId: string;
      answer: any;
    }) => {
      const targetSession = Array.from(activeUsers.values()).find(u => u.userId === data.targetUserId);
      if (targetSession) {
        io.to(targetSession.socketId).emit('call:answered', data.answer);
      }
    });

    socket.on('call:ice-candidate', (data: {
      targetUserId: string;
      candidate: any;
    }) => {
      const targetSession = Array.from(activeUsers.values()).find(u => u.userId === data.targetUserId);
      if (targetSession) {
        io.to(targetSession.socketId).emit('call:ice-candidate', data.candidate);
      }
    });

    socket.on('call:end', (data: {
      targetUserId: string;
    }) => {
      const targetSession = Array.from(activeUsers.values()).find(u => u.userId === data.targetUserId);
      if (targetSession) {
        io.to(targetSession.socketId).emit('call:ended');
      }
    });

    // Handle webhook events (existing functionality)
    socket.on('webhook:created', (data) => {
      io.to('webhooks').emit('webhook:created', data);
    });

    socket.on('webhook:updated', (data) => {
      io.to('webhooks').emit('webhook:updated', data);
    });

    socket.on('webhook:deleted', (data) => {
      io.to('webhooks').emit('webhook:deleted', data);
    });

    // Handle alert events (existing functionality)
    socket.on('alert:received', (data) => {
      io.to('alerts').emit('alert:received', data);
    });

    socket.on('alert:processed', (data) => {
      io.to('alerts').emit('alert:processed', data);
    });

    socket.on('alert:delivered', (data) => {
      io.to('alerts').emit('alert:delivered', data);
    });

    socket.on('alert:failed', (data) => {
      io.to('alerts').emit('alert:failed', data);
    });

    // Handle channel events (existing functionality)
    socket.on('channel:created', (data) => {
      io.to('channels').emit('channel:created', data);
    });

    socket.on('channel:updated', (data) => {
      io.to('channels').emit('channel:updated', data);
    });

    socket.on('channel:deleted', (data) => {
      io.to('channels').emit('channel:deleted', data);
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      console.log('Client disconnected:', socket.id);
      
      const userSession = activeUsers.get(socket.id);
      if (userSession) {
        // Remove from current room
        if (userSession.currentRoom) {
          const room = activeRooms.get(userSession.currentRoom);
          if (room) {
            room.participants = room.participants.filter(p => p.socketId !== socket.id);
            socket.to(userSession.currentRoom).emit('room:user_left', {
              userId: userSession.userId,
              userName: userSession.userName,
              roomId: userSession.currentRoom
            });
            
            if (room.participants.length === 0) {
              activeRooms.delete(userSession.currentRoom);
            }
          }
        }
        
        // Remove from active users
        activeUsers.delete(socket.id);
        
        // Notify others
        socket.broadcast.emit('user:left', {
          userId: userSession.userId,
          userName: userSession.userName,
          onlineCount: activeUsers.size
        });
      }
      
      // Leave all rooms
      socket.leave('webhooks');
      socket.leave('alerts');
      socket.leave('channels');
      socket.leave('learning');
      socket.leave('achievements');
      socket.leave('social');
    });

    // Send welcome message
    socket.emit('message', {
      text: 'Welcome to Time Portal Conception - Real-time Collaboration!',
      senderId: 'system',
      timestamp: new Date().toISOString(),
    });
  });
};

// Helper functions for external access
export const getActiveUsers = () => Array.from(activeUsers.values());
export const getActiveRooms = () => Array.from(activeRooms.values());
export const getUserSession = (socketId: string) => activeUsers.get(socketId);
export const getRoomParticipants = (roomId: string) => {
  const room = activeRooms.get(roomId);
  return room ? room.participants : [];
};