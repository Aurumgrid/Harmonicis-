"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import DateUtils from "@/lib/date-utils";

interface UserProfile {
  id: string;
  name: string;
  avatar: string;
  banner?: string;
  bio: string;
  level: number;
  experience: number;
  rank: string;
  joinDate: string;
  totalHours: number;
  completedResources: number;
  achievements: string[];
  currentActivity?: string;
  isOnline: boolean;
  stats: {
    streak: number;
    weeklyGoal: number;
    weeklyProgress: number;
    totalSessions: number;
    averageSessionTime: number;
  };
  social: {
    friends: number;
    followers: number;
    following: number;
    communities: string[];
  };
  recentActivity: Activity[];
}

interface Activity {
  id: string;
  type: "completion" | "progress" | "achievement" | "social" | "milestone";
  title: string;
  description: string;
  timestamp: string;
  resource?: string;
  xp?: number;
}

interface Friend {
  id: string;
  name: string;
  avatar: string;
  level: number;
  currentActivity?: string;
  isOnline: boolean;
  lastSeen?: string;
  mutualFriends: number;
}

interface Community {
  id: string;
  name: string;
  description: string;
  members: number;
  icon: string;
  isJoined: boolean;
  category: string;
  activity: string;
}

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  rarity: "common" | "rare" | "epic" | "legendary";
  unlocked: boolean;
  unlockedDate?: string;
  progress?: number;
  maxProgress?: number;
}

export default function SocialLearningProfiles() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [friends, setFriends] = useState<Friend[]>([]);
  const [communities, setCommunities] = useState<Community[]>([]);
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [leaderboard, setLeaderboard] = useState<UserProfile[]>([]);
  const [activeTab, setActiveTab] = useState("profile");
  const [searchQuery, setSearchQuery] = useState("");

  // Sample user data
  const sampleUser: UserProfile = {
    id: "user1",
    name: "Time Traveler",
    avatar: "🚀",
    banner: "🌌",
    bio: "Passionate about quantum physics, fractals, and exploring the mysteries of the universe. Always learning something new!",
    level: 12,
    experience: 2840,
    rank: "Quantum Explorer",
    joinDate: "2023-06-15",
    totalHours: 156,
    completedResources: 23,
    achievements: ["Quantum Pioneer", "Fractal Master", "Portal Explorer", "Quick Learner", "Social Butterfly"],
    currentActivity: "Studying Quantum Mechanics",
    isOnline: true,
    stats: {
      streak: 7,
      weeklyGoal: 20,
      weeklyProgress: 15,
      totalSessions: 89,
      averageSessionTime: 45
    },
    social: {
      friends: 24,
      followers: 156,
      following: 89,
      communities: ["Quantum Physics", "Fractal Enthusiasts", "Mathematics"]
    },
    recentActivity: [
      {
        id: "act1",
        type: "completion",
        title: "Completed Resource",
        description: "Finished 'Quantum Mechanics: The Theoretical Minimum'",
        timestamp: "2024-01-22T14:30:00Z",
        resource: "Quantum Mechanics: The Theoretical Minimum",
        xp: 100
      },
      {
        id: "act2",
        type: "achievement",
        title: "Achievement Unlocked",
        description: "Earned 'Quantum Pioneer' badge",
        timestamp: "2024-01-22T14:25:00Z",
        xp: 50
      },
      {
        id: "act3",
        type: "progress",
        title: "Made Progress",
        description: "Advanced 25% in 'MIT OpenCourseWare - Quantum Physics I'",
        timestamp: "2024-01-21T16:45:00Z",
        resource: "MIT OpenCourseWare - Quantum Physics I",
        xp: 25
      },
      {
        id: "act4",
        type: "social",
        title: "New Friend",
        description: "Connected with Alice",
        timestamp: "2024-01-21T11:20:00Z",
        xp: 10
      },
      {
        id: "act5",
        type: "milestone",
        title: "Level Up!",
        description: "Reached level 12",
        timestamp: "2024-01-20T09:15:00Z",
        xp: 200
      }
    ]
  };

  const sampleFriends: Friend[] = [
    {
      id: "friend1",
      name: "Alice",
      avatar: "🔬",
      level: 15,
      currentActivity: "Exploring String Theory",
      isOnline: true,
      mutualFriends: 8
    },
    {
      id: "friend2",
      name: "Bob",
      avatar: "👨‍💻",
      level: 10,
      currentActivity: "Coding fractal generators",
      isOnline: true,
      mutualFriends: 5
    },
    {
      id: "friend3",
      name: "Carol",
      avatar: "🎨",
      level: 8,
      currentActivity: "Studying Rorschach test",
      isOnline: false,
      lastSeen: "2024-01-22T18:30:00Z",
      mutualFriends: 3
    },
    {
      id: "friend4",
      name: "David",
      avatar: "🧮",
      level: 18,
      currentActivity: "Researching Hofstadter's butterfly",
      isOnline: false,
      lastSeen: "2024-01-21T22:15:00Z",
      mutualFriends: 12
    },
    {
      id: "friend5",
      name: "Emma",
      avatar: "🌟",
      level: 14,
      currentActivity: "Reading about Mandelbrot set",
      isOnline: true,
      mutualFriends: 6
    }
  ];

  const sampleCommunities: Community[] = [
    {
      id: "comm1",
      name: "Quantum Physics",
      description: "Explore the fascinating world of quantum mechanics and its applications",
      members: 15420,
      icon: "⚛️",
      isJoined: true,
      category: "Science",
      activity: "Very Active"
    },
    {
      id: "comm2",
      name: "Fractal Enthusiasts",
      description: "Dedicated to the study and appreciation of fractals and chaotic systems",
      members: 8756,
      icon: "🔺",
      isJoined: true,
      category: "Mathematics",
      activity: "Active"
    },
    {
      id: "comm3",
      name: "Mathematics",
      description: "Pure and applied mathematics discussions and resources",
      members: 23451,
      icon: "🧮",
      isJoined: false,
      category: "Academic",
      activity: "Very Active"
    },
    {
      id: "comm4",
      name: "Portal Theory",
      description: "Discussing dimensional portals, wormholes, and multiverse theories",
      members: 5623,
      icon: "🌀",
      isJoined: true,
      category: "Theoretical Physics",
      activity: "Active"
    },
    {
      id: "comm5",
      name: "Psychology & Perception",
      description: "Exploring human perception, cognitive psychology, and personality tests",
      members: 12890,
      icon: "🧠",
      isJoined: false,
      category: "Psychology",
      activity: "Moderate"
    }
  ];

  const sampleAchievements: Achievement[] = [
    {
      id: "ach1",
      name: "Quantum Pioneer",
      description: "Complete your first quantum physics resource",
      icon: "⚛️",
      rarity: "common",
      unlocked: true,
      unlockedDate: "2024-01-22T14:25:00Z"
    },
    {
      id: "ach2",
      name: "Fractal Master",
      description: "Complete 5 fractal-related resources",
      icon: "🔺",
      rarity: "rare",
      unlocked: true,
      unlockedDate: "2024-01-20T16:30:00Z"
    },
    {
      id: "ach3",
      name: "Portal Explorer",
      description: "Explore all 6 knowledge dimensions",
      icon: "🌀",
      rarity: "epic",
      unlocked: true,
      unlockedDate: "2024-01-18T12:15:00Z"
    },
    {
      id: "ach4",
      name: "Speed Learner",
      description: "Complete a resource in under 30 hours",
      icon: "⚡",
      rarity: "rare",
      unlocked: false,
      progress: 1,
      maxProgress: 3
    },
    {
      id: "ach5",
      name: "Social Butterfly",
      description: "Connect with 20+ friends",
      icon: "🦋",
      rarity: "common",
      unlocked: true,
      unlockedDate: "2024-01-15T09:20:00Z"
    },
    {
      id: "ach6",
      name: "Time Traveler",
      description: "Maintain a 30-day learning streak",
      icon: "⏰",
      rarity: "legendary",
      unlocked: false,
      progress: 7,
      maxProgress: 30
    },
    {
      id: "ach7",
      name: "Knowledge Seeker",
      description: "Accumulate 5000 XP",
      icon: "📚",
      rarity: "epic",
      unlocked: false,
      progress: 2840,
      maxProgress: 5000
    },
    {
      id: "ach8",
      name: "Community Leader",
      description: "Join 10+ communities",
      icon: "👑",
      rarity: "rare",
      unlocked: false,
      progress: 3,
      maxProgress: 10
    }
  ];

  const sampleLeaderboard: UserProfile[] = [
    {
      id: "leader1",
      name: "QuantumMaster",
      avatar: "🏆",
      level: 25,
      experience: 6250,
      rank: "Grandmaster",
      joinDate: "2022-03-15",
      totalHours: 342,
      completedResources: 67,
      achievements: ["Quantum God", "Fractal Legend", "Time Lord"],
      currentActivity: "Teaching advanced quantum mechanics",
      isOnline: true,
      stats: { streak: 45, weeklyGoal: 30, weeklyProgress: 28, totalSessions: 234, averageSessionTime: 52 },
      social: { friends: 89, followers: 1234, following: 156, communities: ["Quantum Physics", "Mathematics"] },
      recentActivity: []
    },
    {
      id: "leader2",
      name: "FractalWizard",
      avatar: "🧙",
      level: 23,
      experience: 5750,
      rank: "Master",
      joinDate: "2022-05-20",
      totalHours: 298,
      completedResources: 58,
      achievements: ["Fractal God", "Mathematical Genius", "Pattern Master"],
      currentActivity: "Creating new fractal algorithms",
      isOnline: false,
      stats: { streak: 32, weeklyGoal: 25, weeklyProgress: 22, totalSessions: 198, averageSessionTime: 48 },
      social: { friends: 67, followers: 987, following: 134, communities: ["Fractal Enthusiasts", "Mathematics"] },
      recentActivity: []
    },
    {
      id: "leader3",
      name: "PortalExplorer",
      avatar: "🚪",
      level: 21,
      experience: 5250,
      rank: "Expert",
      joinDate: "2022-08-10",
      totalHours: 276,
      completedResources: 54,
      achievements: ["Portal Master", "Dimension Traveler", "Theory Expert"],
      currentActivity: "Researching multiverse theories",
      isOnline: true,
      stats: { streak: 28, weeklyGoal: 20, weeklyProgress: 18, totalSessions: 176, averageSessionTime: 45 },
      social: { friends: 45, followers: 756, following: 98, communities: ["Portal Theory", "Quantum Physics"] },
      recentActivity: []
    }
  ];

  useEffect(() => {
    setCurrentUser(sampleUser);
    setFriends(sampleFriends);
    setCommunities(sampleCommunities);
    setAchievements(sampleAchievements);
    setLeaderboard(sampleLeaderboard);
  }, []);

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "common": return "bg-gray-100 text-gray-800";
      case "rare": return "bg-blue-100 text-blue-800";
      case "epic": return "bg-purple-100 text-purple-800";
      case "legendary": return "bg-yellow-100 text-yellow-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case "completion": return "✅";
      case "progress": return "📈";
      case "achievement": return "🏆";
      case "social": return "👥";
      case "milestone": return "🎯";
      default: return "📝";
    }
  };

  const filteredFriends = friends.filter(friend =>
    friend.name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredCommunities = communities.filter(community =>
    community.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    community.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  if (!currentUser) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Social Learning Hub</h1>
        <p className="text-muted-foreground">
          Connect with fellow learners, join communities, and track your social learning journey
        </p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="profile">My Profile</TabsTrigger>
          <TabsTrigger value="friends">Friends</TabsTrigger>
          <TabsTrigger value="communities">Communities</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Profile Header */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader className="pb-4">
                  <div className="relative">
                    <div className="h-32 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-6xl">
                      {currentUser.banner}
                    </div>
                    <Avatar className="w-24 h-24 absolute -bottom-12 left-6 border-4 border-background">
                      <AvatarImage src={currentUser.avatar} />
                      <AvatarFallback className="text-2xl">{currentUser.avatar}</AvatarFallback>
                    </Avatar>
                  </div>
                  <div className="mt-14">
                    <div className="flex items-center gap-3">
                      <h2 className="text-2xl font-bold">{currentUser.name}</h2>
                      <div className="flex items-center gap-1">
                        <div className={`w-2 h-2 rounded-full ${currentUser.isOnline ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                        <span className="text-sm text-muted-foreground">
                          {currentUser.isOnline ? 'Online' : 'Offline'}
                        </span>
                      </div>
                    </div>
                    <p className="text-muted-foreground mt-1">{currentUser.rank} • Level {currentUser.level}</p>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium mb-2">Bio</h3>
                      <p className="text-sm text-muted-foreground">{currentUser.bio}</p>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">{currentUser.level}</div>
                        <div className="text-sm text-muted-foreground">Level</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">{currentUser.experience}</div>
                        <div className="text-sm text-muted-foreground">XP</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">{currentUser.completedResources}</div>
                        <div className="text-sm text-muted-foreground">Resources</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-orange-600">{currentUser.totalHours}h</div>
                        <div className="text-sm text-muted-foreground">Study Time</div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-medium mb-2">Current Activity</h3>
                      <p className="text-sm text-muted-foreground">{currentUser.currentActivity}</p>
                    </div>
                    
                    <div>
                      <h3 className="font-medium mb-2">Weekly Progress</h3>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-sm">
                          <span>Weekly Goal</span>
                          <span>{currentUser.stats.weeklyProgress}/{currentUser.stats.weeklyGoal} hours</span>
                        </div>
                        <Progress value={(currentUser.stats.weeklyProgress / currentUser.stats.weeklyGoal) * 100} />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="text-lg font-bold text-red-600">{currentUser.stats.streak}</div>
                        <div className="text-sm text-muted-foreground">Day Streak</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-blue-600">{currentUser.stats.totalSessions}</div>
                        <div className="text-sm text-muted-foreground">Sessions</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-green-600">{currentUser.stats.averageSessionTime}m</div>
                        <div className="text-sm text-muted-foreground">Avg Session</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Recent Activity */}
              <Card className="mt-6">
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-3">
                      {currentUser.recentActivity.map((activity) => (
                        <div key={activity.id} className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                          <span className="text-lg">{getActivityIcon(activity.type)}</span>
                          <div className="flex-1">
                            <div className="font-medium text-sm">{activity.title}</div>
                            <div className="text-xs text-muted-foreground">{activity.description}</div>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-xs text-muted-foreground">
                                {DateUtils.formatDisplay(activity.timestamp, { 
                                  month: 'short', 
                                  day: 'numeric', 
                                  hour: '2-digit', 
                                  minute: '2-digit' 
                                })}
                              </span>
                              {activity.xp && (
                                <Badge variant="outline" className="text-xs">
                                  +{activity.xp} XP
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
            
            {/* Sidebar */}
            <div className="space-y-6">
              {/* Social Stats */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Social Stats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Friends</span>
                      <span className="font-medium">{currentUser.social.friends}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Followers</span>
                      <span className="font-medium">{currentUser.social.followers}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Following</span>
                      <span className="font-medium">{currentUser.social.following}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Communities</span>
                      <span className="font-medium">{currentUser.social.communities.length}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Achievements Preview */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recent Achievements</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {achievements.filter(a => a.unlocked).slice(0, 3).map((achievement) => (
                      <div key={achievement.id} className="flex items-center gap-3">
                        <span className="text-lg">{achievement.icon}</span>
                        <div className="flex-1">
                          <div className="font-medium text-sm">{achievement.name}</div>
                          <div className="text-xs text-muted-foreground">{achievement.description}</div>
                        </div>
                        <Badge className={getRarityColor(achievement.rarity)}>
                          {achievement.rarity}
                        </Badge>
                      </div>
                    ))}
                  </div>
                  <Button variant="outline" className="w-full mt-3" onClick={() => setActiveTab("achievements")}>
                    View All Achievements
                  </Button>
                </CardContent>
              </Card>
              
              {/* Communities Preview */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">My Communities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {communities.filter(c => c.isJoined).slice(0, 3).map((community) => (
                      <div key={community.id} className="flex items-center gap-3">
                        <span className="text-lg">{community.icon}</span>
                        <div className="flex-1">
                          <div className="font-medium text-sm">{community.name}</div>
                          <div className="text-xs text-muted-foreground">{community.members.toLocaleString()} members</div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <Button variant="outline" className="w-full mt-3" onClick={() => setActiveTab("communities")}>
                    View All Communities
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="friends" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Friends</CardTitle>
                  <CardDescription>
                    Connect and learn with your friends
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <Input
                      placeholder="Search friends..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-4">
                    {filteredFriends.map((friend) => (
                      <div key={friend.id} className="flex items-center gap-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors">
                        <Avatar className="w-12 h-12">
                          <AvatarImage src={friend.avatar} />
                          <AvatarFallback className="text-lg">{friend.avatar}</AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-medium">{friend.name}</h3>
                            <div className={`w-2 h-2 rounded-full ${friend.isOnline ? 'bg-green-500' : 'bg-gray-400'}`}></div>
                            <span className="text-xs text-muted-foreground">
                              {friend.isOnline ? 'Online' : friend.lastSeen ? 'Last seen recently' : 'Offline'}
                            </span>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Level {friend.level} • {friend.mutualFriends} mutual friends
                          </div>
                          {friend.currentActivity && (
                            <div className="text-xs text-blue-600 mt-1">
                              💭 {friend.currentActivity}
                            </div>
                          )}
                        </div>
                        
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm">
                            Message
                          </Button>
                          <Button variant="outline" size="sm">
                            Profile
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Friend Requests */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Friend Requests</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-center text-muted-foreground py-8">
                    <div className="text-4xl mb-2">📭</div>
                    <p className="text-sm">No pending friend requests</p>
                  </div>
                </CardContent>
              </Card>
              
              {/* Add Friends */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Add Friends</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Input placeholder="Enter username or email..." />
                    <Button className="w-full">Send Friend Request</Button>
                  </div>
                  
                  <Separator className="my-4" />
                  
                  <div>
                    <h4 className="font-medium mb-2">Suggested Friends</h4>
                    <div className="space-y-2">
                      <div className="flex items-center gap-2 p-2 bg-muted rounded">
                        <Avatar className="w-8 h-8">
                          <AvatarFallback>🔭</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="text-sm font-medium">AstroPhysicist</div>
                          <div className="text-xs text-muted-foreground">12 mutual friends</div>
                        </div>
                        <Button variant="outline" size="sm">Add</Button>
                      </div>
                      
                      <div className="flex items-center gap-2 p-2 bg-muted rounded">
                        <Avatar className="w-8 h-8">
                          <AvatarFallback>🔢</AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="text-sm font-medium">MathWizard</div>
                          <div className="text-xs text-muted-foreground">8 mutual friends</div>
                        </div>
                        <Button variant="outline" size="sm">Add</Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="communities" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Communities</CardTitle>
                  <CardDescription>
                    Join communities to connect with like-minded learners
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <Input
                      placeholder="Search communities..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {filteredCommunities.map((community) => (
                      <Card key={community.id} className="hover:shadow-md transition-shadow">
                        <CardHeader className="pb-2">
                          <div className="flex items-center gap-3">
                            <span className="text-2xl">{community.icon}</span>
                            <div className="flex-1">
                              <CardTitle className="text-sm">{community.name}</CardTitle>
                              <CardDescription className="text-xs">
                                {community.category}
                              </CardDescription>
                            </div>
                            <Badge variant="outline" className="text-xs">
                              {community.activity}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                            {community.description}
                          </p>
                          
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-xs text-muted-foreground">
                              {community.members.toLocaleString()} members
                            </span>
                          </div>
                          
                          <Button 
                            variant={community.isJoined ? "outline" : "default"} 
                            size="sm" 
                            className="w-full"
                          >
                            {community.isJoined ? "Joined" : "Join Community"}
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* My Communities */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">My Communities</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {communities.filter(c => c.isJoined).map((community) => (
                      <div key={community.id} className="flex items-center gap-3 p-2 bg-muted rounded">
                        <span className="text-lg">{community.icon}</span>
                        <div className="flex-1">
                          <div className="font-medium text-sm">{community.name}</div>
                          <div className="text-xs text-muted-foreground">{community.members.toLocaleString()} members</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
              
              {/* Create Community */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Create Community</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Input placeholder="Community name..." />
                    <Textarea placeholder="Description..." rows={3} />
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="science">Science</SelectItem>
                        <SelectItem value="mathematics">Mathematics</SelectItem>
                        <SelectItem value="technology">Technology</SelectItem>
                        <SelectItem value="arts">Arts</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button className="w-full">Create Community</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="achievements" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Achievements</CardTitle>
                  <CardDescription>
                    Track your progress and unlock achievements as you learn
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {achievements.map((achievement) => (
                      <Card key={achievement.id} className={`transition-all ${achievement.unlocked ? 'ring-2 ring-yellow-400' : 'opacity-60'}`}>
                        <CardHeader className="pb-2">
                          <div className="flex items-center gap-3">
                            <span className={`text-2xl ${achievement.unlocked ? '' : 'grayscale'}`}>
                              {achievement.icon}
                            </span>
                            <div className="flex-1">
                              <CardTitle className="text-sm">{achievement.name}</CardTitle>
                              <CardDescription className="text-xs">
                                {achievement.description}
                              </CardDescription>
                            </div>
                            <Badge className={getRarityColor(achievement.rarity)}>
                              {achievement.rarity}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          {achievement.progress !== undefined && achievement.maxProgress && (
                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-xs">
                                <span>Progress</span>
                                <span>{achievement.progress}/{achievement.maxProgress}</span>
                              </div>
                              <Progress 
                                value={(achievement.progress / achievement.maxProgress) * 100} 
                                className="h-2"
                              />
                            </div>
                          )}
                          
                          {achievement.unlocked && achievement.unlockedDate && (
                            <div className="text-xs text-green-600 mt-2">
                              Unlocked on {DateUtils.formatDisplay(achievement.unlockedDate, { 
                                month: 'short', 
                                day: 'numeric', 
                                year: 'numeric' 
                              })}
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Achievement Stats */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Achievement Stats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Unlocked</span>
                      <span className="font-medium">
                        {achievements.filter(a => a.unlocked).length}/{achievements.length}
                      </span>
                    </div>
                    <Progress 
                      value={(achievements.filter(a => a.unlocked).length / achievements.length) * 100} 
                      className="h-2"
                    />
                    
                    <div className="grid grid-cols-2 gap-2 mt-4">
                      <div className="text-center">
                        <div className="text-lg font-bold text-yellow-600">
                          {achievements.filter(a => a.rarity === 'legendary' && a.unlocked).length}
                        </div>
                        <div className="text-xs text-muted-foreground">Legendary</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-purple-600">
                          {achievements.filter(a => a.rarity === 'epic' && a.unlocked).length}
                        </div>
                        <div className="text-xs text-muted-foreground">Epic</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Recent Unlocks */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recent Unlocks</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {achievements
                      .filter(a => a.unlocked && a.unlockedDate)
                      .sort((a, b) => new Date(b.unlockedDate!).getTime() - new Date(a.unlockedDate!).getTime())
                      .slice(0, 3)
                      .map((achievement) => (
                        <div key={achievement.id} className="flex items-center gap-3">
                          <span className="text-lg">{achievement.icon}</span>
                          <div className="flex-1">
                            <div className="font-medium text-sm">{achievement.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {DateUtils.formatDisplay(achievement.unlockedDate!, { 
                                month: 'short', 
                                day: 'numeric' 
                              })}
                            </div>
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="leaderboard" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Global Leaderboard</CardTitle>
                  <CardDescription>
                    Top learners in the Time Portal community
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Current user position */}
                    <Card className="border-blue-500">
                      <CardContent className="p-4">
                        <div className="flex items-center gap-4">
                          <div className="text-2xl font-bold text-blue-600">#?</div>
                          <Avatar className="w-12 h-12">
                            <AvatarImage src={currentUser.avatar} />
                            <AvatarFallback className="text-xl">{currentUser.avatar}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="font-medium">{currentUser.name} (You)</div>
                            <div className="text-sm text-muted-foreground">
                              Level {currentUser.level} • {currentUser.experience} XP
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="font-bold text-lg">{currentUser.completedResources}</div>
                            <div className="text-xs text-muted-foreground">Resources</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                    
                    {leaderboard.map((user, index) => (
                      <Card key={user.id} className={index < 3 ? 'border-yellow-400' : ''}>
                        <CardContent className="p-4">
                          <div className="flex items-center gap-4">
                            <div className={`text-2xl font-bold ${index === 0 ? 'text-yellow-500' : index === 1 ? 'text-gray-400' : index === 2 ? 'text-orange-600' : 'text-muted-foreground'}`}>
                              #{index + 1}
                            </div>
                            <Avatar className="w-12 h-12">
                              <AvatarImage src={user.avatar} />
                              <AvatarFallback className="text-xl">{user.avatar}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="font-medium">{user.name}</div>
                              <div className="text-sm text-muted-foreground">
                                Level {user.level} • {user.experience} XP • {user.rank}
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-bold text-lg">{user.completedResources}</div>
                              <div className="text-xs text-muted-foreground">Resources</div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Leaderboard Filters */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Filters</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Time Period" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Time</SelectItem>
                        <SelectItem value="monthly">This Month</SelectItem>
                        <SelectItem value="weekly">This Week</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        <SelectItem value="quantum">Quantum Physics</SelectItem>
                        <SelectItem value="fractals">Fractals</SelectItem>
                        <SelectItem value="portals">Dimensional Portals</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Region" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="global">Global</SelectItem>
                        <SelectItem value="local">Local</SelectItem>
                        <SelectItem value="friends">Friends</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
              
              {/* Your Ranking */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Your Ranking</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-600">#42</div>
                      <div className="text-sm text-muted-foreground">Global Rank</div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center">
                        <div className="text-lg font-bold text-green-600">#8</div>
                        <div className="text-xs text-muted-foreground">Friends Rank</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-purple-600">#15</div>
                        <div className="text-xs text-muted-foreground">Local Rank</div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div className="text-center">
                      <div className="text-sm font-medium">Next Rank: Quantum Master</div>
                      <div className="text-xs text-muted-foreground">Need 2,160 more XP</div>
                      <Progress value={(currentUser.experience / 5000) * 100} className="mt-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}