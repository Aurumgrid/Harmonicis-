"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import DateUtils from "@/lib/date-utils";

interface LibraryResource {
  id: string;
  title: string;
  type: "book" | "course" | "video" | "tool" | "paper" | "article";
  author: string;
  year?: number;
  description: string;
  difficulty: "beginner" | "intermediate" | "advanced";
  estimatedTime: string;
  completed: boolean;
  rating: number;
  tags: string[];
  category: string;
  addedDate: string;
  lastAccessed?: string;
  progress: number;
  achievements: string[];
  collaborators: string[];
  isFavorite: boolean;
  downloadUrl?: string;
  size?: string;
}

interface LibraryStats {
  totalResources: number;
  completedResources: number;
  totalHours: number;
  favoriteResources: number;
  categories: Record<string, number>;
  difficultyDistribution: Record<string, number>;
}

interface UserActivity {
  id: string;
  userId: string;
  userName: string;
  userAvatar: string;
  action: string;
  resourceTitle: string;
  timestamp: string;
}

export default function LearningLibrary() {
  const [resources, setResources] = useState<LibraryResource[]>([]);
  const [filteredResources, setFilteredResources] = useState<LibraryResource[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedType, setSelectedType] = useState("all");
  const [selectedDifficulty, setSelectedDifficulty] = useState("all");
  const [sortBy, setSortBy] = useState("recentlyAdded");
  const [showCompleted, setShowCompleted] = useState(false);
  const [showFavorites, setShowFavorites] = useState(false);
  const [libraryStats, setLibraryStats] = useState<LibraryStats | null>(null);
  const [recentActivities, setRecentActivities] = useState<UserActivity[]>([]);

  // Sample library data
  const sampleResources: LibraryResource[] = [
    {
      id: "lib1",
      title: "Quantum Mechanics: The Theoretical Minimum",
      type: "book",
      author: "Leonard Susskind",
      year: 2014,
      description: "Conceptual minimal approach to understanding quantum mechanics fundamentals",
      difficulty: "beginner",
      estimatedTime: "40 hours",
      completed: true,
      rating: 4.6,
      tags: ["quantum", "fundamentals", "theory"],
      category: "Quantum Physics",
      addedDate: "2024-01-15",
      lastAccessed: "2024-01-20",
      progress: 100,
      achievements: ["Quantum Foundation", "Theory Master"],
      collaborators: ["Alice", "Bob"],
      isFavorite: true,
      size: "2.3 MB"
    },
    {
      id: "lib2",
      title: "MIT OpenCourseWare - Quantum Physics I",
      type: "course",
      author: "MIT",
      description: "Complete course with video lectures, notes, and exercises",
      difficulty: "intermediate",
      estimatedTime: "80 hours",
      completed: false,
      rating: 4.9,
      tags: ["video", "lectures", "exercises"],
      category: "Quantum Physics",
      addedDate: "2024-01-10",
      lastAccessed: "2024-01-22",
      progress: 35,
      achievements: [],
      collaborators: ["Carol"],
      isFavorite: true,
      size: "1.2 GB"
    },
    {
      id: "lib3",
      title: "The Elegant Universe",
      type: "book",
      author: "Brian Greene",
      year: 1999,
      description: "Accessible introduction to string theory and extra dimensions",
      difficulty: "beginner",
      estimatedTime: "60 hours",
      completed: false,
      rating: 4.7,
      tags: ["string-theory", "popular-science"],
      category: "Dimensional Portals",
      addedDate: "2024-01-12",
      progress: 0,
      achievements: [],
      collaborators: [],
      isFavorite: false,
      size: "3.1 MB"
    },
    {
      id: "lib4",
      title: "Fractals Everywhere",
      type: "book",
      author: "Michael Barnsley",
      year: 1993,
      description: "Mathematical introduction to fractal geometry",
      difficulty: "intermediate",
      estimatedTime: "70 hours",
      completed: false,
      rating: 4.7,
      tags: ["mathematics", "fractals"],
      category: "Fractals",
      addedDate: "2024-01-08",
      lastAccessed: "2024-01-21",
      progress: 20,
      achievements: ["Geometry Explorer"],
      collaborators: ["Alice"],
      isFavorite: false,
      size: "4.5 MB"
    },
    {
      id: "lib5",
      title: "Python Fractal Generator",
      type: "tool",
      author: "Community",
      description: "High-performance Python code for generating fractals",
      difficulty: "intermediate",
      estimatedTime: "20 hours",
      completed: false,
      rating: 4.5,
      tags: ["programming", "python", "fractals"],
      category: "Fractals",
      addedDate: "2024-01-18",
      progress: 0,
      achievements: [],
      collaborators: ["Bob"],
      isFavorite: true,
      size: "156 KB",
      downloadUrl: "https://github.com/ajaykumar7/mandelbrot"
    },
    {
      id: "lib6",
      title: "Energy levels and wave functions of Bloch electrons",
      type: "paper",
      author: "Douglas R. Hofstadter",
      year: 1976,
      description: "Original paper introducing the Hofstadter butterfly concept",
      difficulty: "advanced",
      estimatedTime: "30 hours",
      completed: false,
      rating: 4.9,
      tags: ["seminal", "research", "quantum"],
      category: "Hofstadter's Butterfly",
      addedDate: "2024-01-05",
      progress: 0,
      achievements: [],
      collaborators: [],
      isFavorite: false,
      size: "890 KB"
    },
    {
      id: "lib7",
      title: "Rorschach Test – Interpretation Manual",
      type: "book",
      author: "John E. Exner Jr.",
      year: 2003,
      description: "Comprehensive System standard for interpretation",
      difficulty: "advanced",
      estimatedTime: "90 hours",
      completed: false,
      rating: 4.7,
      tags: ["clinical", "psychology"],
      category: "Rorschach Test",
      addedDate: "2024-01-14",
      progress: 0,
      achievements: [],
      collaborators: ["Carol"],
      isFavorite: false,
      size: "5.2 MB"
    },
    {
      id: "lib8",
      title: "The Fractal Geometry of Nature",
      type: "book",
      author: "Benoît B. Mandelbrot",
      year: 1982,
      description: "Fundamental book by the creator of fractals",
      difficulty: "intermediate",
      estimatedTime: "70 hours",
      completed: false,
      rating: 4.8,
      tags: ["foundational", "fractals"],
      category: "Mandelbrot Set",
      addedDate: "2024-01-16",
      lastAccessed: "2024-01-19",
      progress: 15,
      achievements: ["Fractal Pioneer"],
      collaborators: ["Alice", "Bob"],
      isFavorite: true,
      size: "12.4 MB"
    }
  ];

  const sampleActivities: UserActivity[] = [
    {
      id: "act1",
      userId: "user1",
      userName: "Alice",
      userAvatar: "🔬",
      action: "completed",
      resourceTitle: "Quantum Mechanics: The Theoretical Minimum",
      timestamp: "2024-01-20T14:30:00Z"
    },
    {
      id: "act2",
      userId: "user2",
      userName: "Bob",
      userAvatar: "👨‍💻",
      action: "started",
      resourceTitle: "Python Fractal Generator",
      timestamp: "2024-01-21T09:15:00Z"
    },
    {
      id: "act3",
      userId: "user3",
      userName: "Carol",
      userAvatar: "🎨",
      action: "progressed",
      resourceTitle: "MIT OpenCourseWare - Quantum Physics I",
      timestamp: "2024-01-22T16:45:00Z"
    },
    {
      id: "act4",
      userId: "user1",
      userName: "Alice",
      userAvatar: "🔬",
      action: "added",
      resourceTitle: "The Fractal Geometry of Nature",
      timestamp: "2024-01-22T11:20:00Z"
    }
  ];

  useEffect(() => {
    setResources(sampleResources);
    setFilteredResources(sampleResources);
    setRecentActivities(sampleActivities);
    
    // Calculate library statistics
    const stats: LibraryStats = {
      totalResources: sampleResources.length,
      completedResources: sampleResources.filter(r => r.completed).length,
      totalHours: sampleResources.reduce((acc, r) => {
        const hours = parseInt(r.estimatedTime);
        return acc + (isNaN(hours) ? 0 : hours);
      }, 0),
      favoriteResources: sampleResources.filter(r => r.isFavorite).length,
      categories: sampleResources.reduce((acc, r) => {
        acc[r.category] = (acc[r.category] || 0) + 1;
        return acc;
      }, {} as Record<string, number>),
      difficultyDistribution: sampleResources.reduce((acc, r) => {
        acc[r.difficulty] = (acc[r.difficulty] || 0) + 1;
        return acc;
      }, {} as Record<string, number>)
    };
    setLibraryStats(stats);
  }, []);

  useEffect(() => {
    let filtered = resources.filter(resource => {
      const matchesSearch = resource.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           resource.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           resource.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                           resource.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesCategory = selectedCategory === "all" || resource.category === selectedCategory;
      const matchesType = selectedType === "all" || resource.type === selectedType;
      const matchesDifficulty = selectedDifficulty === "all" || resource.difficulty === selectedDifficulty;
      const matchesCompleted = !showCompleted || resource.completed;
      const matchesFavorites = !showFavorites || resource.isFavorite;
      
      return matchesSearch && matchesCategory && matchesType && matchesDifficulty && matchesCompleted && matchesFavorites;
    });

    // Apply sorting
    filtered = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case "recentlyAdded":
          return new Date(b.addedDate).getTime() - new Date(a.addedDate).getTime();
        case "recentlyAccessed":
          return new Date(b.lastAccessed || "1970-01-01").getTime() - new Date(a.lastAccessed || "1970-01-01").getTime();
        case "rating":
          return b.rating - a.rating;
        case "progress":
          return b.progress - a.progress;
        case "title":
          return a.title.localeCompare(b.title);
        case "difficulty":
          const difficultyOrder = { "beginner": 1, "intermediate": 2, "advanced": 3 };
          return difficultyOrder[a.difficulty] - difficultyOrder[b.difficulty];
        default:
          return 0;
      }
    });

    setFilteredResources(filtered);
  }, [resources, searchQuery, selectedCategory, selectedType, selectedDifficulty, sortBy, showCompleted, showFavorites]);

  const toggleFavorite = (resourceId: string) => {
    setResources(prev => prev.map(resource => 
      resource.id === resourceId 
        ? { ...resource, isFavorite: !resource.isFavorite }
        : resource
    ));
  };

  const toggleCompletion = (resourceId: string) => {
    setResources(prev => prev.map(resource => 
      resource.id === resourceId 
        ? { 
            ...resource, 
            completed: !resource.completed,
            progress: !resource.completed ? 100 : 0
          }
        : resource
    ));
  };

  const updateProgress = (resourceId: string, progress: number) => {
    setResources(prev => prev.map(resource => 
      resource.id === resourceId 
        ? { ...resource, progress, lastAccessed: new Date().toISOString() }
        : resource
    ));
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "book": return "📚";
      case "course": return "🎓";
      case "video": return "🎬";
      case "tool": return "🔧";
      case "paper": return "📑";
      case "article": return "📄";
      default: return "📖";
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-100 text-green-800";
      case "intermediate": return "bg-yellow-100 text-yellow-800";
      case "advanced": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const categories = Array.from(new Set(resources.map(r => r.category)));
  const types = Array.from(new Set(resources.map(r => r.type)));
  const difficulties = Array.from(new Set(resources.map(r => r.difficulty)));

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Learning Library</h1>
        <p className="text-muted-foreground">
          Manage your personal collection of learning resources across all knowledge dimensions
        </p>
      </div>

      {/* Statistics Dashboard */}
      {libraryStats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Total Resources</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {libraryStats.totalResources}
              </div>
              <Progress 
                value={(libraryStats.completedResources / libraryStats.totalResources) * 100} 
                className="mt-2"
              />
              <div className="text-xs text-muted-foreground mt-1">
                {libraryStats.completedResources} completed
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Total Study Time</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {libraryStats.totalHours}h
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Estimated completion time
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Favorites</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                {libraryStats.favoriteResources}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Marked as favorite
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Categories</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">
                {Object.keys(libraryStats.categories).length}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Different knowledge areas
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Filters and Search */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Filter & Search</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
            <div>
              <Input
                placeholder="Search resources..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
            
            <Select value={selectedCategory} onValueChange={setSelectedCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>{category}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedType} onValueChange={setSelectedType}>
              <SelectTrigger>
                <SelectValue placeholder="Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {types.map(type => (
                  <SelectItem key={type} value={type}>{type}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Select value={selectedDifficulty} onValueChange={setSelectedDifficulty}>
              <SelectTrigger>
                <SelectValue placeholder="Difficulty" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Difficulties</SelectItem>
                {difficulties.map(difficulty => (
                  <SelectItem key={difficulty} value={difficulty}>{difficulty}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex flex-wrap items-center gap-4">
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="recentlyAdded">Recently Added</SelectItem>
                <SelectItem value="recentlyAccessed">Recently Accessed</SelectItem>
                <SelectItem value="rating">Rating</SelectItem>
                <SelectItem value="progress">Progress</SelectItem>
                <SelectItem value="title">Title</SelectItem>
                <SelectItem value="difficulty">Difficulty</SelectItem>
              </SelectContent>
            </Select>
            
            <div className="flex items-center gap-2">
              <Switch
                checked={showCompleted}
                onCheckedChange={setShowCompleted}
              />
              <span className="text-sm">Show completed only</span>
            </div>
            
            <div className="flex items-center gap-2">
              <Switch
                checked={showFavorites}
                onCheckedChange={setShowFavorites}
              />
              <span className="text-sm">Show favorites only</span>
            </div>
            
            <div className="text-sm text-muted-foreground">
              {filteredResources.length} resources found
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Resource Grid */}
        <div className="lg:col-span-2">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredResources.map((resource) => (
              <Card key={resource.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2">
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{getTypeIcon(resource.type)}</span>
                      <div className="flex-1">
                        <CardTitle className="text-sm line-clamp-2">{resource.title}</CardTitle>
                        <CardDescription className="text-xs">
                          {resource.author} {resource.year && `(${resource.year})`}
                        </CardDescription>
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => toggleFavorite(resource.id)}
                      className="p-1 h-auto"
                    >
                      {resource.isFavorite ? "⭐" : "☆"}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <p className="text-xs text-muted-foreground line-clamp-2">
                      {resource.description}
                    </p>
                    
                    <div className="flex items-center gap-2">
                      <Badge className={getDifficultyColor(resource.difficulty)}>
                        {resource.difficulty}
                      </Badge>
                      <Badge variant="outline" className="text-xs">
                        {resource.type}
                      </Badge>
                      {resource.rating && (
                        <Badge variant="outline" className="text-xs">
                          ⭐ {resource.rating}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <span>⏱️ {resource.estimatedTime}</span>
                      {resource.size && <span>📁 {resource.size}</span>}
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-xs">
                        <span>Progress</span>
                        <span>{resource.progress}%</span>
                      </div>
                      <Progress value={resource.progress} className="h-2" />
                    </div>
                    
                    <div className="flex flex-wrap gap-1">
                      {resource.tags.slice(0, 3).map((tag, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {tag}
                        </Badge>
                      ))}
                      {resource.tags.length > 3 && (
                        <Badge variant="secondary" className="text-xs">
                          +{resource.tags.length - 3}
                        </Badge>
                      )}
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={resource.completed}
                          onCheckedChange={() => toggleCompletion(resource.id)}
                        />
                        <span className="text-xs">{resource.completed ? "Completed" : "In Progress"}</span>
                      </div>
                      
                      {resource.downloadUrl && (
                        <Button variant="outline" size="sm" className="text-xs">
                          Download
                        </Button>
                      )}
                    </div>
                    
                    {resource.collaborators.length > 0 && (
                      <div className="flex items-center gap-1">
                        <span className="text-xs text-muted-foreground">Collaborators:</span>
                        {resource.collaborators.slice(0, 2).map((collaborator, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            👤 {collaborator}
                          </Badge>
                        ))}
                        {resource.collaborators.length > 2 && (
                          <Badge variant="outline" className="text-xs">
                            +{resource.collaborators.length - 2}
                          </Badge>
                        )}
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
        
        {/* Sidebar */}
        <div className="space-y-6">
          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <ScrollArea className="h-64">
                <div className="space-y-3">
                  {recentActivities.map((activity) => (
                    <div key={activity.id} className="flex items-start gap-3 p-2 bg-muted rounded">
                      <Avatar className="w-8 h-8">
                        <AvatarFallback>{activity.userAvatar}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="text-sm font-medium">{activity.userName}</div>
                        <div className="text-xs text-muted-foreground">
                          {activity.action} "{activity.resourceTitle}"
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {DateUtils.formatDisplay(activity.timestamp, { 
                            month: 'short', 
                            day: 'numeric', 
                            hour: '2-digit', 
                            minute: '2-digit' 
                          })}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>
          
          {/* Category Distribution */}
          {libraryStats && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {Object.entries(libraryStats.categories).map(([category, count]) => (
                    <div key={category} className="flex items-center justify-between">
                      <span className="text-sm">{category}</span>
                      <div className="flex items-center gap-2">
                        <div className="w-16 bg-muted rounded-full h-2">
                          <div 
                            className="bg-blue-500 h-2 rounded-full"
                            style={{ width: `${(count / libraryStats.totalResources) * 100}%` }}
                          />
                        </div>
                        <span className="text-sm text-muted-foreground">{count}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
          
          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  📥 Import Resources
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  📤 Export Library
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  🔄 Sync to Cloud
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  📊 Generate Report
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}