"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import DateUtils from "@/lib/date-utils";

interface Recommendation {
  id: string;
  type: "resource" | "topic" | "path" | "collaborator" | "community";
  title: string;
  description: string;
  confidence: number;
  reason: string;
  category: string;
  difficulty?: string;
  estimatedTime?: string;
  rating?: number;
  tags?: string[];
  relevanceScore: number;
  personalizedScore: number;
  trendScore: number;
  socialProof: number;
}

interface UserProfile {
  id: string;
  name: string;
  interests: string[];
  skillLevel: Record<string, number>;
  learningStyle: "visual" | "auditory" | "kinesthetic" | "reading";
  goals: string[];
  completedResources: string[];
  timeAvailable: number; // hours per week
  preferredDifficulty: "beginner" | "intermediate" | "advanced";
}

interface LearningPath {
  id: string;
  name: string;
  description: string;
  duration: string;
  difficulty: string;
  topics: string[];
  estimatedTime: string;
  completionRate: number;
  rating: number;
  matchScore: number;
  prerequisites: string[];
}

interface TrendingTopic {
  id: string;
  name: string;
  category: string;
  popularity: number;
  growth: number;
  relatedTopics: string[];
}

interface CollaboratorMatch {
  id: string;
  name: string;
  avatar: string;
  expertise: string[];
  compatibilityScore: number;
  mutualInterests: string[];
  availability: string;
}

export default function RecommendationEngine() {
  const [recommendations, setRecommendations] = useState<Recommendation[]>([]);
  const [filteredRecommendations, setFilteredRecommendations] = useState<Recommendation[]>([]);
  const [learningPaths, setLearningPaths] = useState<LearningPath[]>([]);
  const [trendingTopics, setTrendingTopics] = useState<TrendingTopic[]>([]);
  const [collaboratorMatches, setCollaboratorMatches] = useState<CollaboratorMatch[]>([]);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [activeTab, setActiveTab] = useState("recommendations");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedType, setSelectedType] = useState("all");
  const [sortBy, setSortBy] = useState("relevance");
  const [isGenerating, setIsGenerating] = useState(false);

  // Sample user profile
  const sampleUserProfile: UserProfile = {
    id: "user1",
    name: "Time Traveler",
    interests: ["quantum physics", "fractals", "mathematics", "theoretical physics"],
    skillLevel: {
      "quantum physics": 75,
      "fractals": 60,
      "mathematics": 85,
      "theoretical physics": 70,
      "programming": 45
    },
    learningStyle: "visual",
    goals: ["master quantum mechanics", "understand fractal geometry", "explore dimensional theories"],
    completedResources: ["quantum_mechanics_basics", "fractal_introduction", "mathematical_foundation"],
    timeAvailable: 15,
    preferredDifficulty: "intermediate"
  };

  // Sample recommendations
  const sampleRecommendations: Recommendation[] = [
    {
      id: "rec1",
      type: "resource",
      title: "Quantum Computing Basics",
      description: "Introduction to quantum computing concepts and applications",
      confidence: 92,
      reason: "Based on your interest in Quantum Physics and high completion rate",
      category: "Quantum Physics",
      difficulty: "intermediate",
      estimatedTime: "25 hours",
      rating: 4.7,
      tags: ["quantum", "computing", "algorithms"],
      relevanceScore: 0.92,
      personalizedScore: 0.88,
      trendScore: 0.85,
      socialProof: 0.90
    },
    {
      id: "rec2",
      type: "topic",
      title: "Chaos Theory",
      description: "Explore the mathematical study of dynamical systems and chaos",
      confidence: 87,
      reason: "Complementary to your Fractals exploration and strong mathematics background",
      category: "Mathematics",
      difficulty: "advanced",
      estimatedTime: "40 hours",
      rating: 4.8,
      tags: ["chaos", "dynamical systems", "mathematics"],
      relevanceScore: 0.87,
      personalizedScore: 0.85,
      trendScore: 0.78,
      socialProof: 0.82
    },
    {
      id: "rec3",
      type: "path",
      title: "Advanced Quantum Mechanics",
      description: "Deep dive into advanced quantum concepts and applications",
      confidence: 78,
      reason: "Next logical step after completing Quantum Physics fundamentals",
      category: "Quantum Physics",
      difficulty: "advanced",
      estimatedTime: "60 hours",
      rating: 4.9,
      tags: ["quantum", "advanced", "theory"],
      relevanceScore: 0.78,
      personalizedScore: 0.82,
      trendScore: 0.75,
      socialProof: 0.88
    },
    {
      id: "rec4",
      type: "collaborator",
      title: "Dr. Sarah Chen",
      description: "Quantum physics researcher with expertise in quantum computing",
      confidence: 85,
      reason: "Matches your interest in quantum physics and learning style",
      category: "Collaboration",
      relevanceScore: 0.85,
      personalizedScore: 0.90,
      trendScore: 0.70,
      socialProof: 0.95
    },
    {
      id: "rec5",
      type: "community",
      title: "Quantum Computing Enthusiasts",
      description: "Active community discussing quantum computing developments",
      confidence: 83,
      reason: "High engagement and relevance to your interests",
      category: "Community",
      relevanceScore: 0.83,
      personalizedScore: 0.75,
      trendScore: 0.92,
      socialProof: 0.88
    },
    {
      id: "rec6",
      type: "resource",
      title: "String Theory Fundamentals",
      description: "Introduction to string theory and extra dimensions",
      confidence: 76,
      reason: "Builds on your theoretical physics knowledge",
      category: "Theoretical Physics",
      difficulty: "advanced",
      estimatedTime: "35 hours",
      rating: 4.6,
      tags: ["string theory", "theoretical physics", "dimensions"],
      relevanceScore: 0.76,
      personalizedScore: 0.78,
      trendScore: 0.82,
      socialProof: 0.85
    },
    {
      id: "rec7",
      type: "topic",
      title: "Machine Learning for Physics",
      description: "Apply machine learning techniques to physics problems",
      confidence: 81,
      reason: "Combines your programming interest with physics knowledge",
      category: "Interdisciplinary",
      difficulty: "intermediate",
      estimatedTime: "30 hours",
      rating: 4.5,
      tags: ["machine learning", "physics", "programming"],
      relevanceScore: 0.81,
      personalizedScore: 0.83,
      trendScore: 0.90,
      socialProof: 0.87
    },
    {
      id: "rec8",
      type: "path",
      title: "Mathematical Physics Journey",
      description: "Comprehensive path covering advanced mathematical physics",
      confidence: 79,
      reason: "Perfect match for your strong mathematics background",
      category: "Mathematics",
      difficulty: "advanced",
      estimatedTime: "80 hours",
      rating: 4.8,
      tags: ["mathematics", "physics", "advanced"],
      relevanceScore: 0.79,
      personalizedScore: 0.85,
      trendScore: 0.76,
      socialProof: 0.91
    }
  ];

  // Sample learning paths
  const sampleLearningPaths: LearningPath[] = [
    {
      id: "path1",
      name: "Quantum Physics Mastery",
      description: "Complete journey from basics to advanced quantum mechanics",
      duration: "3 months",
      difficulty: "intermediate",
      topics: ["Quantum Mechanics", "Quantum Computing", "Quantum Field Theory"],
      estimatedTime: "120 hours",
      completionRate: 78,
      rating: 4.8,
      matchScore: 92,
      prerequisites: ["Basic Physics", "Linear Algebra"]
    },
    {
      id: "path2",
      name: "Fractal Geometry Explorer",
      description: "Deep dive into fractals, chaos theory, and mathematical beauty",
      duration: "2 months",
      difficulty: "intermediate",
      topics: ["Fractals", "Chaos Theory", "Dynamical Systems"],
      estimatedTime: "80 hours",
      completionRate: 85,
      rating: 4.7,
      matchScore: 87,
      prerequisites: ["Calculus", "Basic Geometry"]
    },
    {
      id: "path3",
      name: "Theoretical Physics Comprehensive",
      description: "Comprehensive study of modern theoretical physics",
      duration: "6 months",
      difficulty: "advanced",
      topics: ["Quantum Mechanics", "String Theory", "General Relativity", "Cosmology"],
      estimatedTime: "200 hours",
      completionRate: 65,
      rating: 4.9,
      matchScore: 84,
      prerequisites: ["Advanced Mathematics", "Classical Mechanics"]
    },
    {
      id: "path4",
      name: "Mathematical Physics Specialization",
      description: "Focus on mathematical methods in physics",
      duration: "4 months",
      difficulty: "advanced",
      topics: ["Mathematical Methods", "Group Theory", "Differential Geometry"],
      estimatedTime: "150 hours",
      completionRate: 72,
      rating: 4.6,
      matchScore: 89,
      prerequisites: ["Advanced Calculus", "Linear Algebra"]
    }
  ];

  // Sample trending topics
  const sampleTrendingTopics: TrendingTopic[] = [
    {
      id: "trend1",
      name: "Quantum Machine Learning",
      category: "Interdisciplinary",
      popularity: 95,
      growth: 28,
      relatedTopics: ["Quantum Computing", "Machine Learning", "Neural Networks"]
    },
    {
      id: "trend2",
      name: "Topological Quantum Computing",
      category: "Quantum Physics",
      popularity: 88,
      growth: 22,
      relatedTopics: ["Quantum Computing", "Topology", "Condensed Matter"]
    },
    {
      id: "trend3",
      name: "Fractal Antennas",
      category: "Applied Physics",
      popularity: 76,
      growth: 18,
      relatedTopics: ["Fractals", "Electromagnetics", "Engineering"]
    },
    {
      id: "trend4",
      name: "Quantum Error Correction",
      category: "Quantum Computing",
      popularity: 82,
      growth: 25,
      relatedTopics: ["Quantum Computing", "Information Theory", "Coding Theory"]
    },
    {
      id: "trend5",
      name: "Chaos Theory in Climate Science",
      category: "Applied Mathematics",
      popularity: 71,
      growth: 15,
      relatedTopics: ["Chaos Theory", "Climate Science", "Dynamical Systems"]
    }
  ];

  // Sample collaborator matches
  const sampleCollaboratorMatches: CollaboratorMatch[] = [
    {
      id: "collab1",
      name: "Dr. Sarah Chen",
      avatar: "🔬",
      expertise: ["Quantum Computing", "Quantum Algorithms", "Machine Learning"],
      compatibilityScore: 92,
      mutualInterests: ["Quantum Physics", "Mathematics"],
      availability: "Full-time"
    },
    {
      id: "collab2",
      name: "Prof. Michael Rodriguez",
      avatar: "🧮",
      expertise: ["Mathematical Physics", "Differential Geometry", "Group Theory"],
      compatibilityScore: 88,
      mutualInterests: ["Mathematics", "Theoretical Physics"],
      availability: "Part-time"
    },
    {
      id: "collab3",
      name: "Dr. Emily Watson",
      avatar: "🔭",
      expertise: ["Fractals", "Chaos Theory", "Dynamical Systems"],
      compatibilityScore: 85,
      mutualInterests: ["Fractals", "Mathematics"],
      availability: "Full-time"
    },
    {
      id: "collab4",
      name: "Dr. James Liu",
      avatar: "💻",
      expertise: ["Computational Physics", "Machine Learning", "Data Science"],
      compatibilityScore: 82,
      mutualInterests: ["Programming", "Physics"],
      availability: "Part-time"
    }
  ];

  useEffect(() => {
    setUserProfile(sampleUserProfile);
    setRecommendations(sampleRecommendations);
    setFilteredRecommendations(sampleRecommendations);
    setLearningPaths(sampleLearningPaths);
    setTrendingTopics(sampleTrendingTopics);
    setCollaboratorMatches(sampleCollaboratorMatches);
  }, []);

  useEffect(() => {
    let filtered = recommendations.filter(rec => {
      const matchesCategory = selectedCategory === "all" || rec.category === selectedCategory;
      const matchesType = selectedType === "all" || rec.type === selectedType;
      return matchesCategory && matchesType;
    });

    // Apply sorting
    filtered = [...filtered].sort((a, b) => {
      switch (sortBy) {
        case "relevance":
          return b.relevanceScore - a.relevanceScore;
        case "confidence":
          return b.confidence - a.confidence;
        case "trending":
          return b.trendScore - a.trendScore;
        case "social":
          return b.socialProof - a.socialProof;
        case "personalized":
          return b.personalizedScore - a.personalizedScore;
        default:
          return 0;
      }
    });

    setFilteredRecommendations(filtered);
  }, [recommendations, selectedCategory, selectedType, sortBy]);

  const generateRecommendations = () => {
    setIsGenerating(true);
    
    // Simulate AI recommendation generation
    setTimeout(() => {
      const newRecommendations: Recommendation[] = [
        {
          id: `rec_${Date.now()}_1`,
          type: "resource",
          title: "Neural Networks for Physics",
          description: "Apply neural network techniques to solve physics problems",
          confidence: 89,
          reason: "Combines your programming skills with physics interests",
          category: "Interdisciplinary",
          difficulty: "intermediate",
          estimatedTime: "35 hours",
          rating: 4.6,
          tags: ["neural networks", "physics", "programming"],
          relevanceScore: 0.89,
          personalizedScore: 0.87,
          trendScore: 0.91,
          socialProof: 0.84
        },
        {
          id: `rec_${Date.now()}_2`,
          type: "topic",
          title: "Quantum Information Theory",
          description: "Explore the intersection of quantum mechanics and information theory",
          confidence: 86,
          reason: "Advanced topic building on your quantum knowledge",
          category: "Quantum Physics",
          difficulty: "advanced",
          estimatedTime: "45 hours",
          rating: 4.8,
          tags: ["quantum", "information theory", "advanced"],
          relevanceScore: 0.86,
          personalizedScore: 0.84,
          trendScore: 0.88,
          socialProof: 0.90
        }
      ];
      
      setRecommendations(prev => [...newRecommendations, ...prev]);
      setIsGenerating(false);
    }, 2000);
  };

  const getRecommendationIcon = (type: string) => {
    switch (type) {
      case "resource": return "📚";
      case "topic": return "🌟";
      case "path": return "🛤️";
      case "collaborator": return "👥";
      case "community": return "🌐";
      default: return "💡";
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case "resource": return "bg-blue-100 text-blue-800";
      case "topic": return "bg-green-100 text-green-800";
      case "path": return "bg-purple-100 text-purple-800";
      case "collaborator": return "bg-orange-100 text-orange-800";
      case "community": return "bg-cyan-100 text-cyan-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner": return "bg-green-100 text-green-800";
      case "intermediate": return "bg-yellow-100 text-yellow-800";
      case "advanced": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const categories = Array.from(new Set(recommendations.map(r => r.category)));
  const types = Array.from(new Set(recommendations.map(r => r.type)));

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">AI Recommendation Engine</h1>
        <p className="text-muted-foreground">
          Personalized learning recommendations powered by artificial intelligence
        </p>
      </div>

      {/* User Profile Summary */}
      {userProfile && (
        <Card className="mb-6">
          <CardHeader>
            <CardTitle>Your Learning Profile</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div>
                <div className="text-sm font-medium">Interests</div>
                <div className="flex flex-wrap gap-1 mt-1">
                  {userProfile.interests.slice(0, 3).map((interest, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {interest}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-sm font-medium">Learning Style</div>
                <div className="text-sm text-muted-foreground capitalize">
                  {userProfile.learningStyle}
                </div>
              </div>
              <div>
                <div className="text-sm font-medium">Time Available</div>
                <div className="text-sm text-muted-foreground">
                  {userProfile.timeAvailable} hours/week
                </div>
              </div>
              <div>
                <div className="text-sm font-medium">Preferred Difficulty</div>
                <div className="text-sm text-muted-foreground capitalize">
                  {userProfile.preferredDifficulty}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          <TabsTrigger value="paths">Learning Paths</TabsTrigger>
          <TabsTrigger value="trending">Trending</TabsTrigger>
          <TabsTrigger value="collaborators">Collaborators</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="recommendations" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>Personalized Recommendations</CardTitle>
                      <CardDescription>
                        AI-powered suggestions tailored to your learning profile
                      </CardDescription>
                    </div>
                    <Button
                      onClick={generateRecommendations}
                      disabled={isGenerating}
                    >
                      {isGenerating ? "Generating..." : "Generate New"}
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  {/* Filters */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        {categories.map(category => (
                          <SelectItem key={category} value={category}>{category}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    <Select value={selectedType} onValueChange={setSelectedType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Types</SelectItem>
                        {types.map(type => (
                          <SelectItem key={type} value={type}>{type}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    <Select value={sortBy} onValueChange={setSortBy}>
                      <SelectTrigger>
                        <SelectValue placeholder="Sort by" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="relevance">Relevance</SelectItem>
                        <SelectItem value="confidence">Confidence</SelectItem>
                        <SelectItem value="trending">Trending</SelectItem>
                        <SelectItem value="social">Social Proof</SelectItem>
                        <SelectItem value="personalized">Personalized</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {/* Recommendations Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {filteredRecommendations.map((rec) => (
                      <Card key={rec.id} className="hover:shadow-md transition-shadow">
                        <CardHeader className="pb-2">
                          <div className="flex items-start justify-between">
                            <div className="flex items-center gap-2">
                              <span className="text-lg">{getRecommendationIcon(rec.type)}</span>
                              <div className="flex-1">
                                <CardTitle className="text-sm line-clamp-2">{rec.title}</CardTitle>
                                <CardDescription className="text-xs">
                                  {rec.category}
                                </CardDescription>
                              </div>
                            </div>
                            <Badge className={getTypeColor(rec.type)}>
                              {rec.type}
                            </Badge>
                          </div>
                        </CardHeader>
                        <CardContent>
                          <p className="text-xs text-muted-foreground mb-3 line-clamp-2">
                            {rec.description}
                          </p>
                          
                          <div className="space-y-2">
                            <div className="flex items-center justify-between text-xs">
                              <span>Confidence</span>
                              <div className="flex items-center gap-2">
                                <Progress value={rec.confidence} className="w-16 h-2" />
                                <span className="font-medium">{rec.confidence}%</span>
                              </div>
                            </div>
                            
                            <div className="text-xs text-muted-foreground mb-3">
                              Why: {rec.reason}
                            </div>
                            
                            {rec.difficulty && (
                              <Badge className={getDifficultyColor(rec.difficulty)}>
                                {rec.difficulty}
                              </Badge>
                            )}
                            
                            {rec.estimatedTime && (
                              <span className="text-xs text-muted-foreground">
                                ⏱️ {rec.estimatedTime}
                              </span>
                            )}
                            
                            {rec.rating && (
                              <span className="text-xs text-muted-foreground">
                                ⭐ {rec.rating}
                              </span>
                            )}
                          </div>
                          
                          <div className="flex gap-2 mt-3">
                            <Button variant="outline" size="sm" className="flex-1">
                              Explore
                            </Button>
                            <Button variant="ghost" size="sm">
                              📎 Save
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Recommendation Insights */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recommendation Insights</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="text-sm font-medium mb-2">Top Categories</div>
                      <div className="space-y-2">
                        {categories.slice(0, 3).map((category) => {
                          const count = recommendations.filter(r => r.category === category).length;
                          const percentage = (count / recommendations.length) * 100;
                          return (
                            <div key={category} className="flex items-center justify-between">
                              <span className="text-sm">{category}</span>
                              <div className="flex items-center gap-2">
                                <div className="w-16 bg-muted rounded-full h-2">
                                  <div 
                                    className="bg-blue-500 h-2 rounded-full"
                                    style={{ width: `${percentage}%` }}
                                  />
                                </div>
                                <span className="text-xs text-muted-foreground">{count}</span>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <div className="text-sm font-medium mb-2">Recommendation Types</div>
                      <div className="space-y-2">
                        {types.map((type) => {
                          const count = recommendations.filter(r => r.type === type).length;
                          return (
                            <div key={type} className="flex items-center justify-between">
                              <span className="text-sm capitalize">{type}</span>
                              <Badge variant="outline" className="text-xs">
                                {count}
                              </Badge>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start">
                      🎯 Update Preferences
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      📊 View Analytics
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      🔔 Set Alerts
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      📤 Share Recommendations
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="paths" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Recommended Learning Paths</CardTitle>
                  <CardDescription>
                    Curated learning journeys based on your goals and preferences
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {learningPaths.map((path) => (
                      <Card key={path.id} className="hover:shadow-md transition-shadow">
                        <CardHeader className="pb-2">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-sm">{path.name}</CardTitle>
                            <Badge variant="outline" className="text-xs">
                              {path.matchScore}% match
                            </Badge>
                          </div>
                          <CardDescription className="text-xs">
                            {path.description}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <div className="grid grid-cols-2 gap-4 text-xs">
                              <div>
                                <span className="text-muted-foreground">Duration:</span>
                                <span className="font-medium ml-1">{path.duration}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Time:</span>
                                <span className="font-medium ml-1">{path.estimatedTime}</span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Difficulty:</span>
                                <Badge className={getDifficultyColor(path.difficulty)} className="text-xs ml-1">
                                  {path.difficulty}
                                </Badge>
                              </div>
                              <div>
                                <span className="text-muted-foreground">Rating:</span>
                                <span className="font-medium ml-1">⭐ {path.rating}</span>
                              </div>
                            </div>
                            
                            <div>
                              <div className="text-xs font-medium mb-1">Topics:</div>
                              <div className="flex flex-wrap gap-1">
                                {path.topics.map((topic, index) => (
                                  <Badge key={index} variant="secondary" className="text-xs">
                                    {topic}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                            
                            <div className="flex items-center justify-between">
                              <div className="text-xs text-muted-foreground">
                                {path.completionRate}% completion rate
                              </div>
                              <Button variant="outline" size="sm">
                                Start Path
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Path Recommendations */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Path Insights</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="text-sm font-medium mb-2">Recommended Based On</div>
                      <ul className="text-xs text-muted-foreground space-y-1">
                        <li>• Strong mathematics background</li>
                        <li>• Interest in quantum physics</li>
                        <li>• 15 hours/week availability</li>
                        <li>• Intermediate difficulty preference</li>
                      </ul>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <div className="text-sm font-medium mb-2">Time Commitment</div>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span>Quantum Physics Mastery</span>
                          <span>10 hrs/week</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span>Fractal Geometry Explorer</span>
                          <span>8 hrs/week</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span>Theoretical Physics Comprehensive</span>
                          <span>12 hrs/week</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Create Custom Path */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Create Custom Path</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Input placeholder="Path name..." />
                    <Textarea placeholder="Description..." rows={3} />
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Difficulty level" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="beginner">Beginner</SelectItem>
                        <SelectItem value="intermediate">Intermediate</SelectItem>
                        <SelectItem value="advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                    <Input placeholder="Estimated duration..." />
                    <Button className="w-full">Create Path</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="trending" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Trending Topics</CardTitle>
                  <CardDescription>
                    Discover what's popular and growing in the learning community
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {trendingTopics.map((topic) => (
                      <Card key={topic.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="font-medium">{topic.name}</h3>
                            <Badge variant="outline" className="text-xs">
                              {topic.category}
                            </Badge>
                          </div>
                          
                          <div className="grid grid-cols-2 gap-4 mb-3">
                            <div>
                              <div className="text-xs text-muted-foreground">Popularity</div>
                              <div className="flex items-center gap-2">
                                <Progress value={topic.popularity} className="flex-1 h-2" />
                                <span className="text-xs font-medium">{topic.popularity}%</span>
                              </div>
                            </div>
                            <div>
                              <div className="text-xs text-muted-foreground">Growth</div>
                              <div className="flex items-center gap-1">
                                <span className="text-xs font-medium text-green-600">+{topic.growth}%</span>
                              </div>
                            </div>
                          </div>
                          
                          <div>
                            <div className="text-xs text-muted-foreground mb-1">Related Topics</div>
                            <div className="flex flex-wrap gap-1">
                              {topic.relatedTopics.slice(0, 3).map((related, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {related}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          
                          <Button variant="outline" size="sm" className="w-full mt-3">
                            Explore Topic
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Trend Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Trend Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="text-sm font-medium mb-2">Fastest Growing</div>
                      <div className="space-y-2">
                        {trendingTopics
                          .sort((a, b) => b.growth - a.growth)
                          .slice(0, 3)
                          .map((topic) => (
                            <div key={topic.id} className="flex items-center justify-between">
                              <span className="text-sm">{topic.name}</span>
                              <Badge variant="outline" className="text-xs text-green-600">
                                +{topic.growth}%
                              </Badge>
                            </div>
                          ))}
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <div className="text-sm font-medium mb-2">Most Popular</div>
                      <div className="space-y-2">
                        {trendingTopics
                          .sort((a, b) => b.popularity - a.popularity)
                          .slice(0, 3)
                          .map((topic) => (
                            <div key={topic.id} className="flex items-center justify-between">
                              <span className="text-sm">{topic.name}</span>
                              <Badge variant="outline" className="text-xs">
                                {topic.popularity}%
                              </Badge>
                            </div>
                          ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Category Breakdown */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Category Breakdown</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Array.from(new Set(trendingTopics.map(t => t.category))).map((category) => {
                      const categoryTopics = trendingTopics.filter(t => t.category === category);
                      const avgPopularity = categoryTopics.reduce((sum, t) => sum + t.popularity, 0) / categoryTopics.length;
                      const avgGrowth = categoryTopics.reduce((sum, t) => sum + t.growth, 0) / categoryTopics.length;
                      
                      return (
                        <div key={category} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">{category}</span>
                            <span className="text-xs text-muted-foreground">
                              {categoryTopics.length} topics
                            </span>
                          </div>
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <div>
                              <span className="text-muted-foreground">Avg Popularity:</span>
                              <span className="font-medium ml-1">{Math.round(avgPopularity)}%</span>
                            </div>
                            <div>
                              <span className="text-muted-foreground">Avg Growth:</span>
                              <span className="font-medium ml-1 text-green-600">+{Math.round(avgGrowth)}%</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="collaborators" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Collaborator Matches</CardTitle>
                  <CardDescription>
                    Find learning partners based on complementary skills and interests
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {collaboratorMatches.map((collaborator) => (
                      <Card key={collaborator.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-4">
                          <div className="flex items-center gap-3 mb-3">
                            <Avatar className="w-12 h-12">
                              <AvatarImage src={collaborator.avatar} />
                              <AvatarFallback className="text-lg">{collaborator.avatar}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <h3 className="font-medium">{collaborator.name}</h3>
                              <div className="text-sm text-muted-foreground">
                                {collaborator.availability} • {collaborator.compatibilityScore}% match
                              </div>
                            </div>
                            <Badge variant="outline" className="text-xs">
                              {collaborator.compatibilityScore}% compatible
                            </Badge>
                          </div>
                          
                          <div className="mb-3">
                            <div className="text-sm font-medium mb-1">Expertise</div>
                            <div className="flex flex-wrap gap-1">
                              {collaborator.expertise.slice(0, 3).map((skill, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {skill}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          
                          <div className="mb-3">
                            <div className="text-sm font-medium mb-1">Mutual Interests</div>
                            <div className="text-xs text-muted-foreground">
                              {collaborator.mutualInterests.join(", ")}
                            </div>
                          </div>
                          
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm" className="flex-1">
                              Connect
                            </Button>
                            <Button variant="outline" size="sm">
                              Message
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Collaboration Insights */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Collaboration Insights</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="text-sm font-medium mb-2">Top Expertise Areas</div>
                      <div className="space-y-2">
                        {Array.from(new Set(collaboratorMatches.flatMap(c => c.expertise))).slice(0, 3).map((expertise) => {
                          const count = collaboratorMatches.filter(c => c.expertise.includes(expertise)).length;
                          return (
                            <div key={expertise} className="flex items-center justify-between">
                              <span className="text-sm">{expertise}</span>
                              <Badge variant="outline" className="text-xs">
                                {count} collaborators
                              </Badge>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <div className="text-sm font-medium mb-2">Availability Distribution</div>
                      <div className="space-y-2">
                        {Array.from(new Set(collaboratorMatches.map(c => c.availability))).map((availability) => {
                          const count = collaboratorMatches.filter(c => c.availability === availability).length;
                          return (
                            <div key={availability} className="flex items-center justify-between">
                              <span className="text-sm">{availability}</span>
                              <Badge variant="outline" className="text-xs">
                                {count} collaborators
                              </Badge>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Collaboration Preferences */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Collaboration Preferences</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Looking for</label>
                      <select className="w-full mt-1 p-2 border rounded">
                        <option value="study_partner">Study Partner</option>
                        <option value="mentor">Mentor</option>
                        <option value="project_collaborator">Project Collaborator</option>
                        <option value="discussion_group">Discussion Group</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Expertise Level</label>
                      <select className="w-full mt-1 p-2 border rounded">
                        <option value="beginner">Beginner</option>
                        <option value="intermediate">Intermediate</option>
                        <option value="advanced">Advanced</option>
                        <option value="expert">Expert</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Time Commitment</label>
                      <select className="w-full mt-1 p-2 border rounded">
                        <option value="casual">Casual (1-3 hrs/week)</option>
                        <option value="moderate">Moderate (3-6 hrs/week)</option>
                        <option value="regular">Regular (6-10 hrs/week)</option>
                        <option value="intensive">Intensive (10+ hrs/week)</option>
                      </select>
                    </div>
                    
                    <Button className="w-full">Update Preferences</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="insights" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Learning Analytics</CardTitle>
                  <CardDescription>
                    Insights into your learning patterns and recommendations
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div>
                      <h3 className="font-medium mb-3">Recommendation Performance</h3>
                      <div className="space-y-3">
                        <div>
                          <div className="flex items-center justify-between text-sm mb-1">
                            <span>Acceptance Rate</span>
                            <span className="font-medium">78%</span>
                          </div>
                          <Progress value={78} className="h-2" />
                        </div>
                        
                        <div>
                          <div className="flex items-center justify-between text-sm mb-1">
                            <span>Completion Rate</span>
                            <span className="font-medium">65%</span>
                          </div>
                          <Progress value={65} className="h-2" />
                        </div>
                        
                        <div>
                          <div className="flex items-center justify-between text-sm mb-1">
                            <span>Satisfaction Score</span>
                            <span className="font-medium">4.2/5</span>
                          </div>
                          <Progress value={84} className="h-2" />
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="font-medium mb-3">Learning Patterns</h3>
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center justify-between">
                          <span>Most Active Time</span>
                          <span className="font-medium">2:00 PM - 4:00 PM</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Preferred Content Type</span>
                          <span className="font-medium">Video Lectures</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Average Session Duration</span>
                          <span className="font-medium">45 minutes</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>Streak</span>
                          <span className="font-medium">12 days</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* AI Insights */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">AI Insights</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <div className="font-medium text-sm text-blue-800 mb-1">
                        🧠 Learning Pattern Detected
                      </div>
                      <div className="text-xs text-blue-700">
                        You learn best with visual content in the afternoon. Schedule video tutorials during 2-4 PM for optimal retention.
                      </div>
                    </div>
                    
                    <div className="p-3 bg-green-50 rounded-lg">
                      <div className="font-medium text-sm text-green-800 mb-1">
                        📈 Progress Opportunity
                      </div>
                      <div className="text-xs text-green-700">
                        Your quantum physics progress is excellent. Consider advancing to quantum computing topics.
                      </div>
                    </div>
                    
                    <div className="p-3 bg-yellow-50 rounded-lg">
                      <div className="font-medium text-sm text-yellow-800 mb-1">
                        ⚠️ Attention Needed
                      </div>
                      <div className="text-xs text-yellow-700">
                        Your fractal geometry progress has stalled. Try switching to hands-on coding exercises.
                      </div>
                    </div>
                    
                    <div className="p-3 bg-purple-50 rounded-lg">
                      <div className="font-medium text-sm text-purple-800 mb-1">
                        🎯 Goal Alignment
                      </div>
                      <div className="text-xs text-purple-700">
                        Current activities align well with your goal to master quantum mechanics.
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Recommendation Quality */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recommendation Quality</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="text-sm font-medium mb-2">Accuracy Metrics</div>
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <span className="text-muted-foreground">Precision:</span>
                          <span className="font-medium ml-1">85%</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Recall:</span>
                          <span className="font-medium ml-1">78%</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">F1 Score:</span>
                          <span className="font-medium ml-1">81%</span>
                        </div>
                        <div>
                          <span className="text-muted-foreground">Diversity:</span>
                          <span className="font-medium ml-1">73%</span>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <div className="text-sm font-medium mb-2">Feedback Summary</div>
                      <div className="space-y-2 text-xs">
                        <div className="flex items-center justify-between">
                          <span>👍 Positive Feedback</span>
                          <span className="font-medium">89%</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>👎 Negative Feedback</span>
                          <span className="font-medium">11%</span>
                        </div>
                        <div className="flex items-center justify-between">
                          <span>💡 Suggestions Implemented</span>
                          <span className="font-medium">67%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}