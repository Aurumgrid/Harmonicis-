"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import DateUtils from "@/lib/date-utils";

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  rarity: "common" | "rare" | "epic" | "legendary" | "mythic";
  category: string;
  unlocked: boolean;
  unlockedDate?: string;
  progress: number;
  maxProgress: number;
  xpReward: number;
  requirements: string[];
  hidden: boolean;
  secret?: boolean;
}

interface UserStats {
  level: number;
  experience: number;
  totalAchievements: number;
  unlockedAchievements: number;
  currentStreak: number;
  longestStreak: number;
  totalPlayTime: number; // in hours
  sessionsCompleted: number;
  resourcesCompleted: number;
  perfectSessions: number;
}

interface AchievementEvent {
  id: string;
  type: "unlock" | "progress" | "milestone";
  achievementId: string;
  title: string;
  description: string;
  timestamp: string;
  xp?: number;
}

interface LeaderboardEntry {
  rank: number;
  userId: string;
  userName: string;
  userAvatar: string;
  level: number;
  achievements: number;
  xp: number;
  completionRate: number;
}

interface SeasonalEvent {
  id: string;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  isActive: boolean;
  achievements: string[];
  rewards: string[];
}

export default function AchievementSystem() {
  const [achievements, setAchievements] = useState<Achievement[]>([]);
  const [userStats, setUserStats] = useState<UserStats | null>(null);
  const [recentEvents, setRecentEvents] = useState<AchievementEvent[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [seasonalEvents, setSeasonalEvents] = useState<SeasonalEvent[]>([]);
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedRarity, setSelectedRarity] = useState("all");
  const [showHidden, setShowHidden] = useState(false);

  // Sample achievements
  const sampleAchievements: Achievement[] = [
    {
      id: "ach1",
      name: "First Steps",
      description: "Complete your first learning resource",
      icon: "👶",
      rarity: "common",
      category: "Progression",
      unlocked: true,
      unlockedDate: "2024-01-15T10:30:00Z",
      progress: 1,
      maxProgress: 1,
      xpReward: 50,
      requirements: ["Complete any resource"],
      hidden: false
    },
    {
      id: "ach2",
      name: "Quantum Pioneer",
      description: "Complete your first quantum physics resource",
      icon: "⚛️",
      rarity: "rare",
      category: "Quantum Physics",
      unlocked: true,
      unlockedDate: "2024-01-22T14:30:00Z",
      progress: 1,
      maxProgress: 1,
      xpReward: 150,
      requirements: ["Complete quantum physics resource"],
      hidden: false
    },
    {
      id: "ach3",
      name: "Fractal Master",
      description: "Complete 5 fractal-related resources",
      icon: "🔺",
      rarity: "epic",
      category: "Fractals",
      unlocked: true,
      unlockedDate: "2024-01-20T16:45:00Z",
      progress: 5,
      maxProgress: 5,
      xpReward: 300,
      requirements: ["Complete 5 fractal resources"],
      hidden: false
    },
    {
      id: "ach4",
      name: "Portal Explorer",
      description: "Explore all 6 knowledge dimensions",
      icon: "🌀",
      rarity: "epic",
      category: "Exploration",
      unlocked: true,
      unlockedDate: "2024-01-18T12:15:00Z",
      progress: 6,
      maxProgress: 6,
      xpReward: 350,
      requirements: ["Visit all knowledge dimensions"],
      hidden: false
    },
    {
      id: "ach5",
      name: "Speed Learner",
      description: "Complete a resource in under 30 hours",
      icon: "⚡",
      rarity: "rare",
      category: "Efficiency",
      unlocked: false,
      progress: 1,
      maxProgress: 3,
      xpReward: 200,
      requirements: ["Complete resource quickly"],
      hidden: false
    },
    {
      id: "ach6",
      name: "Social Butterfly",
      description: "Connect with 20+ friends",
      icon: "🦋",
      rarity: "common",
      category: "Social",
      unlocked: true,
      unlockedDate: "2024-01-15T09:20:00Z",
      progress: 24,
      maxProgress: 20,
      xpReward: 100,
      requirements: ["Connect with friends"],
      hidden: false
    },
    {
      id: "ach7",
      name: "Time Traveler",
      description: "Maintain a 30-day learning streak",
      icon: "⏰",
      rarity: "legendary",
      category: "Consistency",
      unlocked: false,
      progress: 7,
      maxProgress: 30,
      xpReward: 500,
      requirements: ["Daily learning for 30 days"],
      hidden: false
    },
    {
      id: "ach8",
      name: "Knowledge Seeker",
      description: "Accumulate 5000 XP",
      icon: "📚",
      rarity: "epic",
      category: "Progression",
      unlocked: false,
      progress: 2840,
      maxProgress: 5000,
      xpReward: 400,
      requirements: ["Earn experience points"],
      hidden: false
    },
    {
      id: "ach9",
      name: "Perfect Session",
      description: "Complete 10 learning sessions without mistakes",
      icon: "💯",
      rarity: "rare",
      category: "Perfection",
      unlocked: false,
      progress: 3,
      maxProgress: 10,
      xpReward: 250,
      requirements: ["Error-free sessions"],
      hidden: false
    },
    {
      id: "ach10",
      name: "Community Leader",
      description: "Join 10+ communities and help 50+ members",
      icon: "👑",
      rarity: "epic",
      category: "Social",
      unlocked: false,
      progress: 3,
      maxProgress: 10,
      xpReward: 350,
      requirements: ["Community engagement"],
      hidden: false
    },
    {
      id: "ach11",
      name: "Quantum God",
      description: "Master all quantum physics concepts and resources",
      icon: "🌟",
      rarity: "mythic",
      category: "Mastery",
      unlocked: false,
      progress: 45,
      maxProgress: 100,
      xpReward: 1000,
      requirements: ["Complete all quantum content"],
      hidden: false
    },
    {
      id: "ach12",
      name: "Secret Keeper",
      description: "Discover the hidden secrets of the Time Portal",
      icon: "🔐",
      rarity: "legendary",
      category: "Secret",
      unlocked: false,
      progress: 0,
      maxProgress: 1,
      xpReward: 750,
      requirements: ["Find hidden elements"],
      hidden: true,
      secret: true
    }
  ];

  // Sample user stats
  const sampleUserStats: UserStats = {
    level: 12,
    experience: 2840,
    totalAchievements: 12,
    unlockedAchievements: 4,
    currentStreak: 7,
    longestStreak: 15,
    totalPlayTime: 156,
    sessionsCompleted: 89,
    resourcesCompleted: 23,
    perfectSessions: 3
  };

  // Sample recent events
  const sampleRecentEvents: AchievementEvent[] = [
    {
      id: "event1",
      type: "unlock",
      achievementId: "ach2",
      title: "Achievement Unlocked!",
      description: "You've earned 'Quantum Pioneer'",
      timestamp: "2024-01-22T14:30:00Z",
      xp: 150
    },
    {
      id: "event2",
      type: "progress",
      achievementId: "ach7",
      title: "Streak Progress",
      description: "7 day streak - keep it up!",
      timestamp: "2024-01-22T09:15:00Z"
    },
    {
      id: "event3",
      type: "unlock",
      achievementId: "ach3",
      title: "Achievement Unlocked!",
      description: "You've earned 'Fractal Master'",
      timestamp: "2024-01-20T16:45:00Z",
      xp: 300
    },
    {
      id: "event4",
      type: "milestone",
      achievementId: "progress",
      title: "Level Up!",
      description: "Reached level 12",
      timestamp: "2024-01-20T09:20:00Z",
      xp: 200
    },
    {
      id: "event5",
      type: "unlock",
      achievementId: "ach4",
      title: "Achievement Unlocked!",
      description: "You've earned 'Portal Explorer'",
      timestamp: "2024-01-18T12:15:00Z",
      xp: 350
    }
  ];

  // Sample leaderboard
  const sampleLeaderboard: LeaderboardEntry[] = [
    {
      rank: 1,
      userId: "user1",
      userName: "QuantumMaster",
      userAvatar: "🏆",
      level: 25,
      achievements: 45,
      xp: 6250,
      completionRate: 92
    },
    {
      rank: 2,
      userId: "user2",
      userName: "FractalWizard",
      userAvatar: "🧙",
      level: 23,
      achievements: 38,
      xp: 5750,
      completionRate: 88
    },
    {
      rank: 3,
      userId: "user3",
      userName: "PortalExplorer",
      userAvatar: "🚪",
      level: 21,
      achievements: 32,
      xp: 5250,
      completionRate: 85
    },
    {
      rank: 4,
      userId: "user4",
      userName: "TimeTraveler",
      userAvatar: "🚀",
      level: 12,
      achievements: 4,
      xp: 2840,
      completionRate: 67
    },
    {
      rank: 5,
      userId: "user5",
      userName: "MathWhiz",
      userAvatar: "🧮",
      level: 18,
      achievements: 28,
      xp: 4500,
      completionRate: 78
    }
  ];

  // Sample seasonal events
  const sampleSeasonalEvents: SeasonalEvent[] = [
    {
      id: "event1",
      name: "Quantum Week",
      description: "Special quantum physics challenges and rewards",
      startDate: "2024-01-15T00:00:00Z",
      endDate: "2024-01-22T23:59:59Z",
      isActive: false,
      achievements: ["ach2", "ach11"],
      rewards: ["Quantum Badge", "500 XP", "Exclusive Avatar"]
    },
    {
      id: "event2",
      name: "Fractal Festival",
      description: "Celebrate the beauty of fractals with special achievements",
      startDate: "2024-01-20T00:00:00Z",
      endDate: "2024-01-27T23:59:59Z",
      isActive: true,
      achievements: ["ach3", "ach9"],
      rewards: ["Fractal Badge", "300 XP", "Special Effects"]
    },
    {
      id: "event3",
      name: "Portal Marathon",
      description: "Explore all dimensions in this week-long event",
      startDate: "2024-01-25T00:00:00Z",
      endDate: "2024-02-01T23:59:59Z",
      isActive: true,
      achievements: ["ach4", "ach7"],
      rewards: ["Portal Badge", "400 XP", "Cosmetic Items"]
    }
  ];

  useEffect(() => {
    setAchievements(sampleAchievements);
    setUserStats(sampleUserStats);
    setRecentEvents(sampleRecentEvents);
    setLeaderboard(sampleLeaderboard);
    setSeasonalEvents(sampleSeasonalEvents);
  }, []);

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "common": return "bg-gray-100 text-gray-800";
      case "rare": return "bg-blue-100 text-blue-800";
      case "epic": return "bg-purple-100 text-purple-800";
      case "legendary": return "bg-yellow-100 text-yellow-800";
      case "mythic": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getRarityOrder = (rarity: string) => {
    switch (rarity) {
      case "common": return 1;
      case "rare": return 2;
      case "epic": return 3;
      case "legendary": return 4;
      case "mythic": return 5;
      default: return 0;
    }
  };

  const getEventIcon = (type: string) => {
    switch (type) {
      case "unlock": return "🏆";
      case "progress": return "📈";
      case "milestone": return "🎯";
      default: return "📝";
    }
  };

  const getEventColor = (type: string) => {
    switch (type) {
      case "unlock": return "text-yellow-600";
      case "progress": return "text-blue-600";
      case "milestone": return "text-green-600";
      default: return "text-gray-600";
    }
  };

  const filteredAchievements = achievements.filter(achievement => {
    const matchesCategory = selectedCategory === "all" || achievement.category === selectedCategory;
    const matchesRarity = selectedRarity === "all" || achievement.rarity === selectedRarity;
    const matchesHidden = !achievement.hidden || showHidden;
    return matchesCategory && matchesRarity && matchesHidden;
  });

  const categories = Array.from(new Set(achievements.map(a => a.category)));
  const rarities = Array.from(new Set(achievements.map(a => a.rarity)));

  const unlockedAchievements = achievements.filter(a => a.unlocked);
  const totalXP = unlockedAchievements.reduce((sum, a) => sum + a.xpReward, 0);

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Achievement System</h1>
        <p className="text-muted-foreground">
          Gamify your learning journey with achievements, milestones, and rewards
        </p>
      </div>

      {/* User Stats Overview */}
      {userStats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Level & XP</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                Level {userStats.level}
              </div>
              <div className="text-sm text-muted-foreground mb-2">
                {userStats.experience} XP
              </div>
              <Progress value={(userStats.experience % 1000) / 10} className="h-2" />
              <div className="text-xs text-muted-foreground mt-1">
                {1000 - (userStats.experience % 1000)} XP to next level
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Achievements</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {userStats.unlockedAchievements}
              </div>
              <Progress value={(userStats.unlockedAchievements / userStats.totalAchievements) * 100} className="h-2 mt-2" />
              <div className="text-xs text-muted-foreground mt-1">
                {userStats.totalAchievements - userStats.unlockedAchievements} remaining
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Current Streak</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">
                {userStats.currentStreak} days
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Best: {userStats.longestStreak} days
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Total XP from Achievements</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                {totalXP}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                From {unlockedAchievements.length} achievements
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="progress">Progress</TabsTrigger>
          <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
          <TabsTrigger value="events">Events</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              {/* Recent Activity */}
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                  <CardDescription>
                    Your latest achievements and milestones
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-3">
                      {recentEvents.map((event) => (
                        <div key={event.id} className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                          <span className={`text-lg ${getEventColor(event.type)}`}>
                            {getEventIcon(event.type)}
                          </span>
                          <div className="flex-1">
                            <div className="font-medium text-sm">{event.title}</div>
                            <div className="text-xs text-muted-foreground">
                              {event.description}
                            </div>
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-xs text-muted-foreground">
                                {DateUtils.formatDisplay(event.timestamp, { 
                                  month: 'short', 
                                  day: 'numeric', 
                                  hour: '2-digit', 
                                  minute: '2-digit' 
                                })}
                              </span>
                              {event.xp && (
                                <Badge variant="outline" className="text-xs">
                                  +{event.xp} XP
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>

              {/* Achievement Categories */}
              <Card>
                <CardHeader>
                  <CardTitle>Achievement Categories</CardTitle>
                  <CardDescription>
                    Progress across different achievement categories
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {categories.map((category) => {
                      const categoryAchievements = achievements.filter(a => a.category === category);
                      const unlockedInCategory = categoryAchievements.filter(a => a.unlocked).length;
                      const categoryProgress = (unlockedInCategory / categoryAchievements.length) * 100;
                      
                      return (
                        <div key={category}>
                          <div className="flex items-center justify-between mb-2">
                            <span className="text-sm font-medium">{category}</span>
                            <span className="text-sm text-muted-foreground">
                              {unlockedInCategory}/{categoryAchievements.length}
                            </span>
                          </div>
                          <Progress value={categoryProgress} className="h-2" />
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Next Goals */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Next Goals</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {achievements
                      .filter(a => !a.unlocked && a.progress > 0)
                      .sort((a, b) => (b.progress / b.maxProgress) - (a.progress / a.maxProgress))
                      .slice(0, 3)
                      .map((achievement) => (
                        <div key={achievement.id} className="p-3 bg-muted rounded-lg">
                          <div className="flex items-center gap-2 mb-2">
                            <span className="text-lg">{achievement.icon}</span>
                            <div className="flex-1">
                              <div className="font-medium text-sm">{achievement.name}</div>
                              <Badge className={getRarityColor(achievement.rarity)}>
                                {achievement.rarity}
                              </Badge>
                            </div>
                          </div>
                          
                          <div className="space-y-2">
                            <div className="flex items-center justify-between text-xs">
                              <span>Progress</span>
                              <span>{achievement.progress}/{achievement.maxProgress}</span>
                            </div>
                            <Progress value={(achievement.progress / achievement.maxProgress) * 100} className="h-2" />
                          </div>
                          
                          <div className="text-xs text-muted-foreground">
                            {achievement.xpReward} XP reward
                          </div>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
              
              {/* Seasonal Events */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Seasonal Events</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {seasonalEvents
                      .filter(event => event.isActive)
                      .map((event) => (
                        <div key={event.id} className="p-3 border rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="font-medium text-sm">{event.name}</h3>
                            <Badge variant="outline" className="text-xs text-green-600">
                              Active
                            </Badge>
                          </div>
                          <p className="text-xs text-muted-foreground mb-2">
                            {event.description}
                          </p>
                          <div className="text-xs text-muted-foreground">
                            Ends: {DateUtils.formatDisplay(event.endDate, { 
                              month: 'short', 
                              day: 'numeric' 
                            })}
                          </div>
                        </div>
                      ))}
                  </div>
                  
                  <Button variant="outline" className="w-full mt-3">
                    View All Events
                  </Button>
                </CardContent>
              </Card>
              
              {/* Quick Stats */}
              {userStats && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Learning Stats</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm">
                        <span>Total Play Time</span>
                        <span className="font-medium">{userStats.totalPlayTime}h</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>Sessions Completed</span>
                        <span className="font-medium">{userStats.sessionsCompleted}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>Resources Completed</span>
                        <span className="font-medium">{userStats.resourcesCompleted}</span>
                      </div>
                      <div className="flex items-center justify-between text-sm">
                        <span>Perfect Sessions</span>
                        <span className="font-medium">{userStats.perfectSessions}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="achievements" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-3">
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>All Achievements</CardTitle>
                      <CardDescription>
                        Browse and track your achievement progress
                      </CardDescription>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={showHidden}
                        onCheckedChange={setShowHidden}
                      />
                      <span className="text-sm">Show Hidden</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {/* Filters */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="Category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        {categories.map(category => (
                          <SelectItem key={category} value={category}>{category}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    
                    <Select value={selectedRarity} onValueChange={setSelectedRarity}>
                      <SelectTrigger>
                        <SelectValue placeholder="Rarity" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Rarities</SelectItem>
                        {rarities.map(rarity => (
                          <SelectItem key={rarity} value={rarity}>{rarity}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  {/* Achievement Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {filteredAchievements
                      .sort((a, b) => {
                        // Sort by rarity first, then by unlocked status
                        if (a.unlocked !== b.unlocked) {
                          return b.unlocked ? 1 : -1;
                        }
                        return getRarityOrder(b.rarity) - getRarityOrder(a.rarity);
                      })
                      .map((achievement) => (
                        <Card 
                          key={achievement.id} 
                          className={`transition-all ${achievement.unlocked ? 'ring-2 ring-yellow-400' : 'opacity-60'}`}
                        >
                          <CardHeader className="pb-2">
                            <div className="flex items-center gap-3">
                              <span className={`text-2xl ${achievement.unlocked ? '' : 'grayscale'}`}>
                                {achievement.icon}
                              </span>
                              <div className="flex-1">
                                <CardTitle className="text-sm">{achievement.name}</CardTitle>
                                <CardDescription className="text-xs">
                                  {achievement.category}
                                </CardDescription>
                              </div>
                              <Badge className={getRarityColor(achievement.rarity)}>
                                {achievement.rarity}
                              </Badge>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <p className="text-xs text-muted-foreground mb-3">
                              {achievement.description}
                            </p>
                            
                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-xs">
                                <span>Progress</span>
                                <span>{achievement.progress}/{achievement.maxProgress}</span>
                              </div>
                              <Progress 
                                value={(achievement.progress / achievement.maxProgress) * 100} 
                                className="h-2"
                              />
                            </div>
                            
                            <div className="flex items-center justify-between text-xs">
                              <span>XP Reward</span>
                              <span className="font-medium">+{achievement.xpReward} XP</span>
                            </div>
                            
                            {achievement.unlocked && achievement.unlockedDate && (
                              <div className="text-xs text-green-600 mt-2">
                                Unlocked on {DateUtils.formatDisplay(achievement.unlockedDate, { 
                                  month: 'short', 
                                  day: 'numeric', 
                                  year: 'numeric' 
                                })}
                              </div>
                            )}
                            
                            {achievement.secret && (
                              <div className="text-xs text-purple-600 mt-1">
                                🔐 Secret Achievement
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Achievement Stats */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Achievement Stats</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Total Achievements</span>
                      <span className="font-medium">
                        {unlockedAchievements.length}/{achievements.length}
                      </span>
                    </div>
                    <Progress 
                      value={(unlockedAchievements.length / achievements.length) * 100} 
                      className="h-2"
                    />
                    
                    <div className="grid grid-cols-2 gap-2 mt-4">
                      <div className="text-center">
                        <div className="text-lg font-bold text-yellow-600">
                          {achievements.filter(a => a.rarity === "legendary" && a.unlocked).length}
                        </div>
                        <div className="text-xs text-muted-foreground">Legendary</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-red-600">
                          {achievements.filter(a => a.rarity === "mythic" && a.unlocked).length}
                        </div>
                        <div className="text-xs text-muted-foreground">Mythic</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Rarity Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Rarity Distribution</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {rarities.map((rarity) => {
                      const rarityAchievements = achievements.filter(a => a.rarity === rarity);
                      const unlockedInRarity = rarityAchievements.filter(a => a.unlocked).length;
                      const rarityProgress = (unlockedInRarity / rarityAchievements.length) * 100;
                      
                      return (
                        <div key={rarity}>
                          <div className="flex items-center justify-between mb-1">
                            <span className="text-sm capitalize">{rarity}</span>
                            <span className="text-xs text-muted-foreground">
                              {unlockedInRarity}/{rarityAchievements.length}
                            </span>
                          </div>
                          <Progress value={rarityProgress} className="h-2" />
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
              
              {/* Recent Unlocks */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recent Unlocks</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {achievements
                      .filter(a => a.unlocked && a.unlockedDate)
                      .sort((a, b) => new Date(b.unlockedDate!).getTime() - new Date(a.unlockedDate!).getTime())
                      .slice(0, 3)
                      .map((achievement) => (
                        <div key={achievement.id} className="flex items-center gap-3">
                          <span className="text-lg">{achievement.icon}</span>
                          <div className="flex-1">
                            <div className="font-medium text-sm">{achievement.name}</div>
                            <div className="text-xs text-muted-foreground">
                              {DateUtils.formatDisplay(achievement.unlockedDate!, { 
                                month: 'short', 
                                day: 'numeric' 
                              })}
                            </div>
                          </div>
                          <Badge className={getRarityColor(achievement.rarity)}>
                            {achievement.rarity}
                          </Badge>
                        </div>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="progress" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Progress Tracking</CardTitle>
                  <CardDescription>
                    Detailed progress on in-progress achievements
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {achievements
                      .filter(a => !a.unlocked && a.progress > 0)
                      .sort((a, b) => (b.progress / b.maxProgress) - (a.progress / a.maxProgress))
                      .map((achievement) => (
                        <Card key={achievement.id}>
                          <CardHeader className="pb-2">
                            <div className="flex items-center gap-3">
                              <span className="text-xl">{achievement.icon}</span>
                              <div className="flex-1">
                                <CardTitle className="text-sm">{achievement.name}</CardTitle>
                                <CardDescription className="text-xs">
                                  {achievement.category}
                                </CardDescription>
                              </div>
                              <Badge className={getRarityColor(achievement.rarity)}>
                                {achievement.rarity}
                              </Badge>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <p className="text-xs text-muted-foreground mb-3">
                              {achievement.description}
                            </p>
                            
                            <div className="space-y-2">
                              <div className="flex items-center justify-between text-xs">
                                <span>Progress</span>
                                <span>{achievement.progress}/{achievement.maxProgress}</span>
                              </div>
                              <Progress value={(achievement.progress / achievement.maxProgress) * 100} className="h-2" />
                              <div className="text-xs text-muted-foreground">
                                {Math.round((achievement.progress / achievement.maxProgress) * 100)}% complete
                              </div>
                            </div>
                            
                            <div className="text-xs text-muted-foreground mt-2">
                              <strong>Requirements:</strong> {achievement.requirements.join(", ")}
                            </div>
                            
                            <div className="text-xs text-blue-600 mt-2">
                              💡 Tip: {achievement.progress === 0 ? "Start working on this achievement!" : "Keep going, you're making great progress!"}
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Progress Overview */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Progress Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="text-sm font-medium mb-2">Overall Progress</div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm">Achievement Completion</span>
                        <span className="text-sm font-medium">
                          {Math.round((unlockedAchievements.length / achievements.length) * 100)}%
                        </span>
                      </div>
                      <Progress value={(unlockedAchievements.length / achievements.length) * 100} className="h-2" />
                    </div>
                    
                    <div>
                      <div className="text-sm font-medium mb-2">By Category</div>
                      <div className="space-y-2">
                        {categories.map((category) => {
                          const categoryAchievements = achievements.filter(a => a.category === category);
                          const unlockedInCategory = categoryAchievements.filter(a => a.unlocked).length;
                          const categoryProgress = (unlockedInCategory / categoryAchievements.length) * 100;
                          
                          return (
                            <div key={category}>
                              <div className="flex items-center justify-between text-xs">
                                <span>{category}</span>
                                <span className="font-medium">{Math.round(categoryProgress)}%</span>
                              </div>
                              <Progress value={categoryProgress} className="h-1" />
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Upcoming Milestones */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Upcoming Milestones</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <div className="font-medium text-sm text-blue-800 mb-1">
                        🎯 Next Achievement
                      </div>
                      <div className="text-xs text-blue-700">
                        Complete 2 more resources to unlock "Speed Learner"
                      </div>
                    </div>
                    
                    <div className="p-3 bg-green-50 rounded-lg">
                      <div className="font-medium text-sm text-green-800 mb-1">
                        📈 Level Milestone
                      </div>
                      <div className="text-xs text-green-700">
                        720 XP to reach Level 13
                      </div>
                    </div>
                    
                    <div className="p-3 bg-purple-50 rounded-lg">
                      <div className="font-medium text-sm text-purple-800 mb-1">
                        🏆 Category Master
                      </div>
                      <div className="text-xs text-purple-700">
                        Complete 2 more Progression achievements
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Achievement Tips */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Achievement Tips</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div>
                      <div className="font-medium mb-1">🎯 Focus on Progress</div>
                      <div className="text-muted-foreground">
                        Work on achievements that you're close to completing first.
                      </div>
                    </div>
                    
                    <div>
                      <div className="font-medium mb-1">📅 Daily Goals</div>
                      <div className="text-muted-foreground">
                        Set small daily goals to maintain your learning streak.
                      </div>
                    </div>
                    
                    <div>
                      <div className="font-medium mb-1">🌟 Quality Over Quantity</div>
                      <div className="text-muted-foreground">
                        Focus on understanding rather than rushing through content.
                      </div>
                    </div>
                    
                    <div>
                      <div className="font-medium mb-1">🤝 Join Communities</div>
                      <div className="text-muted-foreground">
                        Engage with others to unlock social achievements.
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="leaderboard" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Global Leaderboard</CardTitle>
                  <CardDescription>
                    Top achievers in the Time Portal community
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {/* Current user position */}
                    {userStats && (
                      <Card className="border-blue-500">
                        <CardContent className="p-4">
                          <div className="flex items-center gap-4">
                            <div className="text-2xl font-bold text-blue-600">#?</div>
                            <Avatar className="w-12 h-12">
                              <AvatarFallback className="text-xl">🚀</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="font-medium">Time Traveler (You)</div>
                              <div className="text-sm text-muted-foreground">
                                Level {userStats.level} • {userStats.experience} XP
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-bold text-lg">{userStats.unlockedAchievements}</div>
                              <div className="text-xs text-muted-foreground">Achievements</div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    )}
                    
                    {leaderboard.map((entry) => (
                      <Card key={entry.userId} className={entry.rank <= 3 ? 'border-yellow-400' : ''}>
                        <CardContent className="p-4">
                          <div className="flex items-center gap-4">
                            <div className={`text-2xl font-bold ${
                              entry.rank === 1 ? 'text-yellow-500' : 
                              entry.rank === 2 ? 'text-gray-400' : 
                              entry.rank === 3 ? 'text-orange-600' : 'text-muted-foreground'
                            }`}>
                              #{entry.rank}
                            </div>
                            <Avatar className="w-12 h-12">
                              <AvatarImage src={entry.userAvatar} />
                              <AvatarFallback className="text-xl">{entry.userAvatar}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="font-medium">{entry.userName}</div>
                              <div className="text-sm text-muted-foreground">
                                Level {entry.level} • {entry.xp} XP
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="font-bold text-lg">{entry.achievements}</div>
                              <div className="text-xs text-muted-foreground">Achievements</div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Leaderboard Filters */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Filters</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Time Period" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Time</SelectItem>
                        <SelectItem value="monthly">This Month</SelectItem>
                        <SelectItem value="weekly">This Week</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Region" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="global">Global</SelectItem>
                        <SelectItem value="local">Local</SelectItem>
                        <SelectItem value="friends">Friends</SelectItem>
                      </SelectContent>
                    </Select>
                    
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All Categories</SelectItem>
                        <SelectItem value="quantum">Quantum Physics</SelectItem>
                        <SelectItem value="fractals">Fractals</SelectItem>
                        <SelectItem value="portals">Dimensional Portals</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
              
              {/* Your Ranking */}
              {userStats && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Your Ranking</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600">#42</div>
                        <div className="text-sm text-muted-foreground">Global Rank</div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div className="text-center">
                          <div className="text-lg font-bold text-green-600">#8</div>
                          <div className="text-xs text-muted-foreground">Friends Rank</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-bold text-purple-600">#15</div>
                          <div className="text-xs text-muted-foreground">Local Rank</div>
                        </div>
                      </div>
                      
                      <Separator />
                      
                      <div className="text-center">
                        <div className="text-sm font-medium">Next Rank: Quantum Master</div>
                        <div className="text-xs text-muted-foreground">Need 2,160 more XP</div>
                        <Progress value={(userStats.experience / 5000) * 100} className="mt-2" />
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
              
              {/* Leaderboard Rewards */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Season Rewards</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-yellow-50 rounded-lg">
                      <div className="font-medium text-sm text-yellow-800 mb-1">
                        🥇 Top 10%
                      </div>
                      <div className="text-xs text-yellow-700">
                        Exclusive avatar frame and badge
                      </div>
                    </div>
                    
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <div className="font-medium text-sm text-gray-800 mb-1">
                        🥈 Top 25%
                      </div>
                      <div className="text-xs text-gray-700">
                        Special profile customization options
                      </div>
                    </div>
                    
                    <div className="p-3 bg-orange-50 rounded-lg">
                      <div className="font-medium text-sm text-orange-800 mb-1">
                        🥉 Top 50%
                      </div>
                      <div className="text-xs text-orange-700">
                        Bonus XP and achievement boost
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="events" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Seasonal Events</CardTitle>
                  <CardDescription>
                    Limited-time events with exclusive achievements and rewards
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {seasonalEvents.map((event) => (
                      <Card key={event.id} className={`border-l-4 ${event.isActive ? 'border-l-green-500' : 'border-l-gray-300'}`}>
                        <CardHeader className="pb-2">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-sm">{event.name}</CardTitle>
                            <Badge variant={event.isActive ? "default" : "secondary"}>
                              {event.isActive ? "Active" : "Ended"}
                            </Badge>
                          </div>
                          <CardDescription className="text-xs">
                            {event.description}
                          </CardDescription>
                        </CardHeader>
                        <CardContent>
                          <div className="space-y-3">
                            <div className="grid grid-cols-2 gap-4 text-xs">
                              <div>
                                <span className="text-muted-foreground">Start:</span>
                                <span className="font-medium ml-1">
                                  {DateUtils.formatDisplay(event.startDate, { 
                                    month: 'short', 
                                    day: 'numeric' 
                                  })}
                                </span>
                              </div>
                              <div>
                                <span className="text-muted-foreground">End:</span>
                                <span className="font-medium ml-1">
                                  {DateUtils.formatDisplay(event.endDate, { 
                                    month: 'short', 
                                    day: 'numeric' 
                                  })}
                                </span>
                              </div>
                            </div>
                            
                            <div>
                              <div className="text-xs font-medium mb-1">Exclusive Achievements</div>
                              <div className="flex flex-wrap gap-1">
                                {event.achievements.map((achievementId, index) => {
                                  const achievement = achievements.find(a => a.id === achievementId);
                                  return (
                                    <Badge key={index} variant="outline" className="text-xs">
                                      {achievement?.icon || '🏆'} {achievement?.name || 'Special Achievement'}
                                    </Badge>
                                  );
                                })}
                              </div>
                            </div>
                            
                            <div>
                              <div className="text-xs font-medium mb-1">Rewards</div>
                              <div className="text-xs text-muted-foreground">
                                {event.rewards.join(", ")}
                              </div>
                            </div>
                            
                            {event.isActive && (
                              <Button variant="outline" size="sm" className="w-full">
                                Participate Now
                              </Button>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Event Calendar */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Event Calendar</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="text-center text-sm text-muted-foreground">
                      Upcoming Events
                    </div>
                    
                    <div className="space-y-2">
                      <div className="p-2 bg-blue-50 rounded">
                        <div className="text-sm font-medium">Quantum Challenge</div>
                        <div className="text-xs text-muted-foreground">
                          Feb 1-7, 2024
                        </div>
                      </div>
                      
                      <div className="p-2 bg-green-50 rounded">
                        <div className="text-sm font-medium">Mathematics Marathon</div>
                        <div className="text-xs text-muted-foreground">
                          Feb 15-21, 2024
                        </div>
                      </div>
                      
                      <div className="p-2 bg-purple-50 rounded">
                        <div className="text-sm font-medium">Portal Exploration</div>
                        <div className="text-xs text-muted-foreground">
                          Mar 1-14, 2024
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Event Statistics */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Event Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Events Participated</span>
                      <span className="font-medium">3</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Event Achievements</span>
                      <span className="font-medium">2</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Event Rewards</span>
                      <span className="font-medium">5</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Completion Rate</span>
                      <span className="font-medium">67%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Event Tips */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Event Tips</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div>
                      <div className="font-medium mb-1">📅 Plan Ahead</div>
                      <div className="text-muted-foreground">
                        Check event schedules and plan your participation.
                      </div>
                    </div>
                    
                    <div>
                      <div className="font-medium mb-1">🎯 Focus on Goals</div>
                      <div className="text-muted-foreground">
                        Prioritize event achievements over regular ones.
                      </div>
                    </div>
                    
                    <div>
                      <div className="font-medium mb-1">🤝 Team Up</div>
                      <div className="text-muted-foreground">
                        Some events have collaborative achievements.
                      </div>
                    </div>
                    
                    <div>
                      <div className="font-medium mb-1">⏰ Don't Wait</div>
                      <div className="text-muted-foreground">
                        Events are limited-time, so participate early.
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}