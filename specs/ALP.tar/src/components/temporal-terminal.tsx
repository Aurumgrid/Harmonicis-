"use client";

import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import DateUtils from "@/lib/date-utils";

interface TerminalSession {
  id: string;
  name: string;
  type: "quantum" | "fractal" | "portal" | "hofstadter" | "rorschach" | "mandelbrot";
  status: "active" | "idle" | "completed";
  startTime: string;
  lastActivity: string;
  commands: TerminalCommand[];
  variables: Record<string, string>;
  currentDirectory: string;
}

interface TerminalCommand {
  id: string;
  command: string;
  output: string;
  timestamp: string;
  type: "system" | "user" | "error" | "success";
}

interface FileSystemItem {
  name: string;
  type: "file" | "directory";
  size?: string;
  modified: string;
  permissions: string;
  content?: string;
}

interface TemporalTunnel {
  id: string;
  source: string;
  destination: string;
  status: "active" | "inactive" | "connecting";
  protocol: string;
  localPort: number;
  remotePort: number;
}

interface Collaborator {
  id: string;
  name: string;
  avatar: string;
  status: "online" | "offline" | "away";
  currentSession?: string;
  lastSeen: string;
}

export default function TemporalTerminal() {
  const [sessions, setSessions] = useState<TerminalSession[]>([]);
  const [activeSession, setActiveSession] = useState<string | null>(null);
  const [commandInput, setCommandInput] = useState("");
  const [fileSystem, setFileSystem] = useState<FileSystemItem[]>([]);
  const [tunnels, setTunnels] = useState<TemporalTunnel[]>([]);
  const [collaborators, setCollaborators] = useState<Collaborator[]>([]);
  const [activeTab, setActiveTab] = useState("terminal");
  const terminalEndRef = useRef<HTMLDivElement>(null);

  // Sample file system structure
  const sampleFileSystem: FileSystemItem[] = [
    {
      name: "quantum_physics",
      type: "directory",
      modified: "2024-01-22T14:30:00Z",
      permissions: "rwxr-xr-x"
    },
    {
      name: "fractals",
      type: "directory",
      modified: "2024-01-21T16:45:00Z",
      permissions: "rwxr-xr-x"
    },
    {
      name: "dimensional_portals",
      type: "directory",
      modified: "2024-01-20T12:15:00Z",
      permissions: "rwxr-xr-x"
    },
    {
      name: "hofstadter_butterfly",
      type: "directory",
      modified: "2024-01-19T09:20:00Z",
      permissions: "rwxr-xr-x"
    },
    {
      name: "rorschach_analysis",
      type: "directory",
      modified: "2024-01-18T18:30:00Z",
      permissions: "rwxr-xr-x"
    },
    {
      name: "mandelbrot_set",
      type: "directory",
      modified: "2024-01-17T11:20:00Z",
      permissions: "rwxr-xr-x"
    },
    {
      name: "README.md",
      type: "file",
      size: "2.3 KB",
      modified: "2024-01-22T14:30:00Z",
      permissions: "rw-r--r--",
      content: "# Time Portal - Temporal Learning Environment\n\nWelcome to the Time Portal terminal interface. This environment allows you to explore quantum physics, fractals, dimensional portals, and more through a command-line interface.\n\n## Getting Started\n\n- Use `help` to see available commands\n- Navigate directories using `cd` and `ls`\- Execute temporal simulations with `run`\n- Establish connections with `connect`\n\n## Available Modules\n\n- quantum_physics/\n- fractals/\n- dimensional_portals/\n- hofstadter_butterfly/\n- rorschach_analysis/\n- mandelbrot_set/"
    },
    {
      name: "config.json",
      type: "file",
      size: "890 B",
      modified: "2024-01-22T14:25:00Z",
      permissions: "rw-r--r--",
      content: '{\n  "terminal": {\n    "theme": "dark",\n    "fontSize": 14,\n    "fontFamily": "monospace"\n  },\n  "temporal": {\n    "syncInterval": 30000,\n    "backupEnabled": true,\n    "collaborationEnabled": true\n  },\n  "modules": {\n    "quantum": true,\n    "fractals": true,\n    "portals": true,\n    "hofstadter": true,\n    "rorschach": true,\n    "mandelbrot": true\n  }\n}'
    }
  ];

  // Sample tunnels
  const sampleTunnels: TemporalTunnel[] = [
    {
      id: "tunnel1",
      source: "localhost",
      destination: "quantum-realm",
      status: "active",
      protocol: "SSH",
      localPort: 8080,
      remotePort: 22
    },
    {
      id: "tunnel2",
      source: "localhost",
      destination: "fractal-dimension",
      status: "active",
      protocol: "TCP",
      localPort: 8081,
      remotePort: 8080
    },
    {
      id: "tunnel3",
      source: "localhost",
      destination: "portal-nexus",
      status: "connecting",
      protocol: "WebSocket",
      localPort: 8082,
      remotePort: 443
    }
  ];

  // Sample collaborators
  const sampleCollaborators: Collaborator[] = [
    {
      id: "collab1",
      name: "Alice",
      avatar: "🔬",
      status: "online",
      currentSession: "quantum_session_1",
      lastSeen: "2024-01-22T14:30:00Z"
    },
    {
      id: "collab2",
      name: "Bob",
      avatar: "👨‍💻",
      status: "online",
      currentSession: "fractal_session_1",
      lastSeen: "2024-01-22T14:25:00Z"
    },
    {
      id: "collab3",
      name: "Carol",
      avatar: "🎨",
      status: "away",
      currentSession: "rorschach_session_1",
      lastSeen: "2024-01-22T13:45:00Z"
    },
    {
      id: "collab4",
      name: "David",
      avatar: "🧮",
      status: "offline",
      lastSeen: "2024-01-21T22:15:00Z"
    }
  ];

  useEffect(() => {
    // Initialize file system
    setFileSystem(sampleFileSystem);
    setTunnels(sampleTunnels);
    setCollaborators(sampleCollaborators);

    // Create initial session
    const initialSession: TerminalSession = {
      id: "session_1",
      name: "Default Session",
      type: "quantum",
      status: "active",
      startTime: new Date().toISOString(),
      lastActivity: new Date().toISOString(),
      commands: [
        {
          id: "cmd1",
          command: "welcome",
          output: "Welcome to Time Portal Terminal v2.0\nType 'help' for available commands.",
          timestamp: new Date().toISOString(),
          type: "system"
        }
      ],
      variables: {
        USER: "time_traveler",
        HOME: "/home/time_traveler",
        PATH: "/usr/local/bin:/usr/bin:/bin",
        TEMPORAL_SYNC: "enabled"
      },
      currentDirectory: "/home/time_traveler"
    };

    setSessions([initialSession]);
    setActiveSession(initialSession.id);
  }, []);

  useEffect(() => {
    // Auto-scroll terminal to bottom
    if (terminalEndRef.current) {
      terminalEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [activeSession, sessions]);

  const executeCommand = (command: string) => {
    if (!activeSession) return;

    const session = sessions.find(s => s.id === activeSession);
    if (!session) return;

    const [cmd, ...args] = command.trim().split(' ');
    let output = "";
    let commandType: "system" | "user" | "error" | "success" = "user";

    switch (cmd.toLowerCase()) {
      case "help":
        output = `Available Commands:\n` +
          `  help              - Show this help message\n` +
          `  ls [path]         - List directory contents\n` +
          `  cd <path>         - Change directory\n` +
          `  pwd               - Print working directory\n` +
          `  cat <file>        - Display file contents\n` +
          `  run <module>      - Execute temporal simulation\n` +
          `  connect <target>  - Establish temporal connection\n` +
          `  tunnels           - List active tunnels\n` +
          `  sessions          - List active sessions\n` +
          `  clear             - Clear terminal screen\n` +
          `  who               - Show connected collaborators\n` +
          `  status            - Show system status\n` +
          `  env               - Show environment variables`;
        commandType = "system";
        break;

      case "ls":
        const path = args[0] || session.currentDirectory;
        output = fileSystem
          .filter(item => item.type === "directory")
          .map(item => `📁 ${item.name}`)
          .concat(
            fileSystem
              .filter(item => item.type === "file")
              .map(item => `📄 ${item.name}`)
          )
          .join('\n');
        commandType = "success";
        break;

      case "pwd":
        output = session.currentDirectory;
        commandType = "success";
        break;

      case "cat":
        const fileName = args[0];
        const file = fileSystem.find(item => item.name === fileName && item.type === "file");
        if (file) {
          output = file.content || "File content not available";
          commandType = "success";
        } else {
          output = `cat: ${fileName}: No such file or directory`;
          commandType = "error";
        }
        break;

      case "run":
        const module = args[0];
        if (module) {
          output = `Starting temporal simulation: ${module}\n` +
                   `Initializing quantum processors...\n` +
                   `Calibrating temporal coordinates...\n` +
                   `Simulation running at 87.3% efficiency\n` +
                   `Status: ACTIVE | Duration: 00:02:34`;
          commandType = "success";
        } else {
          output = "run: missing module argument";
          commandType = "error";
        }
        break;

      case "connect":
        const target = args[0];
        if (target) {
          output = `Establishing temporal connection to ${target}...\n` +
                   `Quantum entanglement established\n` +
                   `Temporal synchronization complete\n` +
                   `Connection secured with quantum encryption\n` +
                   `Status: CONNECTED | Latency: 0.003ms`;
          commandType = "success";
        } else {
          output = "connect: missing target argument";
          commandType = "error";
        }
        break;

      case "tunnels":
        output = tunnels.map(tunnel => 
          `${tunnel.id}: ${tunnel.source} -> ${tunnel.destination} (${tunnel.protocol}) [${tunnel.status}]`
        ).join('\n');
        commandType = "success";
        break;

      case "sessions":
        output = sessions.map(session => 
          `${session.id}: ${session.name} (${session.type}) [${session.status}]`
        ).join('\n');
        commandType = "success";
        break;

      case "clear":
        // Clear is handled differently - we'll clear the command history
        setSessions(prev => prev.map(s => 
          s.id === activeSession 
            ? { ...s, commands: [] }
            : s
        ));
        setCommandInput("");
        return;

      case "who":
        output = collaborators
          .filter(collab => collab.status === "online")
          .map(collab => `${collab.name} (${collab.avatar}) - ${collab.currentSession}`)
          .join('\n');
        commandType = "success";
        break;

      case "status":
        output = `System Status: OPERATIONAL\n` +
                 `Temporal Sync: ACTIVE\n` +
                 `Quantum Processors: 87.3% efficiency\n` +
                 `Active Sessions: ${sessions.length}\n` +
                 `Active Tunnels: ${tunnels.filter(t => t.status === "active").length}\n` +
                 `Connected Collaborators: ${collaborators.filter(c => c.status === "online").length}\n` +
                 `System Time: ${new Date().toISOString()}`;
        commandType = "success";
        break;

      case "env":
        output = Object.entries(session.variables)
          .map(([key, value]) => `${key}=${value}`)
          .join('\n');
        commandType = "success";
        break;

      default:
        output = `Command not found: ${cmd}. Type 'help' for available commands.`;
        commandType = "error";
        break;
    }

    const newCommand: TerminalCommand = {
      id: `cmd_${Date.now()}`,
      command: command,
      output,
      timestamp: new Date().toISOString(),
      type: commandType
    };

    setSessions(prev => prev.map(s => 
      s.id === activeSession 
        ? { 
            ...s, 
            commands: [...s.commands, newCommand],
            lastActivity: new Date().toISOString()
          }
        : s
    ));

    setCommandInput("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && commandInput.trim()) {
      executeCommand(commandInput);
    }
  };

  const createNewSession = (type: TerminalSession["type"]) => {
    const newSession: TerminalSession = {
      id: `session_${Date.now()}`,
      name: `${type.charAt(0).toUpperCase() + type.slice(1)} Session`,
      type,
      status: "active",
      startTime: new Date().toISOString(),
      lastActivity: new Date().toISOString(),
      commands: [
        {
          id: `cmd_${Date.now()}`,
          command: "session_start",
          output: `New ${type} session created successfully.`,
          timestamp: new Date().toISOString(),
          type: "system"
        }
      ],
      variables: {
        USER: "time_traveler",
        HOME: "/home/time_traveler",
        PATH: "/usr/local/bin:/usr/bin:/bin",
        TEMPORAL_SYNC: "enabled",
        SESSION_TYPE: type
      },
      currentDirectory: "/home/time_traveler"
    };

    setSessions(prev => [...prev, newSession]);
    setActiveSession(newSession.id);
  };

  const closeSession = (sessionId: string) => {
    setSessions(prev => prev.filter(s => s.id !== sessionId));
    if (activeSession === sessionId && sessions.length > 1) {
      setActiveSession(sessions.find(s => s.id !== sessionId)?.id || null);
    }
  };

  const getTerminalColor = (type: string) => {
    switch (type) {
      case "quantum": return "text-blue-400";
      case "fractal": return "text-green-400";
      case "portal": return "text-purple-400";
      case "hofstadter": return "text-orange-400";
      case "rorschach": return "text-pink-400";
      case "mandelbrot": return "text-cyan-400";
      default: return "text-gray-400";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-500";
      case "idle": return "bg-yellow-500";
      case "completed": return "bg-blue-500";
      case "connecting": return "bg-orange-500";
      case "inactive": return "bg-gray-500";
      default: return "bg-gray-500";
    }
  };

  const activeSessionData = sessions.find(s => s.id === activeSession);

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Temporal Terminal</h1>
        <p className="text-muted-foreground">
          Clientless web-based terminal for exploring temporal dimensions and quantum realms
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1 space-y-6">
          {/* Sessions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Sessions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {sessions.map((session) => (
                  <div
                    key={session.id}
                    className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                      activeSession === session.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                    }`}
                    onClick={() => setActiveSession(session.id)}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <div className={`w-2 h-2 rounded-full ${getStatusColor(session.status)}`}></div>
                        <span className="font-medium text-sm">{session.name}</span>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          closeSession(session.id);
                        }}
                        className="p-1 h-auto"
                      >
                        ×
                      </Button>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {session.type} • {new Date(session.startTime).toLocaleTimeString()}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-4 space-y-2">
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => createNewSession("quantum")}
                >
                  ⚛️ Quantum Session
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => createNewSession("fractal")}
                >
                  🔺 Fractal Session
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => createNewSession("portal")}
                >
                  🌀 Portal Session
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Collaborators */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Collaborators</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {collaborators.map((collaborator) => (
                  <div key={collaborator.id} className="flex items-center gap-3">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={collaborator.avatar} />
                      <AvatarFallback className="text-sm">{collaborator.avatar}</AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="font-medium text-sm">{collaborator.name}</div>
                      <div className="flex items-center gap-1">
                        <div className={`w-2 h-2 rounded-full ${getStatusColor(collaborator.status)}`}></div>
                        <span className="text-xs text-muted-foreground capitalize">
                          {collaborator.status}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Tunnels */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Temporal Tunnels</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {tunnels.map((tunnel) => (
                  <div key={tunnel.id} className="p-2 bg-muted rounded">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-medium text-sm">{tunnel.source}</span>
                      <div className={`w-2 h-2 rounded-full ${getStatusColor(tunnel.status)}`}></div>
                    </div>
                    <div className="text-xs text-muted-foreground">
                      → {tunnel.destination} ({tunnel.protocol})
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {tunnel.localPort} → {tunnel.remotePort}
                    </div>
                  </div>
                ))}
              </div>
              
              <Button variant="outline" size="sm" className="w-full mt-3">
                + New Tunnel
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Main Terminal Area */}
        <div className="lg:col-span-3">
          <Card className="h-full">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Terminal</CardTitle>
                  {activeSessionData && (
                    <CardDescription>
                      {activeSessionData.name} • {activeSessionData.type}
                    </CardDescription>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {activeSessionData && (
                    <Badge variant="outline" className={getTerminalColor(activeSessionData.type)}>
                      {activeSessionData.type}
                    </Badge>
                  )}
                  <Badge variant="outline">
                    {sessions.length} sessions
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="p-0">
              <Tabs value={activeTab} onValueChange={setActiveTab} className="h-full">
                <TabsList className="grid w-full grid-cols-3 rounded-none">
                  <TabsTrigger value="terminal">Terminal</TabsTrigger>
                  <TabsTrigger value="files">File Explorer</TabsTrigger>
                  <TabsTrigger value="settings">Settings</TabsTrigger>
                </TabsList>

                <TabsContent value="terminal" className="mt-0 p-4">
                  <div className="bg-black text-green-400 font-mono text-sm rounded-lg p-4 h-96 overflow-hidden flex flex-col">
                    <ScrollArea className="flex-1">
                      <div className="space-y-1">
                        {activeSessionData?.commands.map((cmd) => (
                          <div key={cmd.id} className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="text-blue-400">$</span>
                              <span className="text-white">{cmd.command}</span>
                            </div>
                            {cmd.output && (
                              <div className={`ml-4 whitespace-pre-wrap ${
                                cmd.type === "error" ? "text-red-400" :
                                cmd.type === "success" ? "text-green-400" :
                                cmd.type === "system" ? "text-yellow-400" :
                                "text-gray-400"
                              }`}>
                                {cmd.output}
                              </div>
                            )}
                          </div>
                        ))}
                        <div ref={terminalEndRef} />
                      </div>
                    </ScrollArea>
                    
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-blue-400">$</span>
                      <Input
                        value={commandInput}
                        onChange={(e) => setCommandInput(e.target.value)}
                        onKeyPress={handleKeyPress}
                        className="bg-transparent border-none text-white placeholder-gray-500 focus-visible:ring-0"
                        placeholder="Type command..."
                      />
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="files" className="mt-0 p-4">
                  <div className="space-y-4">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium">Current Directory:</span>
                      <span className="text-sm text-muted-foreground">
                        {activeSessionData?.currentDirectory || "/home/time_traveler"}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {fileSystem.map((item) => (
                        <Card key={item.name} className="hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex items-center gap-3">
                              <span className="text-2xl">
                                {item.type === "directory" ? "📁" : "📄"}
                              </span>
                              <div className="flex-1">
                                <div className="font-medium text-sm">{item.name}</div>
                                <div className="text-xs text-muted-foreground">
                                  {item.type === "file" && item.size && `${item.size} • `}
                                  {new Date(item.modified).toLocaleDateString()}
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  {item.permissions}
                                </div>
                              </div>
                            </div>
                            
                            {item.type === "file" && (
                              <div className="mt-3">
                                <Button variant="outline" size="sm" className="w-full">
                                  View Contents
                                </Button>
                              </div>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="settings" className="mt-0 p-4">
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium mb-3">Terminal Settings</h3>
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium">Theme</label>
                          <select className="w-full mt-1 p-2 border rounded">
                            <option>Dark</option>
                            <option>Light</option>
                            <option>Blue</option>
                            <option>Green</option>
                          </select>
                        </div>
                        
                        <div>
                          <label className="text-sm font-medium">Font Size</label>
                          <select className="w-full mt-1 p-2 border rounded">
                            <option>12px</option>
                            <option>14px</option>
                            <option>16px</option>
                            <option>18px</option>
                          </select>
                        </div>
                        
                        <div>
                          <label className="text-sm font-medium">Cursor Style</label>
                          <select className="w-full mt-1 p-2 border rounded">
                            <option>Block</option>
                            <option>Underline</option>
                            <option>Line</option>
                          </select>
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-lg font-medium mb-3">Temporal Settings</h3>
                      <div className="space-y-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-sm font-medium">Auto-sync</div>
                            <div className="text-xs text-muted-foreground">
                              Automatically sync temporal data
                            </div>
                          </div>
                          <input type="checkbox" defaultChecked className="rounded" />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-sm font-medium">Collaboration</div>
                            <div className="text-xs text-muted-foreground">
                              Allow real-time collaboration
                            </div>
                          </div>
                          <input type="checkbox" defaultChecked className="rounded" />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="text-sm font-medium">Quantum Encryption</div>
                            <div className="text-xs text-muted-foreground">
                              Enable quantum-level security
                            </div>
                          </div>
                          <input type="checkbox" defaultChecked className="rounded" />
                        </div>
                      </div>
                    </div>
                    
                    <Separator />
                    
                    <div>
                      <h3 className="text-lg font-medium mb-3">Session Management</h3>
                      <div className="space-y-2">
                        <Button variant="outline" className="w-full justify-start">
                          💾 Save Session
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          📁 Load Session
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          🔄 Reset Sessions
                        </Button>
                        <Button variant="outline" className="w-full justify-start">
                          📤 Export Data
                        </Button>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}