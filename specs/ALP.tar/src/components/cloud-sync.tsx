"use client";

import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip";
import DateUtils from "@/lib/date-utils";

interface SyncDevice {
  id: string;
  name: string;
  type: "desktop" | "laptop" | "tablet" | "mobile";
  lastSync: string;
  status: "online" | "offline" | "syncing";
  location: string;
  ipAddress: string;
  version: string;
}

interface BackupRecord {
  id: string;
  timestamp: string;
  size: string;
  type: "manual" | "automatic" | "scheduled";
  status: "completed" | "failed" | "in-progress";
  devices: string[];
  checksum: string;
}

interface SyncConflict {
  id: string;
  resource: string;
  conflictType: "modification" | "deletion" | "creation";
  device1: string;
  device2: string;
  timestamp: string;
  resolved: boolean;
}

interface CloudStorage {
  used: number;
  total: number;
  lastBackup: string;
  backupCount: number;
  syncCount: number;
}

export default function CloudSync() {
  const [devices, setDevices] = useState<SyncDevice[]>([]);
  const [backups, setBackups] = useState<BackupRecord[]>([]);
  const [conflicts, setConflicts] = useState<SyncConflict[]>([]);
  const [storage, setStorage] = useState<CloudStorage | null>(null);
  const [activeTab, setActiveTab] = useState("overview");
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncProgress, setSyncProgress] = useState(0);
  const [autoSync, setAutoSync] = useState(true);
  const [syncInterval, setSyncInterval] = useState(30); // minutes

  // Sample devices
  const sampleDevices: SyncDevice[] = [
    {
      id: "device1",
      name: "Work Desktop",
      type: "desktop",
      lastSync: "2024-01-22T14:30:00Z",
      status: "online",
      location: "New York, NY",
      ipAddress: "192.168.1.100",
      version: "2.0.1"
    },
    {
      id: "device2",
      name: "Personal Laptop",
      type: "laptop",
      lastSync: "2024-01-22T12:15:00Z",
      status: "offline",
      location: "Home",
      ipAddress: "192.168.1.101",
      version: "2.0.1"
    },
    {
      id: "device3",
      name: "iPad Pro",
      type: "tablet",
      lastSync: "2024-01-22T09:45:00Z",
      status: "online",
      location: "Café Downtown",
      ipAddress: "192.168.1.102",
      version: "2.0.0"
    },
    {
      id: "device4",
      name: "iPhone 14",
      type: "mobile",
      lastSync: "2024-01-21T18:20:00Z",
      status: "offline",
      location: "Mobile",
      ipAddress: "192.168.1.103",
      version: "2.0.1"
    }
  ];

  // Sample backups
  const sampleBackups: BackupRecord[] = [
    {
      id: "backup1",
      timestamp: "2024-01-22T14:30:00Z",
      size: "2.3 GB",
      type: "automatic",
      status: "completed",
      devices: ["device1", "device3"],
      checksum: "a1b2c3d4e5f6..."
    },
    {
      id: "backup2",
      timestamp: "2024-01-22T12:15:00Z",
      size: "2.3 GB",
      type: "scheduled",
      status: "completed",
      devices: ["device2"],
      checksum: "b2c3d4e5f6a7..."
    },
    {
      id: "backup3",
      timestamp: "2024-01-22T09:45:00Z",
      size: "2.2 GB",
      type: "automatic",
      status: "completed",
      devices: ["device3"],
      checksum: "c3d4e5f6a7b8..."
    },
    {
      id: "backup4",
      timestamp: "2024-01-21T18:20:00Z",
      size: "2.1 GB",
      type: "manual",
      status: "completed",
      devices: ["device4"],
      checksum: "d4e5f6a7b8c9..."
    }
  ];

  // Sample conflicts
  const sampleConflicts: SyncConflict[] = [
    {
      id: "conflict1",
      resource: "quantum_mechanics_notes.txt",
      conflictType: "modification",
      device1: "Work Desktop",
      device2: "Personal Laptop",
      timestamp: "2024-01-22T14:25:00Z",
      resolved: false
    },
    {
      id: "conflict2",
      resource: "fractal_generator.py",
      conflictType: "modification",
      device1: "iPad Pro",
      device2: "iPhone 14",
      timestamp: "2024-01-22T11:30:00Z",
      resolved: true
    },
    {
      id: "conflict3",
      resource: "portal_research.md",
      conflictType: "creation",
      device1: "Personal Laptop",
      device2: "Work Desktop",
      timestamp: "2024-01-21T16:45:00Z",
      resolved: false
    }
  ];

  // Sample storage info
  const sampleStorage: CloudStorage = {
    used: 2.3,
    total: 10.0,
    lastBackup: "2024-01-22T14:30:00Z",
    backupCount: 156,
    syncCount: 1243
  };

  useEffect(() => {
    setDevices(sampleDevices);
    setBackups(sampleBackups);
    setConflicts(sampleConflicts);
    setStorage(sampleStorage);
  }, []);

  const startSync = () => {
    setIsSyncing(true);
    setSyncProgress(0);
    
    // Simulate sync progress
    const interval = setInterval(() => {
      setSyncProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          setIsSyncing(false);
          return 100;
        }
        return prev + Math.random() * 15;
      });
    }, 500);
  };

  const createBackup = (type: "manual" | "automatic" | "scheduled") => {
    const newBackup: BackupRecord = {
      id: `backup_${Date.now()}`,
      timestamp: new Date().toISOString(),
      size: `${(Math.random() * 0.5 + 2.0).toFixed(1)} GB`,
      type,
      status: "in-progress",
      devices: devices.filter(d => d.status === "online").map(d => d.name),
      checksum: "generating..."
    };

    setBackups(prev => [newBackup, ...prev]);

    // Simulate backup completion
    setTimeout(() => {
      setBackups(prev => prev.map(b => 
        b.id === newBackup.id 
          ? { ...b, status: "completed" as const, checksum: "abc123def456..." }
          : b
      ));
    }, 3000);
  };

  const resolveConflict = (conflictId: string, resolution: "device1" | "device2" | "merge") => {
    setConflicts(prev => prev.map(conflict => 
      conflict.id === conflictId 
        ? { ...conflict, resolved: true }
        : conflict
    ));
  };

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case "desktop": return "🖥️";
      case "laptop": return "💻";
      case "tablet": return "📱";
      case "mobile": return "📱";
      default: return "📟";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "online": return "bg-green-500";
      case "offline": return "bg-gray-500";
      case "syncing": return "bg-blue-500";
      case "completed": return "bg-green-500";
      case "failed": return "bg-red-500";
      case "in-progress": return "bg-yellow-500";
      default: return "bg-gray-500";
    }
  };

  const getConflictTypeColor = (type: string) => {
    switch (type) {
      case "modification": return "bg-yellow-100 text-yellow-800";
      case "deletion": return "bg-red-100 text-red-800";
      case "creation": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const unresolvedConflicts = conflicts.filter(c => !c.resolved);
  const onlineDevices = devices.filter(d => d.status === "online");

  return (
    <div className="container mx-auto p-6 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Cloud Synchronization</h1>
        <p className="text-muted-foreground">
          Seamless cross-device backup and synchronization for your temporal learning journey
        </p>
      </div>

      {/* Status Overview */}
      {storage && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Storage Used</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-600">
                {storage.used}GB
              </div>
              <Progress value={(storage.used / storage.total) * 100} className="mt-2" />
              <div className="text-xs text-muted-foreground mt-1">
                of {storage.total}GB total
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Total Backups</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-600">
                {storage.backupCount}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Last: {DateUtils.formatDisplay(storage.lastBackup, { 
                  month: 'short', 
                  day: 'numeric', 
                  hour: '2-digit', 
                  minute: '2-digit' 
                })}
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Sync Sessions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-purple-600">
                {storage.syncCount}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                Total synchronization events
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Active Devices</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-orange-600">
                {onlineDevices.length}
              </div>
              <div className="text-xs text-muted-foreground mt-1">
                of {devices.length} devices online
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Sync Controls */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Sync Controls</CardTitle>
          <CardDescription>
            Manage synchronization settings and initiate manual sync
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-medium">Auto Sync</div>
                  <div className="text-sm text-muted-foreground">
                    Automatically sync changes across devices
                  </div>
                </div>
                <Switch
                  checked={autoSync}
                  onCheckedChange={setAutoSync}
                />
              </div>
              
              {autoSync && (
                <div>
                  <label className="text-sm font-medium">Sync Interval</label>
                  <select
                    value={syncInterval}
                    onChange={(e) => setSyncInterval(Number(e.target.value))}
                    className="w-full mt-1 p-2 border rounded"
                  >
                    <option value={15}>15 minutes</option>
                    <option value={30}>30 minutes</option>
                    <option value={60}>1 hour</option>
                    <option value={120}>2 hours</option>
                    <option value={360}>6 hours</option>
                  </select>
                </div>
              )}
              
              <div className="space-y-2">
                <Button
                  onClick={startSync}
                  disabled={isSyncing}
                  className="w-full"
                >
                  {isSyncing ? "Syncing..." : "Start Manual Sync"}
                </Button>
                
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => createBackup("manual")}
                    disabled={isSyncing}
                    className="flex-1"
                  >
                    Create Backup
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => createBackup("scheduled")}
                    disabled={isSyncing}
                    className="flex-1"
                  >
                    Schedule Backup
                  </Button>
                </div>
              </div>
            </div>
            
            <div className="space-y-4">
              {isSyncing && (
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium">Sync Progress</span>
                    <span className="text-sm">{Math.round(syncProgress)}%</span>
                  </div>
                  <Progress value={syncProgress} className="h-2" />
                  <div className="text-xs text-muted-foreground mt-1">
                    Syncing across {onlineDevices.length} devices...
                  </div>
                </div>
              )}
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Next Auto Sync</span>
                  <span className="text-sm text-muted-foreground">
                    {autoSync ? `${syncInterval} minutes` : "Disabled"}
                  </span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Last Sync</span>
                  <span className="text-sm text-muted-foreground">
                    {DateUtils.formatDisplay(new Date(), { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </span>
                </div>
                
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Conflicts</span>
                  <Badge variant={unresolvedConflicts.length > 0 ? "destructive" : "secondary"}>
                    {unresolvedConflicts.length} unresolved
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="devices">Devices</TabsTrigger>
          <TabsTrigger value="backups">Backups</TabsTrigger>
          <TabsTrigger value="conflicts">Conflicts</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="devices" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Connected Devices</CardTitle>
                  <CardDescription>
                    Manage devices connected to your cloud sync
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {devices.map((device) => (
                      <div key={device.id} className="flex items-center gap-4 p-4 border rounded-lg">
                        <div className="text-3xl">{getDeviceIcon(device.type)}</div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            <h3 className="font-medium">{device.name}</h3>
                            <div className={`w-2 h-2 rounded-full ${getStatusColor(device.status)}`}></div>
                            <span className="text-xs text-muted-foreground capitalize">
                              {device.status}
                            </span>
                          </div>
                          <div className="text-sm text-muted-foreground">
                            {device.location} • {device.version}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            Last sync: {DateUtils.formatDisplay(device.lastSync, { 
                              month: 'short', 
                              day: 'numeric', 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-xs text-muted-foreground mb-1">
                            {device.ipAddress}
                          </div>
                          <Button variant="outline" size="sm">
                            Manage
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <Button variant="outline" className="w-full mt-4">
                    + Add New Device
                  </Button>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Device Statistics */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Device Statistics</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Total Devices</span>
                      <span className="font-medium">{devices.length}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Online Devices</span>
                      <span className="font-medium">{onlineDevices.length}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Desktop/Laptop</span>
                      <span className="font-medium">
                        {devices.filter(d => d.type === "desktop" || d.type === "laptop").length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Mobile/Tablet</span>
                      <span className="font-medium">
                        {devices.filter(d => d.type === "mobile" || d.type === "tablet").length}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Recent Activity */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64">
                    <div className="space-y-3">
                      {devices.slice(0, 5).map((device) => (
                        <div key={device.id} className="flex items-center gap-3 p-2 bg-muted rounded">
                          <span className="text-lg">{getDeviceIcon(device.type)}</span>
                          <div className="flex-1">
                            <div className="font-medium text-sm">{device.name}</div>
                            <div className="text-xs text-muted-foreground">
                              Synced {DateUtils.formatDisplay(device.lastSync, { 
                                hour: '2-digit', 
                                minute: '2-digit' 
                              })}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="backups" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Backup History</CardTitle>
                  <CardDescription>
                    View and manage your backup history
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-96">
                    <div className="space-y-3">
                      {backups.map((backup) => (
                        <div key={backup.id} className="p-4 border rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <div className="flex items-center gap-2">
                              <div className={`w-2 h-2 rounded-full ${getStatusColor(backup.status)}`}></div>
                              <span className="font-medium">
                                {DateUtils.formatDisplay(backup.timestamp, { 
                                  month: 'short', 
                                  day: 'numeric', 
                                  hour: '2-digit', 
                                  minute: '2-digit' 
                                })}
                              </span>
                              <Badge variant="outline" className="text-xs">
                                {backup.type}
                              </Badge>
                            </div>
                            <div className="text-right">
                              <div className="font-medium">{backup.size}</div>
                              <div className="text-xs text-muted-foreground">
                                {backup.devices.length} devices
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center justify-between text-sm">
                            <div className="text-muted-foreground">
                              Devices: {backup.devices.join(", ")}
                            </div>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm">
                                Restore
                              </Button>
                              <Button variant="outline" size="sm">
                                Download
                              </Button>
                            </div>
                          </div>
                          
                          {backup.checksum && (
                            <div className="text-xs text-muted-foreground mt-2">
                              Checksum: {backup.checksum}
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Backup Settings */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Backup Settings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Backup Schedule</label>
                      <select className="w-full mt-1 p-2 border rounded">
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                        <option value="monthly">Monthly</option>
                        <option value="manual">Manual Only</option>
                      </select>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium">Retention Policy</label>
                      <select className="w-full mt-1 p-2 border rounded">
                        <option value="7">Keep 7 days</option>
                        <option value="30">Keep 30 days</option>
                        <option value="90">Keep 90 days</option>
                        <option value="365">Keep 1 year</option>
                        <option value="unlimited">Unlimited</option>
                      </select>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Compression</div>
                        <div className="text-xs text-muted-foreground">
                          Compress backups to save space
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="text-sm font-medium">Encryption</div>
                        <div className="text-xs text-muted-foreground">
                          Encrypt backups with AES-256
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Storage Usage */}
              {storage && (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Storage Usage</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium">Used Space</span>
                          <span className="text-sm">{storage.used}GB / {storage.total}GB</span>
                        </div>
                        <Progress value={(storage.used / storage.total) * 100} className="h-2" />
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4 text-center">
                        <div>
                          <div className="text-lg font-bold text-blue-600">{storage.backupCount}</div>
                          <div className="text-xs text-muted-foreground">Backups</div>
                        </div>
                        <div>
                          <div className="text-lg font-bold text-green-600">{storage.syncCount}</div>
                          <div className="text-xs text-muted-foreground">Syncs</div>
                        </div>
                      </div>
                      
                      <Button variant="outline" className="w-full">
                        Upgrade Storage
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="conflicts" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Sync Conflicts</CardTitle>
                  <CardDescription>
                    Resolve conflicts between different devices
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {conflicts.map((conflict) => (
                      <div key={conflict.id} className={`p-4 border rounded-lg ${conflict.resolved ? 'opacity-50' : ''}`}>
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-2">
                            <div className={`w-2 h-2 rounded-full ${conflict.resolved ? 'bg-green-500' : 'bg-red-500'}`}></div>
                            <h3 className="font-medium">{conflict.resource}</h3>
                            <Badge className={getConflictTypeColor(conflict.conflictType)}>
                              {conflict.conflictType}
                            </Badge>
                          </div>
                          <span className="text-sm text-muted-foreground">
                            {DateUtils.formatDisplay(conflict.timestamp, { 
                              month: 'short', 
                              day: 'numeric', 
                              hour: '2-digit', 
                              minute: '2-digit' 
                            })}
                          </span>
                        </div>
                        
                        <div className="text-sm text-muted-foreground mb-3">
                          Conflict between {conflict.device1} and {conflict.device2}
                        </div>
                        
                        {!conflict.resolved && (
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => resolveConflict(conflict.id, "device1")}
                            >
                              Use {conflict.device1}
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => resolveConflict(conflict.id, "device2")}
                            >
                              Use {conflict.device2}
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => resolveConflict(conflict.id, "merge")}
                            >
                              Merge
                            </Button>
                          </div>
                        )}
                        
                        {conflict.resolved && (
                          <div className="text-sm text-green-600">
                            ✓ Resolved
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            <div className="space-y-6">
              {/* Conflict Summary */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Conflict Summary</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Total Conflicts</span>
                      <span className="font-medium">{conflicts.length}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Resolved</span>
                      <span className="font-medium text-green-600">
                        {conflicts.filter(c => c.resolved).length}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm">Unresolved</span>
                      <span className="font-medium text-red-600">
                        {unresolvedConflicts.length}
                      </span>
                    </div>
                    
                    <Separator />
                    
                    <div className="space-y-2">
                      <div className="text-sm font-medium">By Type</div>
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-xs">
                          <span>Modifications</span>
                          <span>{conflicts.filter(c => c.conflictType === "modification").length}</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span>Deletions</span>
                          <span>{conflicts.filter(c => c.conflictType === "deletion").length}</span>
                        </div>
                        <div className="flex items-center justify-between text-xs">
                          <span>Creations</span>
                          <span>{conflicts.filter(c => c.conflictType === "creation").length}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* Conflict Resolution Tips */}
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Resolution Tips</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3 text-sm">
                    <div>
                      <div className="font-medium">📝 Modifications</div>
                      <div className="text-muted-foreground">
                        Choose the version with the most recent changes or merge both versions.
                      </div>
                    </div>
                    
                    <div>
                      <div className="font-medium">🗑️ Deletions</div>
                      <div className="text-muted-foreground">
                        Decide whether to keep the deleted file or restore it from backup.
                      </div>
                    </div>
                    
                    <div>
                      <div className="font-medium">📁 Creations</div>
                      <div className="text-muted-foreground">
                        Choose which version of the new file to keep or merge their contents.
                      </div>
                    </div>
                    
                    <div>
                      <div className="font-medium">💡 Pro Tip</div>
                      <div className="text-muted-foreground">
                        Regular syncing reduces conflicts. Set up auto-sync for best results.
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="settings" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Sync Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Real-time Sync</div>
                        <div className="text-sm text-muted-foreground">
                          Sync changes instantly across all devices
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Background Sync</div>
                        <div className="text-sm text-muted-foreground">
                          Sync in the background when app is not active
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">WiFi Only</div>
                        <div className="text-sm text-muted-foreground">
                          Only sync when connected to WiFi
                        </div>
                      </div>
                      <Switch />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Battery Optimization</div>
                        <div className="text-sm text-muted-foreground">
                          Reduce sync activity when battery is low
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div>
                    <label className="text-sm font-medium">Sync Frequency</label>
                    <select className="w-full mt-1 p-2 border rounded">
                      <option value="continuous">Continuous</option>
                      <option value="5min">Every 5 minutes</option>
                      <option value="15min">Every 15 minutes</option>
                      <option value="30min">Every 30 minutes</option>
                      <option value="1hour">Every hour</option>
                    </select>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Advanced Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <label className="text-sm font-medium">Conflict Resolution Strategy</label>
                    <select className="w-full mt-1 p-2 border rounded">
                      <option value="newest">Newest file wins</option>
                      <option value="manual">Manual resolution required</option>
                      <option value="merge">Auto-merge when possible</option>
                      <option value="backup">Keep both versions</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium">Max File Size</label>
                    <select className="w-full mt-1 p-2 border rounded">
                      <option value="100">100 MB</option>
                      <option value="500">500 MB</option>
                      <option value="1000">1 GB</option>
                      <option value="unlimited">Unlimited</option>
                    </select>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Version History</div>
                        <div className="text-sm text-muted-foreground">
                          Keep multiple versions of files
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">Delta Sync</div>
                        <div className="text-sm text-muted-foreground">
                          Only sync changed parts of files
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium">End-to-End Encryption</div>
                        <div className="text-sm text-muted-foreground">
                          Encrypt data before uploading
                        </div>
                      </div>
                      <Switch defaultChecked />
                    </div>
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full">
                      Export Sync Data
                    </Button>
                    <Button variant="outline" className="w-full">
                      Import Sync Data
                    </Button>
                    <Button variant="destructive" className="w-full">
                      Reset All Sync Data
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}