/**
 * Date Synchronization Tests
 * Tests for the date utility and synchronization service
 */

import DateUtils from '../src/lib/date-utils';
import { DateSyncService } from '../src/services/date-sync-service';

describe('DateUtils', () => {
  beforeEach(() => {
    // Reset to default configuration
    DateUtils.initialize();
  });

  describe('now()', () => {
    it('should return current timestamp in ISO format by default', () => {
      const timestamp = DateUtils.now();
      expect(timestamp).toMatch(/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/);
    });

    it('should respect format configuration', () => {
      DateUtils.initialize({ format: 'TIMESTAMP' });
      const timestamp = DateUtils.now();
      expect(/^\d+$/.test(timestamp)).toBe(true);
    });
  });

  describe('formatDisplay()', () => {
    it('should format date for display with default options', () => {
      const date = '2024-01-20T10:30:00Z';
      const formatted = DateUtils.formatDisplay(date);
      expect(formatted).toContain('2024');
      expect(formatted).toContain('Jan');
    });

    it('should accept custom formatting options', () => {
      const date = '2024-01-20T10:30:00Z';
      const formatted = DateUtils.formatDisplay(date, { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      });
      expect(formatted).toMatch(/Jan 20, 2024/);
    });
  });

  describe('formatForDB()', () => {
    it('should format date for database storage', () => {
      const date = new Date('2024-01-20T10:30:00Z');
      const formatted = DateUtils.formatForDB(date);
      expect(formatted).toBe('2024-01-20T10:30:00.000Z');
    });
  });

  describe('parse()', () => {
    it('should parse ISO date string', () => {
      const date = DateUtils.parse('2024-01-20T10:30:00Z');
      expect(date.getFullYear()).toBe(2024);
      expect(date.getMonth()).toBe(0); // January
      expect(date.getDate()).toBe(20);
    });

    it('should parse timestamp', () => {
      const timestamp = Date.now();
      const date = DateUtils.parse(timestamp.toString());
      expect(date.getTime()).toBe(timestamp);
    });

    it('should throw error for invalid date', () => {
      expect(() => DateUtils.parse('invalid-date')).toThrow();
    });
  });

  describe('timeDifference()', () => {
    it('should calculate time difference correctly', () => {
      const date1 = new Date('2024-01-20T10:30:00Z');
      const date2 = new Date('2024-01-20T11:30:00Z');
      
      const diff = DateUtils.timeDifference(date1, date2);
      
      expect(diff.hours).toBe(1);
      expect(diff.minutes).toBe(60);
      expect(diff.seconds).toBe(3600);
      expect(diff.humanReadable).toBe('1 hour ago');
    });
  });

  describe('isRecent()', () => {
    it('should return true for recent dates', () => {
      const recentDate = new Date(Date.now() - 1000 * 60 * 30); // 30 minutes ago
      expect(DateUtils.isRecent(recentDate, 1)).toBe(true);
    });

    it('should return false for old dates', () => {
      const oldDate = new Date(Date.now() - 1000 * 60 * 60 * 25); // 25 hours ago
      expect(DateUtils.isRecent(oldDate, 24)).toBe(false);
    });
  });

  describe('addTime()', () => {
    it('should add time correctly', () => {
      const date = '2024-01-20T10:30:00Z';
      const result = DateUtils.addTime(date, 1, 'hours');
      expect(result).toBe('2024-01-20T11:30:00.000Z');
    });
  });

  describe('isValid()', () => {
    it('should return true for valid dates', () => {
      expect(DateUtils.isValid('2024-01-20T10:30:00Z')).toBe(true);
    });

    it('should return false for invalid dates', () => {
      expect(DateUtils.isValid('invalid-date')).toBe(false);
    });
  });

  describe('generateSyncTimestamp()', () => {
    it('should generate valid timestamp', () => {
      const timestamp = DateUtils.generateSyncTimestamp();
      expect(DateUtils.isValid(timestamp)).toBe(true);
    });
  });

  describe('needsSync()', () => {
    it('should return true when sync is needed', () => {
      const oldDate = DateUtils.addTime(DateUtils.now(), -2, 'hours');
      expect(DateUtils.needsSync(oldDate, 1)).toBe(true);
    });

    it('should return false when sync is not needed', () => {
      const recentDate = DateUtils.addTime(DateUtils.now(), -30, 'minutes');
      expect(DateUtils.needsSync(recentDate, 60)).toBe(false);
    });
  });

  describe('formatForAurumGrid()', () => {
    it('should format date for Aurum Grid with high precision', () => {
      const date = new Date('2024-01-20T10:30:00.123Z');
      const formatted = DateUtils.formatForAurumGrid(date);
      expect(formatted).toMatch(/\.\d{6}Z$/);
    });
  });
});

describe('DateSyncService', () => {
  let syncService: DateSyncService;

  beforeEach(() => {
    syncService = new DateSyncService({
      interval: 1000, // 1 second for testing
      autoSync: false
    });
  });

  afterEach(() => {
    syncService.destroy();
  });

  describe('constructor', () => {
    it('should initialize with default configuration', () => {
      const service = new DateSyncService();
      expect(service.getStatus()).toBeDefined();
      service.destroy();
    });

    it('should accept custom configuration', () => {
      const config = { interval: 5000, autoSync: false };
      const service = new DateSyncService(config);
      expect(service.getStatus()).toBeDefined();
      service.destroy();
    });
  });

  describe('getStatus()', () => {
    it('should return current sync status', () => {
      const status = syncService.getStatus();
      expect(status).toHaveProperty('lastSync');
      expect(status).toHaveProperty('nextSync');
      expect(status).toHaveProperty('isSyncing');
      expect(status).toHaveProperty('success');
    });
  });

  describe('startSync() and stopSync()', () => {
    it('should start and stop synchronization', () => {
      syncService.startSync();
      expect(syncService.getStatus()).toBeDefined();
      
      syncService.stopSync();
      expect(syncService.getStatus()).toBeDefined();
    });
  });

  describe('updateConfig()', () => {
    it('should update configuration', () => {
      const newConfig = { interval: 2000, autoSync: false };
      syncService.updateConfig(newConfig);
      
      const status = syncService.getStatus();
      expect(status).toBeDefined();
    });
  });

  describe('needsNodeSync() and needsUploadSync()', () => {
    it('should check if node needs synchronization', () => {
      const oldDate = DateUtils.addTime(DateUtils.now(), -10, 'minutes');
      expect(syncService.needsNodeSync(oldDate, 5)).toBe(true);
    });

    it('should check if upload needs synchronization', () => {
      const recentDate = DateUtils.addTime(DateUtils.now(), -5, 'minutes');
      expect(syncService.needsUploadSync(recentDate, 10)).toBe(false);
    });
  });

  describe('callbacks', () => {
    it('should notify status callbacks', () => {
      const mockCallback = jest.fn();
      const unsubscribe = syncService.onStatusUpdate(mockCallback);
      
      // Trigger a status update
      syncService.startSync();
      
      expect(mockCallback).toHaveBeenCalled();
      unsubscribe();
    });

    it('should notify node sync callbacks', () => {
      const mockCallback = jest.fn();
      const unsubscribe = syncService.onNodeSync(mockCallback);
      
      // This would normally be triggered by sync operations
      // For testing, we'll just verify the callback is set up
      expect(typeof unsubscribe).toBe('function');
      unsubscribe();
    });

    it('should notify upload sync callbacks', () => {
      const mockCallback = jest.fn();
      const unsubscribe = syncService.onUploadSync(mockCallback);
      
      expect(typeof unsubscribe).toBe('function');
      unsubscribe();
    });
  });
});

// Integration tests
describe('Date Synchronization Integration', () => {
  it('should work together across the application', () => {
    // Test that DateUtils and DateSyncService work together
    const timestamp = DateUtils.generateSyncTimestamp();
    expect(DateUtils.isValid(timestamp)).toBe(true);
    
    const syncService = new DateSyncService({ autoSync: false });
    expect(syncService.needsNodeSync(timestamp, 1)).toBe(false);
    
    syncService.destroy();
  });

  it('should handle timezone conversions correctly', () => {
    const date = new Date();
    const isoString = date.toISOString();
    
    // Test that parsing and formatting are consistent
    const parsed = DateUtils.parse(isoString);
    const formatted = DateUtils.formatForDB(parsed);
    
    expect(DateUtils.isValid(formatted)).toBe(true);
  });

  it('should handle edge cases for date calculations', () => {
    // Test leap year
    const leapYearDate = '2024-02-29T10:30:00Z';
    expect(DateUtils.isValid(leapYearDate)).toBe(true);
    
    // Test timezone boundaries
    const boundaryDate = '2023-12-31T23:59:59Z';
    expect(DateUtils.isValid(boundaryDate)).toBe(true);
    
    // Test very old dates
    const oldDate = '1970-01-01T00:00:00Z';
    expect(DateUtils.isValid(oldDate)).toBe(true);
  });
});