#!/usr/bin/env bash
# review-cycle.sh – simple helper to init a review repo
REPO_NAME="timechain-whitepaper-review"
mkdir "$REPO_NAME" && cd "$REPO_NAME"
git init
cp ../TIMECHAIN_WHITEPAPER_V0.1.md .
cp ../WHITEPAPER_REVIEW_CHECKLIST.md .
cp ../REVIEWER_FEEDBACK_TEMPLATE.md .
cp ../V0_2_ENHANCEMENT_TEMPLATE.md .
cp ../VERSION_MANAGEMENT.md .
mkdir diagrams && cp -r ../diagrams/* diagrams/
git add .
git commit -m "Initial review package (v0.1)"
echo "Repo ready. Push to remote if you wish:"
echo "git remote add origin <URL>"
echo "git push -u origin main"