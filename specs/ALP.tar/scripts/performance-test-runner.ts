#!/usr/bin/env tsx

/**
 * TimeKeeper OS Performance Test Runner
 * 
 * This script runs the complete performance testing suite including:
 * - Benchmark execution
 * - Regression testing
 * - Optimization recommendations
 * - Report generation
 */

import { PerformanceBenchmarkSuite } from '../src/performance/benchmark-suite';
import { PerformanceRegressionTester } from '../src/performance/regression-testing';
import { OptimizationRecommender } from '../src/performance/optimization-recommender';
import { writeFileSync, mkdirSync, existsSync } from 'fs';
import { join } from 'path';

interface PerformanceTestReport {
  timestamp: string;
  summary: {
    totalBenchmarks: number;
    successfulBenchmarks: number;
    failedBenchmarks: number;
    regressionTests: {
      total: number;
      passed: number;
      warnings: number;
      failed: number;
      successRate: number;
    };
    recommendations: {
      total: number;
      critical: number;
      high: number;
      medium: number;
      low: number;
    };
  };
  benchmarks: any[];
  regressions: any[];
  recommendations: any[];
  performanceProfile: any[];
}

class PerformanceTestRunner {
  private outputDir: string;
  private benchmarkSuite: PerformanceBenchmarkSuite;
  private regressionTester: PerformanceRegressionTester;
  private optimizationRecommender: OptimizationRecommender;

  constructor(outputDir: string = './performance-reports') {
    this.outputDir = outputDir;
    this.benchmarkSuite = new PerformanceBenchmarkSuite({
      iterations: 500,
      warmupIterations: 50,
      timeout: 60000,
      memoryThreshold: 200,
      enableProfiling: true
    });
    this.regressionTester = new PerformanceRegressionTester({
      timeThresholdPercent: 15,
      throughputThresholdPercent: 15,
      memoryThresholdPercent: 20,
      strictMode: false,
      autoSaveBaselines: true
    });
    this.optimizationRecommender = new OptimizationRecommender();

    this.ensureOutputDirectory();
  }

  private ensureOutputDirectory(): void {
    if (!existsSync(this.outputDir)) {
      mkdirSync(this.outputDir, { recursive: true });
    }
  }

  private saveReport(report: PerformanceTestReport, filename: string): void {
    const filepath = join(this.outputDir, filename);
    writeFileSync(filepath, JSON.stringify(report, null, 2));
    console.log(`📄 Report saved to: ${filepath}`);
  }

  private saveCSVReport(data: any[], filename: string): void {
    const filepath = join(this.outputDir, filename);
    writeFileSync(filepath, data);
    console.log(`📄 CSV report saved to: ${filepath}`);
  }

  async runFullPerformanceTest(): Promise<PerformanceTestReport> {
    console.log('🚀 Starting TimeKeeper OS Performance Test Suite');
    console.log('==================================================');
    
    const startTime = Date.now();
    const report: PerformanceTestReport = {
      timestamp: new Date().toISOString(),
      summary: {
        totalBenchmarks: 0,
        successfulBenchmarks: 0,
        failedBenchmarks: 0,
        regressionTests: {
          total: 0,
          passed: 0,
          warnings: 0,
          failed: 0,
          successRate: 0
        },
        recommendations: {
          total: 0,
          critical: 0,
          high: 0,
          medium: 0,
          low: 0
        }
      },
      benchmarks: [],
      regressions: [],
      recommendations: [],
      performanceProfile: []
    };

    try {
      // Step 1: Run benchmarks
      console.log('\n📊 Step 1: Running Performance Benchmarks');
      console.log('----------------------------------------');
      const benchmarkResults = await this.benchmarkSuite.runAllBenchmarks();
      
      report.summary.totalBenchmarks = benchmarkResults.length;
      report.summary.successfulBenchmarks = benchmarkResults.filter(r => r.success).length;
      report.summary.failedBenchmarks = benchmarkResults.filter(r => !r.success).length;
      report.benchmarks = benchmarkResults;

      console.log(`✅ Benchmarks completed: ${report.summary.successfulBenchmarks}/${report.summary.totalBenchmarks} successful`);

      // Step 2: Run regression tests
      console.log('\n🔍 Step 2: Running Regression Tests');
      console.log('----------------------------------');
      const regressionResults = this.regressionTester.testRegressions(benchmarkResults);
      const regressionSummary = this.regressionTester.getSummary();
      
      report.summary.regressionTests = {
        total: regressionSummary.total,
        passed: regressionSummary.passed,
        warnings: regressionSummary.warnings,
        failed: regressionSummary.failed,
        successRate: regressionSummary.successRate
      };
      report.regressions = regressionResults;

      console.log(`✅ Regression tests completed: ${regressionSummary.successRate.toFixed(1)}% success rate`);

      // Step 3: Generate optimization recommendations
      console.log('\n💡 Step 3: Generating Optimization Recommendations');
      console.log('-------------------------------------------------');
      const recommendations = this.optimizationRecommender.analyzeBenchmarkResults(benchmarkResults);
      
      report.summary.recommendations = {
        total: recommendations.length,
        critical: recommendations.filter(r => r.priority === 'critical').length,
        high: recommendations.filter(r => r.priority === 'high').length,
        medium: recommendations.filter(r => r.priority === 'medium').length,
        low: recommendations.filter(r => r.priority === 'low').length
      };
      report.recommendations = recommendations;

      console.log(`✅ Recommendations generated: ${recommendations.length} suggestions`);

      // Step 4: Generate performance profile
      console.log('\n📈 Step 4: Generating Performance Profile');
      console.log('----------------------------------------');
      const performanceProfile = this.optimizationRecommender.generatePerformanceProfile(benchmarkResults);
      report.performanceProfile = performanceProfile;

      console.log(`✅ Performance profile generated for ${performanceProfile.length} components`);

      // Step 5: Generate optimization plan
      console.log('\n🎯 Step 5: Creating Optimization Plan');
      console.log('------------------------------------');
      const optimizationPlan = this.optimizationRecommender.generateOptimizationPlan();
      
      console.log('📋 Optimization Plan Summary:');
      console.log(`   Quick Wins: ${optimizationPlan.quickWins.length}`);
      console.log(`   Medium Term: ${optimizationPlan.mediumTerm.length}`);
      console.log(`   Long Term: ${optimizationPlan.longTerm.length}`);
      console.log(`   Total Estimated Improvement: ${optimizationPlan.totalEstimatedImprovement}%`);

      // Step 6: Save reports
      console.log('\n💾 Step 6: Saving Reports');
      console.log('---------------------------');
      
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      
      // Save comprehensive report
      this.saveReport(report, `performance-report-${timestamp}.json`);
      
      // Save benchmark results as CSV
      const benchmarkCSV = this.generateBenchmarkCSV(benchmarkResults);
      this.saveCSVReport(benchmarkCSV, `benchmark-results-${timestamp}.csv`);
      
      // Save regression results as CSV
      const regressionCSV = this.regressionTester.exportResults('csv');
      this.saveCSVReport(regressionCSV, `regression-results-${timestamp}.csv`);
      
      // Save recommendations as CSV
      const recommendationsCSV = this.optimizationRecommender.exportRecommendations('csv');
      this.saveCSVReport(recommendationsCSV, `recommendations-${timestamp}.csv`);

      const totalTime = Date.now() - startTime;
      
      console.log('\n🎉 Performance Test Suite Completed Successfully!');
      console.log('================================================');
      console.log(`⏱️  Total Time: ${(totalTime / 1000).toFixed(2)} seconds`);
      console.log(`📊 Benchmarks: ${report.summary.successfulBenchmarks}/${report.summary.totalBenchmarks} passed`);
      console.log(`🔍 Regression Tests: ${report.summary.regressionTests.successRate.toFixed(1)}% success rate`);
      console.log(`💡 Recommendations: ${report.summary.recommendations.total} suggestions`);
      console.log(`📋 Quick Wins: ${optimizationPlan.quickWins.length} high-impact, low-effort improvements`);
      console.log(`\n📁 Reports saved to: ${this.outputDir}/`);

      return report;

    } catch (error) {
      console.error('❌ Performance test suite failed:', error);
      throw error;
    }
  }

  private generateBenchmarkCSV(results: any[]): string {
    const headers = [
      'Name', 'Component', 'Iterations', 'Average Time (ms)', 'Min Time (ms)', 
      'Max Time (ms)', 'Median Time (ms)', 'Std Deviation', 'Throughput (ops/s)',
      'Memory Before (MB)', 'Memory After (MB)', 'Memory Delta (MB)', 'Success', 'Timestamp'
    ];

    const rows = results.map(result => [
      result.name,
      result.component,
      result.iterations.toString(),
      result.averageTime.toFixed(3),
      result.minTime.toFixed(3),
      result.maxTime.toFixed(3),
      result.medianTime.toFixed(3),
      result.standardDeviation.toFixed(3),
      result.throughput.toFixed(1),
      result.memoryUsage.before.toFixed(2),
      result.memoryUsage.after.toFixed(2),
      result.memoryUsage.delta.toFixed(2),
      result.success.toString(),
      result.timestamp
    ]);

    return [headers.join(','), ...rows.map(row => row.join(','))].join('\n');
  }

  async runQuickPerformanceCheck(): Promise<void> {
    console.log('⚡ Running Quick Performance Check');
    console.log('=================================');
    
    try {
      // Run a smaller subset of benchmarks
      const quickResults = await this.benchmarkSuite.benchmarkKernelOperations();
      
      console.log('\n📊 Quick Performance Results:');
      console.log('-----------------------------');
      
      quickResults.forEach(result => {
        console.log(`${result.name}:`);
        console.log(`  Average Time: ${result.averageTime.toFixed(2)}ms`);
        console.log(`  Throughput: ${result.throughput.toFixed(0)} ops/s`);
        console.log(`  Memory Delta: ${result.memoryUsage.delta.toFixed(2)}MB`);
        console.log(`  Status: ${result.success ? '✅ Passed' : '❌ Failed'}`);
        console.log('');
      });

      const avgTime = quickResults.reduce((sum, r) => sum + r.averageTime, 0) / quickResults.length;
      const avgThroughput = quickResults.reduce((sum, r) => sum + r.throughput, 0) / quickResults.length;
      
      console.log('📈 Summary:');
      console.log(`  Average Response Time: ${avgTime.toFixed(2)}ms`);
      console.log(`  Average Throughput: ${avgThroughput.toFixed(0)} ops/s`);
      console.log(`  Success Rate: ${(quickResults.filter(r => r.success).length / quickResults.length * 100).toFixed(1)}%`);
      
      const performance = avgTime < 3 ? 'Excellent' : avgTime < 5 ? 'Good' : avgTime < 10 ? 'Acceptable' : 'Needs Improvement';
      console.log(`  Overall Performance: ${performance}`);
      
    } catch (error) {
      console.error('❌ Quick performance check failed:', error);
      throw error;
    }
  }
}

// Main execution
async function main() {
  const args = process.argv.slice(2);
  const mode = args[0] || 'full';
  const outputDir = args[1] || './performance-reports';

  const runner = new PerformanceTestRunner(outputDir);

  try {
    switch (mode) {
      case 'quick':
        await runner.runQuickPerformanceCheck();
        break;
      case 'full':
        await runner.runFullPerformanceTest();
        break;
      default:
        console.error('❌ Unknown mode. Use "quick" or "full"');
        process.exit(1);
    }
  } catch (error) {
    console.error('❌ Performance testing failed:', error);
    process.exit(1);
  }
}

// Run if called directly
if (require.main === module) {
  main();
}

export { PerformanceTestRunner };