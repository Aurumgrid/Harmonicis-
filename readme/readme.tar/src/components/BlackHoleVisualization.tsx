"use client";

import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Play, Pause, RotateCcw, Zap } from "lucide-react";

interface BlackHole {
  x: number;
  y: number;
  mass: number;
  vx: number;
  vy: number;
}

export default function BlackHoleVisualization() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [mass1, setMass1] = useState([30]);
  const [mass2, setMass2] = useState([25]);
  const [separation, setSeparation] = useState([100]);
  const [waveData, setWaveData] = useState<number[]>([]);
  const [phase, setPhase] = useState<"inspiral" | "merger" | "ringdown">("inspiral");

  // Initialize black holes
  const blackHoles = useRef<BlackHole[]>([
    { x: -50, y: 0, mass: 30, vx: 0, vy: 0.5 },
    { x: 50, y: 0, mass: 25, vx: 0, vy: -0.6 }
  ]);

  useEffect(() => {
    if (!canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const animate = () => {
      if (!isPlaying) return;

      // Clear canvas
      ctx.fillStyle = 'rgba(15, 23, 42, 0.1)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Update physics
      updatePhysics();

      // Draw black holes
      drawBlackHoles(ctx);

      // Draw gravitational waves
      drawGravitationalWaves(ctx);

      // Update wave data for strain visualization
      updateWaveData();

      setTime(prev => prev + 0.016); // ~60fps
      requestAnimationFrame(animate);
    };

    if (isPlaying) {
      animate();
    }
  }, [isPlaying]);

  const updatePhysics = () => {
    const G = 0.1; // Simplified gravitational constant
    const bh1 = blackHoles.current[0];
    const bh2 = blackHoles.current[1];

    // Calculate distance
    const dx = bh2.x - bh1.x;
    const dy = bh2.y - bh1.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    // Prevent singularity
    if (distance < 5) {
      setPhase("merger");
      if (distance < 2) {
        setPhase("ringdown");
        return;
      }
    }

    // Calculate gravitational force
    const force = G * bh1.mass * bh2.mass / (distance * distance);
    const fx = force * dx / distance;
    const fy = force * dy / distance;

    // Update velocities
    bh1.vx += fx / bh1.mass * 0.016;
    bh1.vy += fy / bh1.mass * 0.016;
    bh2.vx -= fx / bh2.mass * 0.016;
    bh2.vy -= fy / bh2.mass * 0.016;

    // Update positions
    bh1.x += bh1.vx * 0.016;
    bh1.y += bh1.vy * 0.016;
    bh2.x += bh2.vx * 0.016;
    bh2.y += bh2.vy * 0.016;

    // Energy loss due to gravitational wave radiation (simplified)
    const energyLoss = 0.999;
    bh1.vx *= energyLoss;
    bh1.vy *= energyLoss;
    bh2.vx *= energyLoss;
    bh2.vy *= energyLoss;
  };

  const drawBlackHoles = (ctx: CanvasRenderingContext2D) => {
    const centerX = ctx.canvas.width / 2;
    const centerY = ctx.canvas.height / 2;
    const scale = 2;

    blackHoles.current.forEach((bh, index) => {
      const x = centerX + bh.x * scale;
      const y = centerY + bh.y * scale;
      const radius = Math.sqrt(bh.mass) * 2;

      // Draw event horizon
      const gradient = ctx.createRadialGradient(x, y, 0, x, y, radius);
      gradient.addColorStop(0, 'rgba(0, 0, 0, 1)');
      gradient.addColorStop(0.7, 'rgba(75, 0, 130, 0.8)');
      gradient.addColorStop(1, 'rgba(138, 43, 226, 0.3)');

      ctx.beginPath();
      ctx.arc(x, y, radius, 0, Math.PI * 2);
      ctx.fillStyle = gradient;
      ctx.fill();

      // Draw accretion disk effect
      ctx.beginPath();
      ctx.arc(x, y, radius * 1.5, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(255, 165, 0, ${0.3 + Math.sin(time * 10 + index) * 0.2})`;
      ctx.lineWidth = 2;
      ctx.stroke();
    });
  };

  const drawGravitationalWaves = (ctx: CanvasRenderingContext2D) => {
    const centerX = ctx.canvas.width / 2;
    const centerY = ctx.canvas.height / 2;

    // Draw expanding gravitational waves
    for (let i = 0; i < 5; i++) {
      const radius = (time * 50 + i * 30) % 200;
      const opacity = Math.max(0, 1 - radius / 200);

      ctx.beginPath();
      ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
      ctx.strokeStyle = `rgba(100, 149, 237, ${opacity * 0.3})`;
      ctx.lineWidth = 2;
      ctx.stroke();
    }
  };

  const updateWaveData = () => {
    const bh1 = blackHoles.current[0];
    const bh2 = blackHoles.current[1];
    const distance = Math.sqrt((bh2.x - bh1.x) ** 2 + (bh2.y - bh1.y) ** 2);
    
    // Simplified strain calculation
    const strain = Math.min(1, 100 / (distance * distance)) * Math.sin(time * 10);
    
    setWaveData(prev => {
      const newData = [...prev, strain];
      return newData.slice(-100); // Keep last 100 points
    });
  };

  const resetSimulation = () => {
    setIsPlaying(false);
    setTime(0);
    setWaveData([]);
    setPhase("inspiral");
    
    const sep = separation[0];
    blackHoles.current = [
      { x: -sep/2, y: 0, mass: mass1[0], vx: 0, vy: 0.5 },
      { x: sep/2, y: 0, mass: mass2[0], vx: 0, vy: -0.6 }
    ];

    // Redraw initial state
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.fillStyle = 'rgb(15, 23, 42)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    drawBlackHoles(ctx);
  };

  useEffect(() => {
    resetSimulation();
  }, [mass1, mass2, separation]);

  return (
    <div className="space-y-6">
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Coalescence Simulation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-4 items-center">
            <Button
              onClick={() => setIsPlaying(!isPlaying)}
              variant={isPlaying ? "secondary" : "default"}
            >
              {isPlaying ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
              {isPlaying ? "Pause" : "Start"}
            </Button>
            <Button onClick={resetSimulation} variant="outline">
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset
            </Button>
            <Badge variant={phase === "inspiral" ? "default" : "secondary"}>
              Phase: {phase === "inspiral" ? "Inspiral" : phase === "merger" ? "Merger" : "Ringdown"}
            </Badge>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-white">BH 1 Mass (M☉)</Label>
              <Slider
                value={mass1}
                onValueChange={setMass1}
                max={100}
                min={5}
                step={1}
                className="w-full"
              />
              <div className="text-center text-slate-300 text-sm">{mass1[0]} M☉</div>
            </div>

            <div className="space-y-2">
              <Label className="text-white">BH 2 Mass (M☉)</Label>
              <Slider
                value={mass2}
                onValueChange={setMass2}
                max={100}
                min={5}
                step={1}
                className="w-full"
              />
              <div className="text-center text-slate-300 text-sm">{mass2[0]} M☉</div>
            </div>

            <div className="space-y-2">
              <Label className="text-white">Initial Separation</Label>
              <Slider
                value={separation}
                onValueChange={setSeparation}
                max={200}
                min={50}
                step={10}
                className="w-full"
              />
              <div className="text-center text-slate-300 text-sm">{separation[0]} km</div>
            </div>
          </div>

          <div className="bg-slate-900 rounded-lg p-4">
            <canvas
              ref={canvasRef}
              width={600}
              height={400}
              className="w-full h-full border border-slate-600 rounded"
            />
          </div>

          <div className="text-center text-slate-400 text-sm">
            <p>Simplified simulation of black hole coalescence</p>
            <p>Gravitational waves are represented by the concentric circles</p>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Space-Time Strain</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-slate-900 rounded-lg p-4 h-32">
            <div className="relative w-full h-full">
              {waveData.length > 0 && (
                <svg className="w-full h-full" viewBox="0 0 100 32">
                  <path
                    d={`M 0,16 ${waveData.map((value, index) => `L ${index},${16 + value * 10}`).join(' ')}`}
                    fill="none"
                    stroke="rgb(100, 149, 237)"
                    strokeWidth="0.5"
                  />
                  <line x1="0" y1="16" x2="100" y2="16" stroke="rgb(71, 85, 105)" strokeWidth="0.3" />
                </svg>
              )}
            </div>
          </div>
          <div className="text-center text-slate-400 text-sm mt-2">
            Gravitational wave amplitude over time
          </div>
        </CardContent>
      </Card>
    </div>
  );
}