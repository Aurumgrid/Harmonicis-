"use client";

import { useState, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";
import { GitCompare, TrendingUp, Zap } from "lucide-react";
import ExportTools from "@/components/ExportTools";

interface Scenario {
  id: string;
  name: string;
  mass1: number;
  mass2: number;
  distance: number;
  strain: number;
  frequency: number;
  energy: number;
  timeToMerger: number;
  chirpMass: number;
}

export default function ComparisonTool() {
  const chartRef = useRef<HTMLDivElement>(null);
  const [scenarios, setScenarios] = useState<Scenario[]>([
    {
      id: "1",
      name: "GW150914 (First Detection)",
      mass1: 36,
      mass2: 29,
      distance: 410,
      strain: 1.0e-21,
      frequency: 150,
      energy: 3.0,
      timeToMerger: 0.2,
      chirpMass: 28.6
    },
    {
      id: "2", 
      name: "GW170814",
      mass1: 31,
      mass2: 25,
      distance: 540,
      strain: 7.5e-22,
      frequency: 180,
      energy: 2.1,
      timeToMerger: 0.15,
      chirpMass: 24.1
    },
    {
      id: "3",
      name: "GW190521 (Massive)",
      mass1: 85,
      mass2: 66,
      distance: 1500,
      strain: 5.2e-22,
      frequency: 60,
      energy: 8.5,
      timeToMerger: 0.05,
      chirpMass: 64.2
    }
  ]);

  const [customScenario, setCustomScenario] = useState({
    mass1: 30,
    mass2: 25,
    distance: 1000
  });

  const calculateCustomScenario = () => {
    // Constants
    const G = 6.67430e-11;
    const c = 299792458;
    const solarMass = 1.989e30;
    const megaparsec = 3.086e22;
    
    // Convert inputs to SI units
    const m1 = customScenario.mass1 * solarMass;
    const m2 = customScenario.mass2 * solarMass;
    const d = customScenario.distance * megaparsec;
    
    // Calculate total mass and reduced mass
    const M = m1 + m2;
    const mu = (m1 * m2) / M;
    
    // Calculate chirp mass
    const Mc = (mu**(3/5) * M**(2/5));
    
    // Calculate characteristic frequency (Hz)
    const f_char = (c**3 / (G * M)) * (1 / (6 * Math.PI * (2**(1/2))));
    
    // Calculate strain amplitude
    const h = (4 * G * Mc / (c**2 * d)) * (Math.PI * G * Mc * f_char / c**3)**(2/3);
    
    // Calculate energy radiated
    const E_rad = (mu * c**2) * (G * M * f_char / c**3)**(5/3);
    
    // Calculate time to merger
    const t_merger = (5 * c**5) / (256 * (G * Mc)**(5/3) * (Math.PI * f_char)**(8/3));

    const newScenario: Scenario = {
      id: Date.now().toString(),
      name: "Custom Scenario",
      mass1: customScenario.mass1,
      mass2: customScenario.mass2,
      distance: customScenario.distance,
      strain: h,
      frequency: f_char,
      energy: E_rad / 1e44,
      timeToMerger: t_merger / 31557600,
      chirpMass: Mc / solarMass
    };

    setScenarios(prev => [...prev, newScenario]);
  };

  const removeScenario = (id: string) => {
    setScenarios(prev => prev.filter(s => s.id !== id));
  };

  // Prepare data for charts
  const strainData = scenarios.map(s => ({
    name: s.name,
    strain: Math.log10(s.strain),
    id: s.id
  }));

  const energyData = scenarios.map(s => ({
    name: s.name,
    energy: s.energy,
    id: s.id
  }));

  const frequencyData = scenarios.map(s => ({
    name: s.name,
    frequency: s.frequency,
    id: s.id
  }));

  return (
    <div className="space-y-6">
      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <GitCompare className="w-5 h-5" />
            Comparison Tool
          </CardTitle>
          <CardDescription className="text-slate-300">
            Compare different black hole coalescence scenarios
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="scenarios" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="scenarios">Scenarios</TabsTrigger>
              <TabsTrigger value="custom">Custom</TabsTrigger>
            </TabsList>

            <TabsContent value="scenarios" className="space-y-4">
              <div className="grid gap-4">
                {scenarios.map((scenario) => (
                  <Card key={scenario.id} className="bg-slate-700/50 border-slate-600">
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-white text-lg">{scenario.name}</CardTitle>
                          <CardDescription className="text-slate-400">
                            {scenario.mass1} + {scenario.mass2} M☉ at {scenario.distance} Mpc
                          </CardDescription>
                        </div>
                        {scenario.id !== "1" && scenario.id !== "2" && scenario.id !== "3" && (
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => removeScenario(scenario.id)}
                            className="text-red-400 hover:text-red-300"
                          >
                            ×
                          </Button>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <div className="text-slate-400">Strain</div>
                          <div className="text-white font-mono">{scenario.strain.toExponential(1)}</div>
                        </div>
                        <div>
                          <div className="text-slate-400">Frequency</div>
                          <div className="text-white font-mono">{scenario.frequency.toFixed(0)} Hz</div>
                        </div>
                        <div>
                          <div className="text-slate-400">Energy</div>
                          <div className="text-white font-mono">{scenario.energy.toFixed(1)}×10⁴⁴ J</div>
                        </div>
                        <div>
                          <div className="text-slate-400">Chirp Mass</div>
                          <div className="text-white font-mono">{scenario.chirpMass.toFixed(1)} M☉</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="custom" className="space-y-4">
              <Card className="bg-slate-700/50 border-slate-600">
                <CardHeader>
                  <CardTitle className="text-white">Create Custom Scenario</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid md:grid-cols-3 gap-4">
                    <div>
                      <label className="text-slate-300 text-sm">BH 1 Mass (M☉)</label>
                      <input
                        type="number"
                        value={customScenario.mass1}
                        onChange={(e) => setCustomScenario(prev => ({ ...prev, mass1: Number(e.target.value) }))}
                        className="w-full mt-1 px-3 py-2 bg-slate-600 border border-slate-500 rounded text-white"
                        min="5"
                        max="100"
                      />
                    </div>
                    <div>
                      <label className="text-slate-300 text-sm">BH 2 Mass (M☉)</label>
                      <input
                        type="number"
                        value={customScenario.mass2}
                        onChange={(e) => setCustomScenario(prev => ({ ...prev, mass2: Number(e.target.value) }))}
                        className="w-full mt-1 px-3 py-2 bg-slate-600 border border-slate-500 rounded text-white"
                        min="5"
                        max="100"
                      />
                    </div>
                    <div>
                      <label className="text-slate-300 text-sm">Distance (Mpc)</label>
                      <input
                        type="number"
                        value={customScenario.distance}
                        onChange={(e) => setCustomScenario(prev => ({ ...prev, distance: Number(e.target.value) }))}
                        className="w-full mt-1 px-3 py-2 bg-slate-600 border border-slate-500 rounded text-white"
                        min="100"
                        max="5000"
                      />
                    </div>
                  </div>
                  <Button onClick={calculateCustomScenario} className="w-full">
                    Add Scenario
                  </Button>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5" />
              Strain Comparison (log₁₀)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={strainData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgb(71, 85, 105)" />
                  <XAxis dataKey="name" stroke="rgb(148, 163, 184)" fontSize={12} />
                  <YAxis stroke="rgb(148, 163, 184)" fontSize={12} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "rgb(30, 41, 59)", border: "1px solid rgb(71, 85, 105)" }}
                    labelStyle={{ color: "rgb(248, 250, 252)" }}
                  />
                  <Bar dataKey="strain" fill="rgb(100, 149, 237)" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-slate-800/50 border-slate-700">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <Zap className="w-5 h-5" />
              Radiated Energy Comparison
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={energyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgb(71, 85, 105)" />
                  <XAxis dataKey="name" stroke="rgb(148, 163, 184)" fontSize={12} />
                  <YAxis stroke="rgb(148, 163, 184)" fontSize={12} />
                  <Tooltip
                    contentStyle={{ backgroundColor: "rgb(30, 41, 59)", border: "1px solid rgb(71, 85, 105)" }}
                    labelStyle={{ color: "rgb(248, 250, 252)" }}
                  />
                  <Bar dataKey="energy" fill="rgb(168, 85, 247)" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-slate-800/50 border-slate-700">
        <CardHeader>
          <CardTitle className="text-white">Characteristic Frequency vs Total Mass</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={scenarios.map(s => ({
                name: s.name,
                frequency: s.frequency,
                totalMass: s.mass1 + s.mass2
              }))}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgb(71, 85, 105)" />
                <XAxis 
                  dataKey="totalMass" 
                  stroke="rgb(148, 163, 184)" 
                  fontSize={12}
                  label={{ value: 'Total Mass (M☉)', position: 'insideBottom', offset: -5, fill: 'rgb(148, 163, 184)' }}
                />
                <YAxis 
                  stroke="rgb(148, 163, 184)" 
                  fontSize={12}
                  label={{ value: 'Frequency (Hz)', angle: -90, position: 'insideLeft', offset: 10, fill: 'rgb(148, 163, 184)' }}
                />
                <Tooltip
                  contentStyle={{ backgroundColor: "rgb(30, 41, 59)", border: "1px solid rgb(71, 85, 105)" }}
                  labelStyle={{ color: "rgb(248, 250, 252)" }}
                />
                <Line 
                  type="monotone" 
                  dataKey="frequency" 
                  stroke="rgb(34, 197, 94)" 
                  strokeWidth={2}
                  dot={{ fill: "rgb(34, 197, 94)", strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      <ExportTools 
        chartData={scenarios}
        chartRef={chartRef}
        scenarioData={scenarios}
      />
    </div>
  );
}