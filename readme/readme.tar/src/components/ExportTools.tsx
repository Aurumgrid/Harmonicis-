"use client";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Download, FileImage, FileSpreadsheet } from "lucide-react";

interface ExportToolsProps {
  chartData?: any[];
  chartRef?: React.RefObject<any>;
  scenarioData?: any[];
}

export default function ExportTools({ chartData, chartRef, scenarioData }: ExportToolsProps) {
  const exportAsPNG = async () => {
    if (!chartRef?.current) return;
    
    try {
      // Dynamically import html2canvas
      const html2canvas = (await import('html2canvas')).default;
      const canvas = await html2canvas(chartRef.current);
      const link = document.createElement('a');
      link.download = 'gravitational-waves-chart.png';
      link.href = canvas.toDataURL();
      link.click();
    } catch (error) {
      console.error('Error exporting as PNG:', error);
    }
  };

  const exportAsCSV = () => {
    if (!scenarioData || scenarioData.length === 0) return;

    const headers = ['Name', 'Mass 1 (M☉)', 'Mass 2 (M☉)', 'Distance (Mpc)', 'Strain', 'Frequency (Hz)', 'Energy (×10⁴⁴ J)', 'Time to Merger (years)', 'Chirp Mass (M☉)'];
    
    const csvContent = [
      headers.join(','),
      ...scenarioData.map((scenario: any) => [
        scenario.name,
        scenario.mass1,
        scenario.mass2,
        scenario.distance,
        scenario.strain.toExponential(2),
        scenario.frequency.toFixed(2),
        scenario.energy.toFixed(2),
        scenario.timeToMerger.toFixed(2),
        scenario.chirpMass.toFixed(2)
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'gravitational-waves-scenarios.csv';
    link.click();
  };

  const exportAsJSON = () => {
    if (!scenarioData || scenarioData.length === 0) return;

    const jsonContent = JSON.stringify(scenarioData, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = 'gravitational-waves-scenarios.json';
    link.click();
  };

  return (
    <Card className="bg-slate-800/50 border-slate-700">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Download className="w-5 h-5" />
          Export Data
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Button
            onClick={exportAsPNG}
            disabled={!chartRef?.current}
            className="flex items-center gap-2"
          >
            <FileImage className="w-4 h-4" />
            Export Chart (PNG)
          </Button>
          
          <Button
            onClick={exportAsCSV}
            disabled={!scenarioData || scenarioData.length === 0}
            variant="outline"
            className="flex items-center gap-2"
          >
            <FileSpreadsheet className="w-4 h-4" />
            Export Data (CSV)
          </Button>
          
          <Button
            onClick={exportAsJSON}
            disabled={!scenarioData || scenarioData.length === 0}
            variant="outline"
            className="flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            Export Data (JSON)
          </Button>
        </div>
        
        <div className="text-sm text-slate-400 space-y-2">
          <p><Badge variant="secondary">PNG</Badge> Export current chart as image</p>
          <p><Badge variant="secondary">CSV</Badge> Export all scenarios for spreadsheet</p>
          <p><Badge variant="secondary">JSON</Badge> Export raw data for analysis</p>
        </div>
      </CardContent>
    </Card>
  );
}