# TimeChain Wallet API & SDK Reference

## 📚 **Overview**

This document provides a comprehensive reference for the TimeChain Wallet API and SDK, enabling developers to build applications that leverage the unique temporal capabilities of the TimeChain protocol.

---

## 🔌 **RESTful API Reference**

### **Base URL**
```
Mainnet: https://api.timechain.network/v1
Testnet: https://testnet-api.timechain.network/v1
```

### **Authentication**
All API requests require authentication using Bearer tokens:

```http
Authorization: Bearer <your-api-key>
```

### **Wallet Management**

#### Create Wallet
```http
POST /wallets
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "name": "My TimeChain Wallet",
  "network": "mainnet",
  "encryption": {
    "algorithm": "aes-256-gcm",
    "keyDerivation": "scrypt"
  },
  "backup": {
    "enabled": true,
    "providers": ["cloud", "social"]
  }
}
```

**Response:**
```json
{
  "id": "wallet_123456789",
  "name": "My TimeChain Wallet",
  "address": "tc1q...address",
  "network": "mainnet",
  "created_at": "2024-01-01T00:00:00Z",
  "status": "active",
  "encryption": {
    "algorithm": "aes-256-gcm",
    "key_derivation": "scrypt"
  }
}
```

#### Get Wallet
```http
GET /wallets/{walletId}
Authorization: Bearer <api-key>
```

#### Update Wallet
```http
PUT /wallets/{walletId}
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "name": "Updated Wallet Name",
  "settings": {
    "notifications": {
      "temporal_events": true,
      "security_alerts": true
    }
  }
}
```

#### Delete Wallet
```http
DELETE /wallets/{walletId}
Authorization: Bearer <api-key>
```

### **Account Management**

#### Create Account
```http
POST /wallets/{walletId}/accounts
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "name": "Savings Account",
  "type": "hd",
  "derivation_path": "m/44'/9000'/0'/0",
  "metadata": {
    "purpose": "savings",
    "risk_level": "low"
  }
}
```

#### List Accounts
```http
GET /wallets/{walletId}/accounts
Authorization: Bearer <api-key>
```

#### Get Account Balance
```http
GET /wallets/{walletId}/accounts/{accountId}/balance
Authorization: Bearer <api-key>
```

### **Transaction Management**

#### Send Transaction
```http
POST /transactions
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "wallet_id": "wallet_123456789",
  "account_id": "account_987654321",
  "type": "transfer",
  "recipient": "tc1q...recipient",
  "amount": "100.5",
  "asset": "TIME",
  "fee": {
    "strategy": "optimal",
    "max_fee": "0.001"
  },
  "metadata": {
    "memo": "Payment for services"
  }
}
```

#### Get Transaction
```http
GET /transactions/{transactionId}
Authorization: Bearer <api-key>
```

#### List Transactions
```http
GET /wallets/{walletId}/transactions
Authorization: Bearer <api-key>

# Query Parameters
?from=2024-01-01T00:00:00Z
&to=2024-12-31T23:59:59Z
&type=transfer,schedule
&status=pending,confirmed
&limit=50
&offset=0
```

### **Temporal Operations**

#### Schedule Transaction
```http
POST /temporal/schedule
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "wallet_id": "wallet_123456789",
  "transaction": {
    "type": "transfer",
    "recipient": "tc1q...recipient",
    "amount": "1000",
    "asset": "TIME"
  },
  "schedule": {
    "type": "one_time",
    "execute_at": "2024-12-31T23:59:59Z",
    "timezone": "UTC"
  },
  "conditions": [],
  "recurrence": null,
  "metadata": {
    "purpose": "rent_payment",
    "category": "housing"
  }
}
```

#### Schedule Recurring Transaction
```http
POST /temporal/schedule/recurring
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "wallet_id": "wallet_123456789",
  "template": {
    "type": "transfer",
    "recipient": "tc1q...recipient",
    "amount": "500",
    "asset": "TIME"
  },
  "schedule": {
    "type": "recurring",
    "frequency": "monthly",
    "interval": 1,
    "start_date": "2024-01-01T00:00:00Z",
    "end_date": "2024-12-31T23:59:59Z",
    "day_of_month": 1,
    "timezone": "UTC"
  },
  "metadata": {
    "purpose": "subscription_payment",
    "category": "services"
  }
}
```

#### Schedule Conditional Transaction
```http
POST /temporal/schedule/conditional
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "wallet_id": "wallet_123456789",
  "transaction": {
    "type": "transfer",
    "recipient": "tc1q...recipient",
    "amount": "1000",
    "asset": "TIME"
  },
  "condition": {
    "type": "price_above",
    "asset_pair": "TIME/USD",
    "target_price": "100.00",
    "source": "chainlink"
  },
  "timeout": "2024-12-31T23:59:59Z",
  "metadata": {
    "purpose": "investment_trigger",
    "category": "trading"
  }
}
```

#### Get Scheduled Transaction
```http
GET /temporal/schedules/{scheduleId}
Authorization: Bearer <api-key>
```

#### List Scheduled Transactions
```http
GET /wallets/{walletId}/schedules
Authorization: Bearer <api-key>

# Query Parameters
?status=active,completed,failed
&type=one_time,recurring,conditional
&from=2024-01-01T00:00:00Z
&to=2024-12-31T23:59:59Z
```

#### Cancel Scheduled Transaction
```http
DELETE /temporal/schedules/{scheduleId}
Authorization: Bearer <api-key>
```

### **Smart Contract Operations**

#### Deploy Temporal Contract
```http
POST /contracts/deploy
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "wallet_id": "wallet_123456789",
  "bytecode": "0x608060405234801561001057600080fd5b50...",
  "abi": [...],
  "constructor_args": [
    "0x123...address",
    "1000",
    "2024-01-01T00:00:00Z"
  ],
  "deployment_time": "2024-01-01T00:00:00Z",
  "metadata": {
    "name": "Temporal Vesting Contract",
    "version": "1.0.0"
  }
}
```

#### Execute Contract Function
```http
POST /contracts/{contractId}/execute
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "wallet_id": "wallet_123456789",
  "function_name": "release",
  "arguments": ["25"],
  "execute_time": "2024-07-01T00:00:00Z",
  "value": "0",
  "gas_limit": "100000"
}
```

#### Query Contract State
```http
GET /contracts/{contractId}/state
Authorization: Bearer <api-key>

# Query Parameters
?timestamp=2024-01-01T00:00:00Z
&function_name=getBalance
&arguments=0x123...address
```

#### Create Temporal Trigger
```http
POST /contracts/{contractId}/triggers
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "wallet_id": "wallet_123456789",
  "condition": {
    "type": "time_reached",
    "timestamp": "2024-07-01T00:00:00Z"
  },
  "action": {
    "type": "contract_call",
    "function_name": "releaseQuarter",
    "arguments": ["25"]
  },
  "metadata": {
    "purpose": "vesting_release",
    "category": "contract_management"
  }
}
```

### **Historical Queries**

#### Query Historical State
```http
GET /history/state/{contractId}
Authorization: Bearer <api-key>

# Query Parameters
?timestamp=2024-01-01T00:00:00Z
&depth=latest
&include_storage=true
```

#### Query Historical Transactions
```http
GET /history/transactions
Authorization: Bearer <api-key>

# Query Parameters
?address=tc1q...address
&from=2024-01-01T00:00:00Z
&to=2024-12-31T23:59:59Z
&type=all
&limit=100
&offset=0
```

#### Query Chronon Information
```http
GET /history/chronons/{height}
Authorization: Bearer <api-key>
```

### **DeFi Operations**

#### Create Time-Locked Stake
```http
POST /defi/staking/time-locked
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "wallet_id": "wallet_123456789",
  "amount": "5000",
  "asset": "TIME",
  "duration": "31536000", // 1 year in seconds
  "interest_rate": "0.08", // 8% APR
  "compounding": "monthly",
  "metadata": {
    "purpose": "long_term_stake",
    "risk_level": "low"
  }
}
```

#### Create Temporal Option
```http
POST /defi/options/create
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "wallet_id": "wallet_123456789",
  "underlying": "TIME",
  "strike_price": "120.00",
  "expiration_time": "2024-12-31T23:59:59Z",
  "option_type": "call",
  "premium": "5",
  "metadata": {
    "purpose": "speculation",
    "risk_level": "high"
  }
}
```

#### Create Temporal Loan
```http
POST /defi/lending/create
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "wallet_id": "wallet_123456789",
  "principal": "10000",
  "asset": "TIME",
  "collateral": [
    {
      "asset": "TIME",
      "amount": "15000"
    }
  ],
  "repayment_schedule": [
    {
      "due_date": "2024-04-01T00:00:00Z",
      "amount": "2500"
    },
    {
      "due_date": "2024-07-01T00:00:00Z",
      "amount": "2500"
    },
    {
      "due_date": "2024-10-01T00:00:00Z",
      "amount": "2500"
    },
    {
      "due_date": "2025-01-01T00:00:00Z",
      "amount": "2500"
    }
  ],
  "interest_rate": "0.06", // 6% APR
  "metadata": {
    "purpose": "business_expansion",
    "risk_level": "medium"
  }
}
```

---

## 💻 **JavaScript SDK Reference**

### **Installation**
```bash
npm install @timechain/wallet-sdk
```

### **Initialization**
```javascript
import { TimeChainWallet } from '@timechain/wallet-sdk';

// Initialize wallet
const wallet = new TimeChainWallet({
  apiKey: 'your-api-key',
  network: 'mainnet', // 'mainnet' | 'testnet' | 'devnet'
  provider: 'https://mainnet.timechain.network',
  options: {
    timeout: 30000,
    retries: 3
  }
});

// Connect to existing wallet
await wallet.connect('wallet_123456789');
```

### **Wallet Management**

#### Create New Wallet
```javascript
const walletConfig = {
  name: 'My TimeChain Wallet',
  encryption: {
    algorithm: 'aes-256-gcm',
    keyDerivation: 'scrypt'
  },
  backup: {
    enabled: true,
    providers: ['cloud', 'social']
  }
};

const newWallet = await wallet.createWallet(walletConfig);
console.log('Wallet created:', newWallet.id);
```

#### Import Wallet from Mnemonic
```javascript
const mnemonic = 'word1 word2 word3 ...';
const importedWallet = await wallet.importWallet(mnemonic, {
  name: 'Imported Wallet',
  passphrase: 'optional-passphrase'
});
```

#### Generate Mnemonic
```javascript
const mnemonic = await wallet.generateMnemonic();
console.log('Mnemonic:', mnemonic);
```

### **Account Management**

#### Create Account
```javascript
const account = await wallet.createAccount({
  name: 'Savings Account',
  type: 'hd',
  derivationPath: "m/44'/9000'/0'/0",
  metadata: {
    purpose: 'savings',
    riskLevel: 'low'
  }
});
```

#### Get Accounts
```javascript
const accounts = await wallet.getAccounts();
console.log('Accounts:', accounts);
```

#### Get Account Balance
```javascript
const balance = await wallet.getBalance('account_987654321');
console.log('Balance:', balance);
```

### **Transaction Management**

#### Send Transaction
```javascript
const transaction = {
  to: 'tc1q...recipient',
  value: '100.5',
  asset: 'TIME',
  fee: {
    strategy: 'optimal',
    maxFee: '0.001'
  },
  metadata: {
    memo: 'Payment for services'
  }
};

const receipt = await wallet.sendTransaction(transaction);
console.log('Transaction sent:', receipt.hash);
```

#### Get Transaction
```javascript
const tx = await wallet.getTransaction('tx_123456789');
console.log('Transaction:', tx);
```

#### Get Transaction History
```javascript
const history = await wallet.getTransactionHistory({
  from: new Date('2024-01-01'),
  to: new Date('2024-12-31'),
  type: ['transfer', 'schedule'],
  limit: 50
});
```

### **Temporal Operations**

#### Schedule One-Time Transaction
```javascript
const scheduledTx = await wallet.scheduleTransaction({
  to: 'tc1q...recipient',
  value: '1000',
  asset: 'TIME',
  executeAt: new Date('2024-12-31T23:59:59Z'),
  metadata: {
    purpose: 'rent_payment',
    category: 'housing'
  }
});

console.log('Scheduled transaction:', scheduledTx.id);
```

#### Schedule Recurring Transaction
```javascript
const recurringTx = await wallet.scheduleRecurringTransaction({
  to: 'tc1q...recipient',
  value: '500',
  asset: 'TIME',
  schedule: {
    frequency: 'monthly',
    interval: 1,
    startDate: new Date('2024-01-01'),
    endDate: new Date('2024-12-31'),
    dayOfMonth: 1
  },
  metadata: {
    purpose: 'subscription_payment',
    category: 'services'
  }
});
```

#### Schedule Conditional Transaction
```javascript
const conditionalTx = await wallet.scheduleConditionalTransaction({
  to: 'tc1q...recipient',
  value: '1000',
  asset: 'TIME',
  condition: {
    type: 'price_above',
    assetPair: 'TIME/USD',
    targetPrice: '100.00',
    source: 'chainlink'
  },
  timeout: new Date('2024-12-31T23:59:59Z'),
  metadata: {
    purpose: 'investment_trigger',
    category: 'trading'
  }
});
```

#### Get Scheduled Transactions
```javascript
const schedules = await wallet.getScheduledTransactions({
  status: ['active'],
  type: ['one_time', 'recurring', 'conditional']
});
```

#### Cancel Scheduled Transaction
```javascript
await wallet.cancelScheduledTransaction('schedule_123456789');
```

### **Smart Contract Operations**

#### Deploy Temporal Contract
```javascript
const contract = await wallet.deployContract({
  bytecode: '0x608060405234801561001057600080fd5b50...',
  abi: [...],
  constructorArgs: [
    '0x123...address',
    '1000',
    new Date('2024-01-01T00:00:00Z')
  ],
  deploymentTime: new Date('2024-01-01T00:00:00Z'),
  metadata: {
    name: 'Temporal Vesting Contract',
    version: '1.0.0'
  }
});
```

#### Execute Contract Function
```javascript
const result = await wallet.executeContract({
  contract: '0xabc...contract',
  functionName: 'release',
  arguments: ['25'],
  executeTime: new Date('2024-07-01T00:00:00Z'),
  value: '0',
  gasLimit: '100000'
});
```

#### Query Contract State
```javascript
const state = await wallet.queryContractState({
  contract: '0xabc...contract',
  timestamp: new Date('2024-01-01T00:00:00Z'),
  functionName: 'getBalance',
  arguments: ['0x123...address']
});
```

#### Create Temporal Trigger
```javascript
const trigger = await wallet.createTemporalTrigger({
  contract: '0xabc...contract',
  condition: {
    type: 'time_reached',
    timestamp: new Date('2024-07-01T00:00:00Z')
  },
  action: {
    type: 'contract_call',
    functionName: 'releaseQuarter',
    arguments: ['25']
  },
  metadata: {
    purpose: 'vesting_release',
    category: 'contract_management'
  }
});
```

### **Historical Queries**

#### Query Historical State
```javascript
const historicalState = await wallet.queryHistoricalState({
  contract: '0xabc...contract',
  timestamp: new Date('2024-01-01T00:00:00Z'),
  depth: 'latest',
  includeStorage: true
});
```

#### Query Historical Transactions
```javascript
const historicalTxs = await wallet.queryHistoricalTransactions({
  address: 'tc1q...address',
  from: new Date('2024-01-01'),
  to: new Date('2024-12-31'),
  type: 'all',
  limit: 100
});
```

### **DeFi Operations**

#### Create Time-Locked Stake
```javascript
const stake = await wallet.createTimeLockedStake({
  amount: '5000',
  asset: 'TIME',
  duration: 31536000, // 1 year in seconds
  interestRate: '0.08', // 8% APR
  compounding: 'monthly',
  metadata: {
    purpose: 'long_term_stake',
    riskLevel: 'low'
  }
});
```

#### Create Temporal Option
```javascript
const option = await wallet.createTemporalOption({
  underlying: 'TIME',
  strikePrice: '120.00',
  expirationTime: new Date('2024-12-31T23:59:59Z'),
  optionType: 'call',
  premium: '5',
  metadata: {
    purpose: 'speculation',
    riskLevel: 'high'
  }
});
```

#### Create Temporal Loan
```javascript
const loan = await wallet.createTemporalLoan({
  principal: '10000',
  asset: 'TIME',
  collateral: [
    {
      asset: 'TIME',
      amount: '15000'
    }
  ],
  repaymentSchedule: [
    {
      dueDate: new Date('2024-04-01'),
      amount: '2500'
    },
    {
      dueDate: new Date('2024-07-01'),
      amount: '2500'
    },
    {
      dueDate: new Date('2024-10-01'),
      amount: '2500'
    },
    {
      dueDate: new Date('2025-01-01'),
      amount: '2500'
    }
  ],
  interestRate: '0.06', // 6% APR
  metadata: {
    purpose: 'business_expansion',
    riskLevel: 'medium'
  }
});
```

### **Event Handling**

#### Listen to Wallet Events
```javascript
// Wallet events
wallet.on('connected', (walletId) => {
  console.log('Wallet connected:', walletId);
});

wallet.on('disconnected', () => {
  console.log('Wallet disconnected');
});

wallet.on('error', (error) => {
  console.error('Wallet error:', error);
});

// Transaction events
wallet.on('transactionSent', (transaction) => {
  console.log('Transaction sent:', transaction);
});

wallet.on('transactionConfirmed', (confirmation) => {
  console.log('Transaction confirmed:', confirmation);
});

// Temporal events
wallet.on('temporalEvent', (event) => {
  console.log('Temporal event:', event);
});

wallet.on('scheduleCreated', (schedule) => {
  console.log('Schedule created:', schedule);
});

wallet.on('scheduleExecuted', (execution) => {
  console.log('Schedule executed:', execution);
});

// Smart contract events
wallet.on('contractDeployed', (contract) => {
  console.log('Contract deployed:', contract);
});

wallet.on('contractExecuted', (execution) => {
  console.log('Contract executed:', execution);
});

// DeFi events
wallet.on('stakeCreated', (stake) => {
  console.log('Stake created:', stake);
});

wallet.on('optionCreated', (option) => {
  console.log('Option created:', option);
});
```

#### Remove Event Listeners
```javascript
// Remove specific listener
wallet.off('transactionSent', handlerFunction);

// Remove all listeners for an event
wallet.off('temporalEvent');

// Remove all listeners
wallet.removeAllListeners();
```

### **Security Operations**

#### Encrypt Wallet Data
```javascript
const encrypted = await wallet.encryptData('sensitive data', 'password');
console.log('Encrypted data:', encrypted);
```

#### Decrypt Wallet Data
```javascript
const decrypted = await wallet.decryptData(encrypted, 'password');
console.log('Decrypted data:', decrypted);
```

#### Sign Message
```javascript
const message = 'Hello, TimeChain!';
const signature = await wallet.signMessage(message, 'account_987654321');
console.log('Signature:', signature);
```

#### Verify Signature
```javascript
const isValid = await wallet.verifySignature(message, signature, 'public_key');
console.log('Signature valid:', isValid);
```

### **Multi-Signature Operations**

#### Create Multi-Signature Wallet
```javascript
const multiSigWallet = await wallet.createMultiSigWallet({
  participants: [
    '0x123...alice',
    '0x456...bob',
    '0x789...charlie'
  ],
  requiredSignatures: 2,
  name: 'Team Wallet',
  metadata: {
    purpose: 'team_funds',
    riskLevel: 'medium'
  }
});
```

#### Create Multi-Signature Transaction
```javascript
const multiSigTx = await wallet.createMultiSigTransaction({
  participants: [
    '0x123...alice',
    '0x456...bob',
    '0x789...charlie'
  ],
  requiredSignatures: 2,
  transaction: {
    to: 'tc1q...recipient',
    value: '10000',
    asset: 'TIME'
  },
  executeTime: new Date('2024-12-31T23:59:59Z'),
  metadata: {
    purpose: 'team_payment',
    category: 'business'
  }
});
```

#### Sign Multi-Signature Transaction
```javascript
const signedTx = await wallet.signMultiSigTransaction(
  'multi_sig_tx_123456789',
  'account_987654321'
);
```

### **Hardware Wallet Integration**

#### Connect Hardware Wallet
```javascript
const hwWallet = await wallet.connectHardwareWallet({
  type: 'ledger', // 'ledger' | 'trezor' | 'keepkey'
  transport: 'usb' // 'usb' | 'ble' | 'webusb'
});
```

#### Get Hardware Wallet Accounts
```javascript
const accounts = await hwWallet.getAccounts();
console.log('Hardware wallet accounts:', accounts);
```

#### Sign with Hardware Wallet
```javascript
const signature = await hwWallet.signTransaction(transaction, account);
console.log('Hardware wallet signature:', signature);
```

---

## 📱 **Mobile SDK Reference (React Native)**

### **Installation**
```bash
npm install @timechain/react-native-wallet-sdk
```

### **Initialization**
```javascript
import { TimeChainWallet } from '@timechain/react-native-wallet-sdk';

const wallet = new TimeChainWallet({
  apiKey: 'your-api-key',
  network: 'mainnet',
  options: {
    biometricAuthentication: true,
    secureStorage: true
  }
});
```

### **Biometric Authentication**
```javascript
// Enable biometric authentication
const isAuthenticated = await wallet.authenticateWithBiometrics();
if (isAuthenticated) {
  console.log('Biometric authentication successful');
}
```

### **Secure Storage**
```javascript
// Store sensitive data securely
await wallet.secureStore('private_key', 'encrypted_private_key');

// Retrieve sensitive data
const privateKey = await wallet.secureRetrieve('private_key');
```

### **Push Notifications**
```javascript
// Register for push notifications
await wallet.registerForPushNotifications();

// Handle temporal notifications
wallet.handleTemporalNotification((notification) => {
  console.log('Temporal notification:', notification);
  
  // Show local notification
  Notifications.postLocalNotification({
    title: 'Temporal Event',
    body: notification.message,
    sound: 'default',
    category: 'TEMPORAL_EVENT'
  });
});
```

### **Camera Integration**
```javascript
// Scan QR code
const qrData = await wallet.scanQRCode();
console.log('QR Code data:', qrData);

// Generate QR code
const qrCode = await wallet.generateQRCode('tc1q...address');
console.log('Generated QR code:', qrCode);
```

---

## 🔧 **CLI Tool Reference**

### **Installation**
```bash
npm install -g @timechain/cli
```

### **Basic Commands**

#### Initialize Wallet
```bash
timechain wallet init --name "My Wallet" --network mainnet
```

#### Import Wallet
```bash
timechain wallet import --mnemonic "word1 word2 word3 ..." --name "Imported Wallet"
```

#### Check Balance
```bash
timechain balance --account default
```

#### Send Transaction
```bash
timechain send --to tc1q...recipient --amount 100.5 --asset TIME --memo "Payment"
```

### **Temporal Commands**

#### Schedule Transaction
```bash
timechain schedule \
  --to tc1q...recipient \
  --amount 1000 \
  --asset TIME \
  --time "2024-12-31T23:59:59Z" \
  --memo "Rent payment"
```

#### Schedule Recurring Transaction
```bash
timechain schedule-recurring \
  --to tc1q...recipient \
  --amount 500 \
  --asset TIME \
  --frequency monthly \
  --start "2024-01-01" \
  --end "2024-12-31" \
  --day-of-month 1 \
  --memo "Subscription payment"
```

#### List Scheduled Transactions
```bash
timechain list-schedules --status active --type recurring
```

#### Cancel Scheduled Transaction
```bash
timechain cancel-schedule schedule_123456789
```

### **Smart Contract Commands**

#### Deploy Contract
```bash
timechain deploy-contract \
  --bytecode contract.bytecode \
  --abi contract.abi \
  --args "0x123...address" "1000" "2024-01-01T00:00:00Z" \
  --name "Vesting Contract"
```

#### Execute Contract
```bash
timechain execute-contract \
  --contract 0xabc...contract \
  --function release \
  --args 25 \
  --time "2024-07-01T00:00:00Z"
```

#### Query Contract State
```bash
timechain query-contract \
  --contract 0xabc...contract \
  --function getBalance \
  --args 0x123...address \
  --time "2024-01-01T00:00:00Z"
```

### **DeFi Commands**

#### Create Stake
```bash
timechain stake \
  --amount 5000 \
  --asset TIME \
  --duration 31536000 \
  --interest-rate 0.08 \
  --compounding monthly
```

#### Create Option
```bash
timechain create-option \
  --underlying TIME \
  --strike-price 120.00 \
  --expiration "2024-12-31T23:59:59Z" \
  --type call \
  --premium 5
```

### **Configuration Commands**

#### Set Configuration
```bash
timechain config set network mainnet
timechain config set api-key your-api-key
timechain config set timeout 30000
```

#### Get Configuration
```bash
timechain config get network
timechain config list
```

### **Utility Commands**

#### Generate Mnemonic
```bash
timechain generate-mnemonic
```

#### Validate Address
```bash
timechain validate-address tc1q...address
```

#### Get Network Info
```bash
timechain network-info
```

#### Get Chronon Info
```bash
timechain chronon-info --height 123456
```

---

## 🔄 **Webhook Reference**

### **Webhook Events**

#### Transaction Events
```json
{
  "event": "transaction.sent",
  "data": {
    "transaction_id": "tx_123456789",
    "wallet_id": "wallet_123456789",
    "amount": "100.5",
    "asset": "TIME",
    "recipient": "tc1q...recipient",
    "status": "pending",
    "timestamp": "2024-01-01T00:00:00Z"
  }
}
```

#### Temporal Events
```json
{
  "event": "temporal.schedule_created",
  "data": {
    "schedule_id": "schedule_123456789",
    "wallet_id": "wallet_123456789",
    "type": "one_time",
    "execute_at": "2024-12-31T23:59:59Z",
    "status": "active",
    "created_at": "2024-01-01T00:00:00Z"
  }
}
```

#### Smart Contract Events
```json
{
  "event": "contract.deployed",
  "data": {
    "contract_id": "contract_123456789",
    "wallet_id": "wallet_123456789",
    "address": "0xabc...contract",
    "bytecode_hash": "0x123...",
    "deployment_time": "2024-01-01T00:00:00Z"
  }
}
```

#### DeFi Events
```json
{
  "event": "defi.stake_created",
  "data": {
    "stake_id": "stake_123456789",
    "wallet_id": "wallet_123456789",
    "amount": "5000",
    "asset": "TIME",
    "duration": 31536000,
    "interest_rate": "0.08",
    "created_at": "2024-01-01T00:00:00Z"
  }
}
```

### **Webhook Management**

#### Create Webhook
```http
POST /webhooks
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "url": "https://your-app.com/webhook",
  "events": ["transaction.sent", "temporal.schedule_created"],
  "secret": "your-webhook-secret"
}
```

#### List Webhooks
```http
GET /webhooks
Authorization: Bearer <api-key>
```

#### Update Webhook
```http
PUT /webhooks/{webhookId}
Content-Type: application/json
Authorization: Bearer <api-key>

{
  "url": "https://updated-app.com/webhook",
  "events": ["transaction.sent", "temporal.schedule_created", "contract.deployed"]
}
```

#### Delete Webhook
```http
DELETE /webhooks/{webhookId}
Authorization: Bearer <api-key>
```

---

## 📚 **Error Handling**

### **Error Codes**

| Code | Name | Description |
|------|------|-------------|
| 1001 | WALLET_NOT_FOUND | Wallet not found |
| 1002 | ACCOUNT_NOT_FOUND | Account not found |
| 1003 | INSUFFICIENT_BALANCE | Insufficient balance |
| 1004 | INVALID_ADDRESS | Invalid address format |
| 1005 | TRANSACTION_FAILED | Transaction failed |
| 2001 | SCHEDULE_NOT_FOUND | Scheduled transaction not found |
| 2002 | INVALID_SCHEDULE_TIME | Invalid schedule time |
| 2003 | SCHEDULE_ALREADY_EXISTS | Schedule already exists |
| 3001 | CONTRACT_NOT_FOUND | Contract not found |
| 3002 | CONTRACT_DEPLOYMENT_FAILED | Contract deployment failed |
| 3003 | CONTRACT_EXECUTION_FAILED | Contract execution failed |
| 4001 | DEFI_OPERATION_FAILED | DeFi operation failed |
| 4002 | INSUFFICIENT_COLLATERAL | Insufficient collateral |
| 5001 | AUTHENTICATION_FAILED | Authentication failed |
| 5002 | AUTHORIZATION_FAILED | Authorization failed |
| 5003 | RATE_LIMIT_EXCEEDED | Rate limit exceeded |

### **Error Response Format**
```json
{
  "error": {
    "code": 1001,
    "message": "Wallet not found",
    "details": "Wallet with ID 'wallet_123456789' not found",
    "timestamp": "2024-01-01T00:00:00Z",
    "request_id": "req_123456789"
  }
}
```

### **Error Handling Examples**

#### JavaScript SDK
```javascript
try {
  const result = await wallet.sendTransaction({
    to: 'tc1q...recipient',
    value: '100.5',
    asset: 'TIME'
  });
} catch (error) {
  if (error.code === 1003) {
    console.error('Insufficient balance:', error.message);
  } else if (error.code === 1004) {
    console.error('Invalid address:', error.message);
  } else {
    console.error('Transaction failed:', error.message);
  }
}
```

#### REST API
```javascript
try {
  const response = await fetch('/transactions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': 'Bearer your-api-key'
    },
    body: JSON.stringify({
      wallet_id: 'wallet_123456789',
      to: 'tc1q...recipient',
      amount: '100.5',
      asset: 'TIME'
    })
  });
  
  if (!response.ok) {
    const error = await response.json();
    console.error('API Error:', error.error);
    return;
  }
  
  const result = await response.json();
  console.log('Transaction sent:', result);
} catch (error) {
  console.error('Network error:', error);
}
```

---

*This comprehensive API and SDK reference provides developers with all the tools needed to build applications that leverage the unique temporal capabilities of the TimeChain Wallet.*