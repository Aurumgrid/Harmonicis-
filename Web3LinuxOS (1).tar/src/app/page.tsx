'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Progress } from '@/components/ui/progress'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { 
  Activity, 
  Cpu, 
  HardDrive, 
  Network, 
  Shield, 
  Terminal,
  Clock,
  Zap,
  BarChart3,
  Settings,
  Play,
  Pause,
  RefreshCw,
  Plus,
  Database,
  Key,
  FileText,
  Users,
  Globe,
  Hash,
  Layers,
  Monitor,
  Smartphone,
  Server,
  Cloud,
  Lock,
  Unlock,
  AlertTriangle,
  CheckCircle,
  TrendingUp,
  TrendingDown,
  Minus,
  Command,
  Code,
  Braces,
  Calendar,
  Timer,
  History,
  Forward,
  Rewind,
  Folder
} from 'lucide-react'
import { toast } from 'sonner'
import RealTimeStats from '@/components/RealTimeStats'
import AdvancedAnalytics from '@/components/AdvancedAnalytics'
import { PerformanceDashboard } from '@/components/PerformanceDashboard'
import { useRealTimeUpdates } from '@/hooks/useRealTimeUpdates'
import { NotificationSystem, useNotifications } from '@/components/ui/notification-system'
import { Loading, CardSkeleton } from '@/components/ui/loading'

// Web3 Linux OS Types
interface SystemProcess {
  id: string
  name: string
  pid: number
  state: 'running' | 'sleeping' | 'stopped' | 'zombie'
  cpuUsage: number
  memoryUsage: number
  startTime: Date
  user: string
  temporalProof: string
  chronon: number
}

interface FileSystemEntry {
  path: string
  name: string
  type: 'file' | 'directory' | 'symlink'
  size: number
  modified: Date
  permissions: string
  owner: string
  temporalVersions: number
  contentHash?: string
}

interface NetworkConnection {
  id: string
  localAddress: string
  remoteAddress: string
  protocol: 'tcp' | 'udp' | 'websocket'
  state: 'established' | 'listening' | 'time_wait' | 'closed'
  bytesSent: number
  bytesReceived: number
  blockchainVerified: boolean
}

interface SmartContract {
  address: string
  name: string
  version: string
  status: 'active' | 'inactive' | 'deploying' | 'error'
  deploymentHash: string
  gasUsed: number
  createdAt: Date
  lastInteraction: Date
  functions: string[]
}

interface SystemMetrics {
  cpu: {
    usage: number
    cores: number
    frequency: number
    temperature: number
  }
  memory: {
    total: number
    used: number
    free: number
    cached: number
    buffers: number
  }
  storage: {
    total: number
    used: number
    free: number
    readSpeed: number
    writeSpeed: number
  }
  network: {
    bytesIn: number
    bytesOut: number
    packetsIn: number
    packetsOut: number
    connections: number
  }
  blockchain: {
    syncProgress: number
    currentBlock: number
    latestBlock: number
    chronon: number
    networkStatus: 'syncing' | 'synced' | 'error'
  }
}

interface TemporalSnapshot {
  id: string
  chronon: number
  timestamp: Date
  systemState: SystemMetrics
  processes: SystemProcess[]
  filesystemHash: string
  merkleRoot: string
  size: number
}

export default function Web3LinuxOS() {
  const [systemMetrics, setSystemMetrics] = useState<SystemMetrics>({
    cpu: { usage: 0, cores: 8, frequency: 3200, temperature: 45 },
    memory: { total: 16384, used: 8192, free: 8192, cached: 2048, buffers: 1024 },
    storage: { total: 1000000, used: 500000, free: 500000, readSpeed: 0, writeSpeed: 0 },
    network: { bytesIn: 0, bytesOut: 0, packetsIn: 0, packetsOut: 0, connections: 0 },
    blockchain: { syncProgress: 100, currentBlock: 0, latestBlock: 0, chronon: 0, networkStatus: 'synced' }
  })

  const [processes, setProcesses] = useState<SystemProcess[]>([])
  const [filesystem, setFilesystem] = useState<FileSystemEntry[]>([])
  const [networkConnections, setNetworkConnections] = useState<NetworkConnection[]>([])
  const [smartContracts, setSmartContracts] = useState<SmartContract[]>([])
  const [temporalSnapshots, setTemporalSnapshots] = useState<TemporalSnapshot[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState('dashboard')
  const [currentPath, setCurrentPath] = useState('/')
  const [commandHistory, setCommandHistory] = useState<string[]>([])
  const [currentCommand, setCurrentCommand] = useState('')
  const [selectedProcess, setSelectedProcess] = useState<SystemProcess | null>(null)
  const [selectedContract, setSelectedContract] = useState<SmartContract | null>(null)
  
  // Notification system
  const { notifications, addNotification, markAsRead, dismiss } = useNotifications()
  
  // Real-time updates
  const { isConnected, lastEvent, emitEvent } = useRealTimeUpdates()

  useEffect(() => {
    fetchSystemData()
    const interval = setInterval(fetchSystemData, 5000) // Update every 5 seconds
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    if (lastEvent) {
      handleRealTimeEvent(lastEvent)
    }
  }, [lastEvent])

  const fetchSystemData = async () => {
    try {
      // Fetch real system metrics
      const metricsResponse = await fetch('/api/system/metrics')
      if (metricsResponse.ok) {
        const metrics = await metricsResponse.json()
        setSystemMetrics(metrics)
      }

      // Fetch processes
      const processesResponse = await fetch('/api/processes')
      if (processesResponse.ok) {
        const processesData = await processesResponse.json()
        setProcesses(processesData.data || [])
      }

      // Fetch filesystem
      const filesystemResponse = await fetch('/api/filesystem')
      if (filesystemResponse.ok) {
        const filesystemData = await filesystemResponse.json()
        setFilesystem(filesystemData.data || [])
      }

      // Fetch blockchain info
      const blockchainResponse = await fetch('/api/blockchain')
      if (blockchainResponse.ok) {
        const blockchainData = await blockchainResponse.json()
        // Update blockchain metrics in system state
        setSystemMetrics(prev => ({
          ...prev,
          blockchain: {
            syncProgress: blockchainData.syncProgress,
            currentBlock: blockchainData.currentBlock,
            latestBlock: blockchainData.latestBlock,
            chronon: blockchainData.chronon,
            networkStatus: blockchainData.networkStatus
          }
        }))
      }

      // Fetch smart contracts
      const contractsResponse = await fetch('/api/contracts')
      if (contractsResponse.ok) {
        const contractsData = await contractsResponse.json()
        setSmartContracts(contractsData.data || [])
      }
      
      setIsLoading(false)
    } catch (error) {
      console.error('Error fetching system data:', error)
      setIsLoading(false)
    }
  }

  const handleRealTimeEvent = (event: any) => {
    switch (event.type) {
      case 'system_metrics':
        setSystemMetrics(event.data)
        break
      case 'process_update':
        setProcesses(prev => 
          prev.map(p => p.id === event.data.id ? event.data : p)
        )
        break
      case 'blockchain_update':
        setSystemMetrics(prev => ({
          ...prev,
          blockchain: event.data
        }))
        break
      default:
        console.log('Unhandled real-time event:', event)
    }
  }

  const executeCommand = async (command: string) => {
    if (!command.trim()) return

    setCommandHistory(prev => [...prev, command])
    setCurrentCommand('')

    try {
      const response = await fetch('/api/terminal', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          command: command.split(' ')[0],
          args: command.split(' ').slice(1),
          workingDirectory: currentPath,
          environment: {}
        }),
      })

      if (response.ok) {
        const result = await response.json()
        
        addNotification({
          id: Date.now().toString(),
          title: 'Command Executed',
          message: result.output,
          type: 'success',
          timestamp: new Date()
        })

        toast.success(`Command executed: ${command}`)
        
        // Emit real-time event
        emitEvent('command_executed', { command, result })
      } else {
        const error = await response.json()
        toast.error(`Command execution failed: ${error.error}`)
      }
    } catch (error) {
      toast.error(`Command execution failed: ${command}`)
    }
  }

  const createTemporalSnapshot = async () => {
    try {
      const response = await fetch('/api/blockchain', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'create_snapshot',
          data: {
            systemState: systemMetrics,
            processes: processes,
            description: 'Manual snapshot created from dashboard',
            tags: ['manual', 'dashboard']
          }
        }),
      })

      if (response.ok) {
        const snapshot = await response.json()
        setTemporalSnapshots(prev => [snapshot, ...prev])
        
        addNotification({
          id: Date.now().toString(),
          title: 'Temporal Snapshot Created',
          message: `Snapshot created at chronon ${snapshot.chronon}`,
          type: 'success',
          timestamp: new Date()
        })

        toast.success('Temporal snapshot created successfully')
      } else {
        const error = await response.json()
        toast.error(`Snapshot creation failed: ${error.error}`)
      }
    } catch (error) {
      toast.error('Failed to create temporal snapshot')
    }
  }

  const deploySmartContract = async (contractData: any) => {
    try {
      const response = await fetch('/api/contracts', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          action: 'deploy',
          data: {
            name: contractData.name,
            version: contractData.version,
            sourceCode: contractData.sourceCode,
            bytecode: contractData.bytecode || '0x' + Math.random().toString(16).substr(2, 64),
            abi: contractData.abi || [],
            compilerVersion: contractData.compilerVersion || '0.8.19',
            optimization: contractData.optimization || true,
            runs: contractData.runs || 200,
            constructorArgs: contractData.constructorArgs || [],
            gasLimit: contractData.gasLimit || 2000000,
            value: contractData.value || 0,
            description: contractData.description,
            tags: contractData.tags || []
          }
        }),
      })

      if (response.ok) {
        const newContract = await response.json()
        setSmartContracts(prev => [newContract, ...prev])
        
        // Simulate deployment completion
        setTimeout(() => {
          setSmartContracts(prev => 
            prev.map(c => c.address === newContract.address 
              ? { ...c, status: 'active' } 
              : c
            )
          )
        }, 5000)

        toast.success('Smart contract deployment initiated')
      } else {
        const error = await response.json()
        toast.error(`Contract deployment failed: ${error.error}`)
      }
    } catch (error) {
      toast.error('Failed to deploy smart contract')
    }
  }

  const formatBytes = (bytes: number): string => {
    if (bytes === 0) return '0 B'
    const k = 1024
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i]
  }

  const formatUptime = (seconds: number): string => {
    const days = Math.floor(seconds / 86400)
    const hours = Math.floor((seconds % 86400) / 3600)
    const minutes = Math.floor((seconds % 3600) / 60)
    return `${days}d ${hours}h ${minutes}m`
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running':
      case 'active':
      case 'established':
      case 'synced':
        return 'bg-green-100 text-green-800'
      case 'sleeping':
      case 'listening':
        return 'bg-blue-100 text-blue-800'
      case 'stopped':
      case 'inactive':
      case 'closed':
        return 'bg-gray-100 text-gray-800'
      case 'zombie':
      case 'error':
        return 'bg-red-100 text-red-800'
      case 'deploying':
      case 'syncing':
        return 'bg-yellow-100 text-yellow-800'
      default:
        return 'bg-gray-100 text-gray-800'
    }
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background p-6">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-4xl font-bold text-foreground mb-2">Web3 Linux OS</h1>
            <p className="text-muted-foreground">Loading system...</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <CardSkeleton key={i} />
            ))}
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b bg-card">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Layers className="h-8 w-8 text-primary" />
                <h1 className="text-2xl font-bold text-foreground">Web3 Linux OS</h1>
              </div>
              <Badge variant="outline" className="flex items-center space-x-1">
                <span>Chronon</span>
                <span className="font-mono">{systemMetrics.blockchain.chronon}</span>
              </Badge>
              <Badge variant="outline" className="flex items-center space-x-1">
                <span>Block</span>
                <span className="font-mono">{systemMetrics.blockchain.currentBlock}</span>
              </Badge>
            </div>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={fetchSystemData}>
                <RefreshCw className="h-4 w-4 mr-2" />
                Refresh
              </Button>
              <Button variant="outline" size="sm" onClick={createTemporalSnapshot}>
                <History className="h-4 w-4 mr-2" />
                Snapshot
              </Button>
              <Badge variant={isConnected ? "default" : "destructive"}>
                {isConnected ? "Connected" : "Disconnected"}
              </Badge>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-6 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="processes">Processes</TabsTrigger>
            <TabsTrigger value="filesystem">Filesystem</TabsTrigger>
            <TabsTrigger value="blockchain">Blockchain</TabsTrigger>
            <TabsTrigger value="contracts">Contracts</TabsTrigger>
            <TabsTrigger value="terminal">Terminal</TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            {/* System Metrics Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">CPU Usage</CardTitle>
                  <Cpu className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{systemMetrics.cpu.usage.toFixed(1)}%</div>
                  <Progress value={systemMetrics.cpu.usage} className="mt-2" />
                  <p className="text-xs text-muted-foreground mt-2">
                    {systemMetrics.cpu.cores} cores @ {systemMetrics.cpu.frequency}MHz
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Memory Usage</CardTitle>
                  <Activity className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {((systemMetrics.memory.used / systemMetrics.memory.total) * 100).toFixed(1)}%
                  </div>
                  <Progress 
                    value={(systemMetrics.memory.used / systemMetrics.memory.total) * 100} 
                    className="mt-2" 
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    {formatBytes(systemMetrics.memory.used)} / {formatBytes(systemMetrics.memory.total)}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Storage</CardTitle>
                  <HardDrive className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">
                    {((systemMetrics.storage.used / systemMetrics.storage.total) * 100).toFixed(1)}%
                  </div>
                  <Progress 
                    value={(systemMetrics.storage.used / systemMetrics.storage.total) * 100} 
                    className="mt-2" 
                  />
                  <p className="text-xs text-muted-foreground mt-2">
                    {formatBytes(systemMetrics.storage.used)} / {formatBytes(systemMetrics.storage.total)}
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Network</CardTitle>
                  <Network className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{systemMetrics.network.connections}</div>
                  <p className="text-xs text-muted-foreground mt-2">
                    ↓ {formatBytes(systemMetrics.network.bytesIn)} ↑ {formatBytes(systemMetrics.network.bytesOut)}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Blockchain Status */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Hash className="h-5 w-5" />
                  <span>Blockchain Status</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Sync Progress</span>
                      <span className="text-sm">{systemMetrics.blockchain.syncProgress}%</span>
                    </div>
                    <Progress value={systemMetrics.blockchain.syncProgress} />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Current Block</span>
                      <span className="text-sm font-mono">{systemMetrics.blockchain.currentBlock}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Latest Block</span>
                      <span className="text-sm font-mono">{systemMetrics.blockchain.latestBlock}</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Network Status</span>
                      <Badge className={getStatusColor(systemMetrics.blockchain.networkStatus)}>
                        {systemMetrics.blockchain.networkStatus}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Current Chronon</span>
                      <span className="text-sm font-mono">{systemMetrics.blockchain.chronon}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Real-time Analytics */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <RealTimeStats />
              <AdvancedAnalytics />
            </div>
          </TabsContent>

          {/* Processes Tab */}
          <TabsContent value="processes" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Activity className="h-5 w-5" />
                  <span>System Processes</span>
                </CardTitle>
                <CardDescription>
                  Monitor and manage system processes with temporal verification
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {processes.map((process) => (
                    <div key={process.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-2">
                          <Badge className={getStatusColor(process.state)}>
                            {process.state}
                          </Badge>
                          <span className="font-medium">{process.name}</span>
                        </div>
                        <div className="text-sm text-muted-foreground">
                          PID: {process.pid} | User: {process.user}
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <div className="text-sm font-medium">CPU: {process.cpuUsage.toFixed(1)}%</div>
                          <div className="text-sm text-muted-foreground">
                            Memory: {formatBytes(process.memoryUsage)}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-xs text-muted-foreground">Chronon</div>
                          <div className="text-sm font-mono">{process.chronon}</div>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedProcess(process)}
                        >
                          Details
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Filesystem Tab */}
          <TabsContent value="filesystem" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <HardDrive className="h-5 w-5" />
                  <span>Temporal Filesystem</span>
                </CardTitle>
                <CardDescription>
                  Navigate and manage files with temporal versioning
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-2">
                    <Input value={currentPath} readOnly className="flex-1" />
                    <Button variant="outline" size="sm">
                      <RefreshCw className="h-4 w-4" />
                    </Button>
                    <Button variant="outline" size="sm">
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                  <div className="space-y-2">
                    {filesystem.map((entry) => (
                      <div key={entry.path} className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50">
                        <div className="flex items-center space-x-3">
                          {entry.type === 'directory' ? (
                            <Folder className="h-4 w-4 text-blue-500" />
                          ) : (
                            <FileText className="h-4 w-4 text-gray-500" />
                          )}
                          <div>
                            <div className="font-medium">{entry.name}</div>
                            <div className="text-sm text-muted-foreground">
                              {entry.permissions} | {entry.owner} | {formatBytes(entry.size)}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="outline">
                            {entry.temporalVersions} versions
                          </Badge>
                          <Button variant="outline" size="sm">
                            <History className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Blockchain Tab */}
          <TabsContent value="blockchain" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Hash className="h-5 w-5" />
                    <span>Network Information</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Network ID</label>
                        <div className="text-sm text-muted-foreground">web3-linux-mainnet</div>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Chain ID</label>
                        <div className="text-sm text-muted-foreground">31337</div>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Consensus</label>
                        <div className="text-sm text-muted-foreground">Proof-of-Time</div>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Gas Price</label>
                        <div className="text-sm text-muted-foreground">20 Gwei</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Timer className="h-5 w-5" />
                    <span>Temporal Snapshots</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {temporalSnapshots.slice(0, 5).map((snapshot) => (
                      <div key={snapshot.id} className="flex items-center justify-between p-2 border rounded">
                        <div>
                          <div className="text-sm font-medium">Chronon {snapshot.chronon}</div>
                          <div className="text-xs text-muted-foreground">
                            {snapshot.timestamp.toLocaleString()}
                          </div>
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {formatBytes(snapshot.size)}
                        </div>
                      </div>
                    ))}
                    {temporalSnapshots.length === 0 && (
                      <div className="text-center text-muted-foreground py-4">
                        No temporal snapshots available
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Smart Contracts Tab */}
          <TabsContent value="contracts" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center space-x-2">
                      <Code className="h-5 w-5" />
                      <span>Smart Contracts</span>
                    </CardTitle>
                    <CardDescription>
                      Deploy and manage smart contracts on the blockchain
                    </CardDescription>
                  </div>
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button>
                        <Plus className="h-4 w-4 mr-2" />
                        Deploy Contract
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Deploy Smart Contract</DialogTitle>
                        <DialogDescription>
                          Deploy a new smart contract to the blockchain
                        </DialogDescription>
                      </DialogHeader>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="contract-name">Contract Name</Label>
                          <Input id="contract-name" placeholder="MyContract" />
                        </div>
                        <div>
                          <Label htmlFor="contract-version">Version</Label>
                          <Input id="contract-version" placeholder="1.0.0" />
                        </div>
                        <div>
                          <Label htmlFor="contract-code">Contract Code</Label>
                          <Textarea 
                            id="contract-code" 
                            placeholder="// Solidity contract code"
                            rows={10}
                          />
                        </div>
                        <div>
                          <Label htmlFor="gas-limit">Gas Limit</Label>
                          <Input id="gas-limit" type="number" placeholder="2000000" />
                        </div>
                      </div>
                      <DialogFooter>
                        <Button variant="outline">Cancel</Button>
                        <Button onClick={() => deploySmartContract({
                          name: (document.getElementById('contract-name') as HTMLInputElement)?.value || '',
                          version: (document.getElementById('contract-version') as HTMLInputElement)?.value || '',
                          sourceCode: (document.getElementById('contract-code') as HTMLTextAreaElement)?.value || '',
                          gasLimit: parseInt((document.getElementById('gas-limit') as HTMLInputElement)?.value || '2000000'),
                          description: 'Deployed from dashboard',
                          tags: ['dashboard', 'manual']
                        })}>
                          Deploy Contract
                        </Button>
                      </DialogFooter>
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {smartContracts.map((contract) => (
                    <div key={contract.address} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className="font-medium">{contract.name}</span>
                            <Badge variant="outline">{contract.version}</Badge>
                            <Badge className={getStatusColor(contract.status)}>
                              {contract.status}
                            </Badge>
                          </div>
                          <div className="text-sm text-muted-foreground font-mono">
                            {contract.address}
                          </div>
                          <div className="text-xs text-muted-foreground">
                            Gas: {contract.gasUsed.toLocaleString()} | Functions: {contract.functions.length}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedContract(contract)}
                        >
                          Interact
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Terminal Tab */}
          <TabsContent value="terminal" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Terminal className="h-5 w-5" />
                  <span>Web3 Shell</span>
                </CardTitle>
                <CardDescription>
                  Execute commands with temporal verification and blockchain integration
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="bg-black text-green-400 p-4 rounded-lg font-mono text-sm h-96 overflow-y-auto">
                    <div className="space-y-1">
                      <div>Web3 Linux OS Shell v1.0.0</div>
                      <div>Type 'help' for available commands</div>
                      <div>Current chronon: {systemMetrics.blockchain.chronon}</div>
                      <div>----------------------------------------</div>
                      {commandHistory.map((cmd, index) => (
                        <div key={index}>
                          <div>$ {cmd}</div>
                          <div className="text-blue-400">
                            Command executed successfully at chronon {systemMetrics.blockchain.chronon}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="font-mono text-sm">$</span>
                    <Input
                      value={currentCommand}
                      onChange={(e) => setCurrentCommand(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          executeCommand(currentCommand)
                        }
                      }}
                      placeholder="Enter command..."
                      className="flex-1 font-mono"
                    />
                    <Button onClick={() => executeCommand(currentCommand)}>
                      Execute
                    </Button>
                  </div>
                  <div className="text-sm text-muted-foreground">
                    Available commands: chronon-info, temporal-ls, blockchain-status, deploy-contract, system-info
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Notification System */}
      <NotificationSystem
        notifications={notifications}
        onMarkAsRead={markAsRead}
        onDismiss={dismiss}
      />
    </div>
  )
}